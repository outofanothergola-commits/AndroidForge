# PSYCH — private Android APK build from a phone

This project archive has a GitHub Actions workflow added at `.github/workflows/build-apk.yml`. It builds a **debug APK** in GitHub's cloud and saves it as a workflow artifact. It does not publish the app to Google Play.

## Important
- Keep the GitHub repository **Private**. The project includes Firebase app configuration.
- A successful APK build does not guarantee Firebase AI features are configured for your Firebase project/App Check.
- The build workflow uses Gradle 9.3.1, Java 17, Android SDK Platform 36.1, and Build Tools 36.0.0.
- This archive does not contain a Gradle wrapper, so the workflow installs Gradle in the cloud and invokes `gradle` directly.

## Phone-only steps
1. Create a **Private** repository on https://github.com/new. Do not initialize it with a README, .gitignore, or license.
2. Install Termux from https://f-droid.org/packages/com.termux/ and open it.
3. Run `termux-setup-storage` and allow access.
4. Put this ZIP in your phone's Downloads folder, then run:

   ```sh
   pkg update -y && pkg install git unzip -y
   cd ~/storage/downloads
   unzip PSYCH-phone-build.zip -d psych-build
   cd psych-build
   git init -b main
   git add .
   git commit -m "Add PSYCH Android project"
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-PRIVATE-REPO.git
   git push -u origin main
   ```

5. For the GitHub password prompt, use a GitHub Personal Access Token, not your account password. Create a classic token at https://github.com/settings/tokens/new with `repo` and `workflow` scopes. Keep it private; never paste it into chat.
6. Open your private repository on GitHub in Chrome. Tap **Actions** → **Build PSYCH APK** → **Run workflow** → **Run workflow**.
7. Wait for the run to finish with a green check. Open that run, scroll to **Artifacts**, and download `PSYCH-debug-APK`.
8. Extract the downloaded artifact ZIP. Tap the `.apk` file and allow Chrome/Files to install apps from that source if Android asks. Tap **Install**.

If `git push` fails, check that the token has both `repo` and `workflow` scopes and that the remote URL matches your private repository.
