package com.example

import com.example.ai.HipHopMasterTemplate
import com.example.audio.MasteringProfile
import com.example.audio.StudioPcmFormat
import com.example.audio.buildWavHeaderBytes
import com.example.audio.decodeWavBytesToChannels48000
import com.example.audio.inspectWavStreamHeader
import com.example.audio.writeWavSample
import com.example.data.RapStyleEncyclopedia
import com.example.data.StudioLanguage
import com.example.data.local.BeatStyle
import com.example.lyrics.LyricAnalyzer
import com.example.security.OwnerSecurityState
import com.example.video.LyricalVideoFrameRenderer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.random.Random

class LyricAnalyzerTest {

    @Test
    fun `analyze counts bars words and rhyme clusters`() {
        val sample = """
            [Verse 1]
            Stepping in the booth with a steady flow
            Watch the amber meters start to glow
            Every single bar sharp as a blade
            Nothing in the studio was ever fake
        """.trimIndent()

        val stats = LyricAnalyzer.analyze(sample)
        assertEquals(4, stats.barCount)
        assertTrue(stats.wordCount > 20)
        assertTrue(stats.rhymeGroupsCount >= 1)

        val flowLine = stats.lines.first { it.endWord == "flow" }
        val glowLine = stats.lines.first { it.endWord == "glow" }
        assertEquals(flowLine.rhymeGroupIndex, glowLine.rhymeGroupIndex)
    }

    @Test
    fun `findRhymesFor returns matching suggestions`() {
        val rhymes = LyricAnalyzer.findRhymesFor("flow")
        assertTrue(rhymes.contains("glow"))
        assertTrue(rhymes.contains("show"))
    }

    @Test
    fun `encyclopedia and master template expose full hip hop craft and durations`() {
        assertEquals(10, RapStyleEncyclopedia.subgenreCategories.size)
        assertTrue(RapStyleEncyclopedia.allSubgenresFlat.size >= 150)
        assertEquals(25, RapStyleEncyclopedia.flowDeliveryTechniques.size)
        assertEquals(30, RapStyleEncyclopedia.lyricWritingTechniques.size)
        assertEquals(20, RapStyleEncyclopedia.productionStyles.size)
        assertEquals(20, RapStyleEncyclopedia.ultimateCombinations.size)

        val threeMin = HipHopMasterTemplate.buildScaffold("Test", "Trap", "Dark", 136, "Deep", 3)
        val tenMin = HipHopMasterTemplate.buildScaffold("Test", "Trap", "Dark", 136, "Deep", 10)
        assertTrue(threeMin.contains("[Verse 1 – 16 Bars]"))
        assertTrue(threeMin.contains("[Final Hook – 8 Bars]"))
        assertTrue(tenMin.contains("[Verse 4 – 16 Bars]"))
    }

    @Test
    fun `studio languages include requested regional and classical languages`() {
        val names = StudioLanguage.entries.map { it.englishName }
        assertTrue(StudioLanguage.entries.size >= 33)
        assertTrue(names.contains("Hindi"))
        assertTrue(names.contains("English"))
        assertTrue(names.contains("Assamese"))
        assertTrue(names.contains("Nepali"))
        assertTrue(names.contains("Bodo / Boro"))
        assertTrue(names.contains("Sanskrit"))
        assertTrue(names.any { it.contains("Aadivasi") })
        assertTrue(names.contains("Punjabi"))
        assertTrue(names.contains("Bengali"))
    }

    @Test
    fun `lyrical video parser builds clean timed lines`() {
        val raw = """
            [Intro – 4 Bars]
            Lights low in the private room
            Bass heavy shaking up the moon
            [Hook]
            Every crown belongs to psycho
        """.trimIndent()
        val parsed = LyricalVideoFrameRenderer.parseTimedLines(raw, totalDurationMs = 9_000L)
        assertEquals(3, parsed.size)
        assertEquals("Intro – 4 Bars", parsed[0].sectionTag)
        assertEquals("Hook", parsed[2].sectionTag)
        assertEquals(0L, parsed[0].startMs)
        assertEquals(9_000L, parsed.last().endMs)
    }

    @Test
    fun `wav 32-bit float and 24-bit pcm encode decode round-trip preserves precision`() {
        val srcLeft = doubleArrayOf(-0.85, -0.25, 0.0, 0.42, 0.93)
        val srcRight = doubleArrayOf(0.75, 0.125, -0.5, 0.18, -0.91)
        val rng = Random(1234)

        for (fmt in listOf(StudioPcmFormat.PCM_32_FLOAT, StudioPcmFormat.PCM_24_INT)) {
            val header = buildWavHeaderBytes(
                totalFrames = srcLeft.size.toLong(),
                sampleRate = 48000,
                channels = 2,
                format = fmt,
            )
            val bytesPerSample = fmt.bitsPerSample / 8
            val data = ByteArray(srcLeft.size * 2 * bytesPerSample)
            var pos = 0
            for (i in srcLeft.indices) {
                pos = writeWavSample(data, pos, srcLeft[i], fmt, rng)
                pos = writeWavSample(data, pos, srcRight[i], fmt, rng)
            }
            val fullWav = header + data
            val info = inspectWavStreamHeader(fullWav)
            assertNotNull(info)
            assertEquals(fmt.bitsPerSample, info!!.bitsPerSample)
            assertEquals(fmt.isFloat, info.isFloat)
            assertEquals(48000, info.sampleRate)
            assertEquals(2, info.channels)

            val decoded = decodeWavBytesToChannels48000(fullWav)
            assertNotNull(decoded)
            val (outL, outR) = decoded!!
            assertEquals(srcLeft.size, outL.size)
            val tol = if (fmt.isFloat) 1e-6 else 2e-5
            for (i in srcLeft.indices) {
                assertTrue("Left mismatch for $fmt at $i", abs(outL[i] - srcLeft[i]) < tol)
                assertTrue("Right mismatch for $fmt at $i", abs(outR[i] - srcRight[i]) < tol)
            }
        }
    }

    @Test
    fun `mastering profiles, new beat styles, and preview shield default are configured`() {
        assertEquals(4, MasteringProfile.entries.size)
        assertTrue(BeatStyle.entries.contains(BeatStyle.ORCHESTRAL_CINEMATIC))
        assertTrue(BeatStyle.entries.contains(BeatStyle.PHONK_MEMPHIS))
        val defaultSecurity = OwnerSecurityState()
        assertEquals(false, defaultSecurity.screenPrivacyShield)
        assertEquals(true, defaultSecurity.strictPrivateVault)
    }
}

