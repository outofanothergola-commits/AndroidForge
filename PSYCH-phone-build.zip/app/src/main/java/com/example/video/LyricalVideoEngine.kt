package com.example.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.audio.BeatEngine
import com.example.audio.STUDIO_SAMPLE_RATE
import com.example.audio.decodeAudioToMono48000
import com.example.audio.extractSpectrumTimeline
import com.example.data.local.BeatStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class LyricalVideoTheme(
    val displayName: String,
    val bgTop: Int,
    val bgBottom: Int,
    val accentPrimary: Int,
    val accentSecondary: Int,
    val textPrimary: Int,
) {
    CYBER_GOLD("Cyber Gold", 0xFF0A0D14.toInt(), 0xFF192132.toInt(), 0xFFFF9F1C.toInt(), 0xFF00E5FF.toInt(), 0xFFF8FAFC.toInt()),
    DESI_FIRE("Desi Fire", 0xFF14070B.toInt(), 0xFF2B1018.toInt(), 0xFFFF5722.toInt(), 0xFFFFD166.toInt(), 0xFFFFF8F0.toInt()),
    NEON_MATRIX("Neon Matrix", 0xFF06130F.toInt(), 0xFF0E261E.toInt(), 0xFF2CEAA3.toInt(), 0xFF00E5FF.toInt(), 0xFFF0FDF4.toInt()),
    HIMALAYAN_AURORA("Aurora Mist", 0xFF0A0D1C.toInt(), 0xFF1B163A.toInt(), 0xFFA78BFA.toInt(), 0xFF38BDF8.toInt(), 0xFFF8FAFC.toInt()),
    VINYL_NOIR("Vinyl Noir", 0xFF101012.toInt(), 0xFF231E18.toInt(), 0xFFEAB308.toInt(), 0xFFFB923C.toInt(), 0xFFFAF5E8.toInt()),
}

enum class VideoAspectRatio(
    val label: String,
    val width: Int,
    val height: Int,
) {
    REELS_9_16("9:16 Reels", 720, 1280),
    SQUARE_1_1("1:1 Square", 720, 720),
    YOUTUBE_16_9("16:9 HD", 1280, 720),
}

data class TimedLyricLine(
    val text: String,
    val sectionTag: String,
    val startMs: Long,
    val endMs: Long,
)

data class GeneratedVideoResult(
    val filePath: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
)

object LyricalVideoFrameRenderer {

    fun parseTimedLines(lyrics: String, totalDurationMs: Long): List<TimedLyricLine> {
        val dur = totalDurationMs.coerceAtLeast(4000L)
        val rawLines = lyrics.lines()
            .map { it.trim() }
            .filter {
                it.isNotEmpty() &&
                    !it.startsWith("Song Title:", ignoreCase = true) &&
                    !it.startsWith("Genre:", ignoreCase = true)
            }

        var currentSection = "STUDIO CUT"
        val performable = mutableListOf<Pair<String, String>>()
        for (line in rawLines) {
            if (line.startsWith("[") && line.endsWith("]")) {
                currentSection = line.removePrefix("[").removeSuffix("]").trim()
            } else {
                performable.add(line to currentSection)
            }
        }
        if (performable.isEmpty()) {
            performable.add("PSYCH☯⚡ STUDIO SESSION" to "INSTRUMENTAL")
            performable.add("Original Beat & Master Recording" to "INSTRUMENTAL")
        }

        val totalWeight = performable.sumOf { (txt, _) -> txt.length.coerceAtLeast(10) }.toDouble()
        var cursorMs = 0L
        return performable.mapIndexed { idx, (txt, sec) ->
            val weight = txt.length.coerceAtLeast(10).toDouble() / totalWeight
            val lineDur = if (idx == performable.lastIndex) {
                (dur - cursorMs).coerceAtLeast(500L)
            } else {
                (dur * weight).toLong().coerceAtLeast(700L)
            }
            val start = cursorMs
            val end = (start + lineDur).coerceAtMost(dur)
            cursorMs = end
            TimedLyricLine(txt, sec, start, end)
        }
    }

    fun drawFrame(
        canvas: Canvas,
        width: Int,
        height: Int,
        theme: LyricalVideoTheme,
        songTitle: String,
        artistName: String,
        metaLine: String,
        timedLines: List<TimedLyricLine>,
        spectrumBars: FloatArray,
        coverBitmap: Bitmap?,
        currentMs: Long,
        totalMs: Long,
    ) {
        val w = width.toFloat()
        val h = height.toFloat()
        val progress = (currentMs.toFloat() / totalMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
        val bassEnergy = if (spectrumBars.size >= 5) {
            (spectrumBars[0] + spectrumBars[1] + spectrumBars[2] + spectrumBars[3]) / 4f
        } else {
            0.25f
        }

        // 1. Background gradient
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, h, theme.bgTop, theme.bgBottom, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // 2. Optional Cover Art Backdrop + Dark Vignette
        if (coverBitmap != null && !coverBitmap.isRecycled) {
            val scale = maxOf(w / coverBitmap.width, h / coverBitmap.height)
            val drawW = coverBitmap.width * scale
            val drawH = coverBitmap.height * scale
            val left = (w - drawW) / 2f
            val top = (h - drawH) / 2f
            val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 110 }
            canvas.drawBitmap(coverBitmap, null, RectF(left, top, left + drawW, top + drawH), imgPaint)

            val veilPaint = Paint().apply {
                shader = LinearGradient(
                    0f, 0f, 0f, h,
                    Color.argb(185, 8, 10, 16),
                    Color.argb(230, 8, 10, 16),
                    Shader.TileMode.CLAMP,
                )
            }
            canvas.drawRect(0f, 0f, w, h, veilPaint)
        }

        // 3. Beat-pulsing radial glow aura
        val auraRadius = minOf(w, h) * (0.42f + bassEnergy * 0.16f)
        val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                w / 2f,
                h * 0.40f,
                auraRadius,
                intArrayOf(
                    applyAlpha(theme.accentPrimary, (75 + bassEnergy * 95).toInt().coerceIn(40, 175)),
                    applyAlpha(theme.accentSecondary, 28),
                    Color.TRANSPARENT,
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawCircle(w / 2f, h * 0.40f, auraRadius, auraPaint)

        // 4. Spinning vinyl emblem / cover disc in upper area
        val isLandscape = w > h * 1.15f
        val discCenterX = if (isLandscape) w * 0.20f else w * 0.5f
        val discCenterY = if (isLandscape) h * 0.46f else h * 0.25f
        val discRadius = minOf(w, h) * (if (isLandscape) 0.19f else 0.135f) * (1f + bassEnergy * 0.05f)
        drawSpinningEmblem(canvas, discCenterX, discCenterY, discRadius, theme, currentMs, coverBitmap)

        // 5. Top Header Brand & Song Title
        val pad = w * 0.06f
        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyAlpha(theme.accentPrimary, 46)
            style = Paint.Style.FILL
        }
        val badgeBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyAlpha(theme.accentPrimary, 165)
            style = Paint.Style.STROKE
            strokeWidth = (w * 0.0025f).coerceAtLeast(1.5f)
        }
        val brandTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.accentPrimary
            textSize = minOf(w, h) * 0.025f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.08f
        }
        val brandStr = "PSYCH☯⚡ • $metaLine"
        val brandW = brandTextPaint.measureText(brandStr) + pad * 0.7f
        val badgeRect = RectF(pad, h * 0.045f, (pad + brandW).coerceAtMost(w - pad), h * 0.045f + brandTextPaint.textSize * 2.1f)
        canvas.drawRoundRect(badgeRect, 999f, 999f, badgePaint)
        canvas.drawRoundRect(badgeRect, 999f, 999f, badgeBorder)
        canvas.drawText(
            brandStr,
            badgeRect.left + pad * 0.35f,
            badgeRect.centerY() + brandTextPaint.textSize * 0.35f,
            brandTextPaint,
        )

        val titleX = if (isLandscape) w * 0.36f else pad
        val titleY = if (isLandscape) h * 0.17f else discCenterY + discRadius + h * 0.055f
        val titleWidth = (w - titleX - pad).toInt().coerceAtLeast(120)

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.textPrimary
            textSize = minOf(w, h) * 0.048f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val titleLayout = buildStaticLayout(songTitle.ifBlank { "Untitled Track" }, titlePaint, titleWidth, if (isLandscape) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_CENTER)
        canvas.save()
        canvas.translate(titleX, titleY)
        titleLayout.draw(canvas)
        canvas.restore()

        val artistPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.accentSecondary
            textSize = minOf(w, h) * 0.028f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = if (isLandscape) Paint.Align.LEFT else Paint.Align.CENTER
        }
        val artistY = titleY + titleLayout.height + artistPaint.textSize * 1.1f
        val artistX = if (isLandscape) titleX else w / 2f
        canvas.drawText(artistName.ifBlank { "psycho" }, artistX, artistY, artistPaint)

        // 6. Active Kinetic Karaoke Lyrics Stage
        val activeIndex = timedLines.indexOfFirst { currentMs in it.startMs..it.endMs }
            .let { if (it >= 0) it else timedLines.lastIndex.coerceAtLeast(0) }
        val activeLine = timedLines[activeIndex]
        val prevLine = timedLines.getOrNull(activeIndex - 1)
        val nextLine = timedLines.getOrNull(activeIndex + 1)

        val lyricLeft = if (isLandscape) w * 0.36f else pad
        val lyricWidth = (w - lyricLeft - pad).toInt().coerceAtLeast(150)
        val lyricCenterY = if (isLandscape) h * 0.50f else h * 0.62f
        val align = if (isLandscape) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_CENTER

        // Section chapter pill
        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyAlpha(theme.accentSecondary, 210)
            textSize = minOf(w, h) * 0.024f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = if (isLandscape) Paint.Align.LEFT else Paint.Align.CENTER
        }
        canvas.drawText(
            "[ ${activeLine.sectionTag} ]",
            if (isLandscape) lyricLeft else w / 2f,
            lyricCenterY - minOf(w, h) * 0.135f,
            sectionPaint,
        )

        // Previous line (faded)
        if (prevLine != null) {
            val prevPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = applyAlpha(theme.textPrimary, 95)
                textSize = minOf(w, h) * 0.032f
            }
            val prevLayout = buildStaticLayout(prevLine.text, prevPaint, lyricWidth, align)
            canvas.save()
            canvas.translate(lyricLeft, lyricCenterY - minOf(w, h) * 0.105f)
            prevLayout.draw(canvas)
            canvas.restore()
        }

        // Active line (glowing kinetic spotlight)
        val activePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.textPrimary
            textSize = minOf(w, h) * 0.048f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setShadowLayer(12f, 0f, 0f, applyAlpha(theme.accentPrimary, 200))
        }
        val activeLayout = buildStaticLayout(activeLine.text, activePaint, lyricWidth, align)
        val lineProgress = ((currentMs - activeLine.startMs).toFloat() / (activeLine.endMs - activeLine.startMs).coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
        val activeTop = lyricCenterY - activeLayout.height * 0.35f

        val cardBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyAlpha(theme.accentPrimary, 24)
        }
        val cardBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyAlpha(theme.accentPrimary, 140)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        val lyricBox = RectF(
            lyricLeft - 14f,
            activeTop - 16f,
            lyricLeft + lyricWidth + 14f,
            activeTop + activeLayout.height + 24f,
        )
        canvas.drawRoundRect(lyricBox, 22f, 22f, cardBg)
        canvas.drawRoundRect(lyricBox, 22f, 22f, cardBorder)

        canvas.save()
        canvas.translate(lyricLeft, activeTop)
        activeLayout.draw(canvas)
        canvas.restore()

        // Karaoke progress bar inside active lyric card
        val kBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = theme.accentPrimary }
        canvas.drawRoundRect(
            RectF(
                lyricBox.left + 16f,
                lyricBox.bottom - 10f,
                lyricBox.left + 16f + (lyricBox.width() - 32f) * lineProgress,
                lyricBox.bottom - 4f,
            ),
            4f,
            4f,
            kBarPaint,
        )

        // Next line preview
        if (nextLine != null) {
            val nextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = applyAlpha(theme.textPrimary, 120)
                textSize = minOf(w, h) * 0.032f
            }
            val nextLayout = buildStaticLayout(nextLine.text, nextPaint, lyricWidth, align)
            canvas.save()
            canvas.translate(lyricLeft, lyricBox.bottom + minOf(w, h) * 0.025f)
            nextLayout.draw(canvas)
            canvas.restore()
        }

        // 7. Audio-Reactive 40-Bar Spectrum Visualizer
        val barAreaTop = h * 0.80f
        val barAreaBottom = h * 0.91f
        val maxBarH = (barAreaBottom - barAreaTop).coerceAtLeast(24f)
        val count = spectrumBars.size.coerceAtLeast(1)
        val specLeft = pad
        val specW = w - pad * 2f
        val stepW = specW / count
        val barW = (stepW * 0.58f).coerceAtLeast(3f)
        val specPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until count) {
            val mag = spectrumBars[i].coerceIn(0.06f, 1f)
            val bh = maxBarH * mag
            val bx = specLeft + i * stepW + (stepW - barW) / 2f
            val by = barAreaBottom - bh
            specPaint.shader = LinearGradient(
                bx, by, bx, barAreaBottom,
                theme.accentSecondary,
                theme.accentPrimary,
                Shader.TileMode.CLAMP,
            )
            canvas.drawRoundRect(RectF(bx, by, bx + barW, barAreaBottom), barW / 2f, barW / 2f, specPaint)
        }

        // 8. Bottom Master Timeline & Clock
        val trackY = h * 0.945f
        val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = applyAlpha(theme.textPrimary, 45) }
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = theme.accentPrimary }
        canvas.drawRoundRect(RectF(pad, trackY, w - pad, trackY + 7f), 4f, 4f, trackPaint)
        canvas.drawRoundRect(RectF(pad, trackY, pad + (w - pad * 2f) * progress, trackY + 7f), 4f, 4f, fillPaint)

        val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyAlpha(theme.textPrimary, 175)
            textSize = minOf(w, h) * 0.024f
            typeface = Typeface.MONOSPACE
        }
        canvas.drawText(formatClock(currentMs), pad, trackY + timePaint.textSize * 1.45f, timePaint)
        timePaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(formatClock(totalMs), w - pad, trackY + timePaint.textSize * 1.45f, timePaint)
    }

    private fun drawSpinningEmblem(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        radius: Float,
        theme: LyricalVideoTheme,
        currentMs: Long,
        coverBitmap: Bitmap?,
    ) {
        val discPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF0E121A.toInt()
            style = Paint.Style.FILL
        }
        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.accentPrimary
            style = Paint.Style.STROKE
            strokeWidth = (radius * 0.06f).coerceAtLeast(3f)
        }
        val groovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyAlpha(theme.accentSecondary, 90)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }

        canvas.drawCircle(cx, cy, radius, discPaint)
        canvas.drawCircle(cx, cy, radius * 0.80f, groovePaint)
        canvas.drawCircle(cx, cy, radius * 0.62f, groovePaint)
        canvas.drawCircle(cx, cy, radius, ringPaint)

        canvas.save()
        val angleDeg = (currentMs * 0.045f) % 360f
        canvas.rotate(angleDeg, cx, cy)
        if (coverBitmap != null && !coverBitmap.isRecycled) {
            val innerR = radius * 0.56f
            val path = android.graphics.Path().apply { addCircle(cx, cy, innerR, android.graphics.Path.Direction.CW) }
            canvas.save()
            canvas.clipPath(path)
            canvas.drawBitmap(coverBitmap, null, RectF(cx - innerR, cy - innerR, cx + innerR, cy + innerR), Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
        } else {
            val symPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = theme.accentPrimary
                textSize = radius * 0.55f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.DEFAULT_BOLD
            }
            canvas.drawText("☯⚡", cx, cy + symPaint.textSize * 0.35f, symPaint)
        }
        canvas.restore()
    }

    private fun buildStaticLayout(
        text: String,
        paint: TextPaint,
        width: Int,
        align: Layout.Alignment,
    ): StaticLayout {
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(align)
            .setLineSpacing(4f, 1.08f)
            .setMaxLines(3)
            .build()
    }

    private fun applyAlpha(color: Int, alpha: Int): Int {
        return Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
    }

    private fun formatClock(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        return String.format(Locale.US, "%02d:%02d", totalSec / 60L, totalSec % 60L)
    }
}

/**
 * Hardware/Surface H.264 + AAC MPEG-4 Lyrical Music Video Generator.
 * Renders real MP4 videos containing animated kinetic karaoke lyrics, audio-reactive spectrum bars,
 * custom cover artwork, and muxed stereo AAC studio audio.
 */
class LyricalVideoEngine(
    private val context: Context,
    private val beatEngine: BeatEngine,
) {
    suspend fun renderLyricalVideoMp4(
        songTitle: String,
        artistName: String,
        metaLine: String,
        lyrics: String,
        sourceAudioPath: String?,
        beatStyle: BeatStyle,
        bpm: Int,
        fallbackDurationSec: Int,
        theme: LyricalVideoTheme,
        aspectRatio: VideoAspectRatio,
        coverImageUri: Uri?,
        onProgress: (Float) -> Unit,
    ): Result<GeneratedVideoResult> = withContext(Dispatchers.IO) {
        runCatching {
            val width = aspectRatio.width
            val height = aspectRatio.height
            val fps = 30
            val coverBitmap = coverImageUri?.let { loadScaledCoverBitmap(it, width, height) }

            // 1. Obtain 48kHz mono PCM for audio encoding & spectrum reactive animation
            val mono48k: FloatArray = if (!sourceAudioPath.isNullOrBlank() && File(sourceAudioPath).exists()) {
                decodeAudioToMono48000(context, sourceAudioPath)
            } else {
                val secs = fallbackDurationSec.coerceIn(10, 120)
                val frames = secs.toLong() * STUDIO_SAMPLE_RATE.toLong()
                val outMono = FloatArray(frames.toInt())
                var cursor = 0
                beatEngine.renderInstrumentalChunked(
                    style = if (beatStyle == BeatStyle.CUSTOM || beatStyle == BeatStyle.METRONOME) BeatStyle.TRAP_808 else beatStyle,
                    bpm = bpm,
                    totalFrames = frames,
                ) { stereo, chunkFrames ->
                    for (i in 0 until chunkFrames) {
                        outMono[cursor + i] = ((stereo[i * 2] + stereo[i * 2 + 1]) * 0.5f).coerceIn(-0.97f, 0.97f)
                    }
                    cursor += chunkFrames
                }
                outMono
            }

            require(mono48k.size >= STUDIO_SAMPLE_RATE) { "Audio source is too short to generate video." }
            val durationMs = ((mono48k.size.toLong() * 1000L) / STUDIO_SAMPLE_RATE.toLong()).coerceAtLeast(1000L)
            val totalVideoFrames = ((durationMs * fps) / 1000L).toInt().coerceAtLeast(fps)

            onProgress(0.05f)
            val spectrumTimeline = extractSpectrumTimeline(mono48k, fps = fps, bandCount = 40)
            val timedLines = LyricalVideoFrameRenderer.parseTimedLines(lyrics, durationMs)

            val videoDir = File(context.filesDir, "videos").apply { mkdirs() }
            val outFile = File(videoDir, "psych_lyric_video_${System.currentTimeMillis()}.mp4")

            encodeH264AacMp4(
                outFile = outFile,
                width = width,
                height = height,
                fps = fps,
                totalVideoFrames = totalVideoFrames,
                mono48k = mono48k,
                theme = theme,
                songTitle = songTitle,
                artistName = artistName,
                metaLine = metaLine,
                timedLines = timedLines,
                spectrumTimeline = spectrumTimeline,
                coverBitmap = coverBitmap,
                onProgress = onProgress,
            )

            runCatching { coverBitmap?.recycle() }
            onProgress(1.0f)
            GeneratedVideoResult(
                filePath = outFile.absolutePath,
                durationMs = durationMs,
                width = width,
                height = height,
            )
        }
    }

    private fun encodeH264AacMp4(
        outFile: File,
        width: Int,
        height: Int,
        fps: Int,
        totalVideoFrames: Int,
        mono48k: FloatArray,
        theme: LyricalVideoTheme,
        songTitle: String,
        artistName: String,
        metaLine: String,
        timedLines: List<TimedLyricLine>,
        spectrumTimeline: List<FloatArray>,
        coverBitmap: Bitmap?,
        onProgress: (Float) -> Unit,
    ) {
        val videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 3_600_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, STUDIO_SAMPLE_RATE, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }

        val videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        val audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        var inputSurface: android.view.Surface? = null
        var muxerStarted = false

        try {
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = videoEncoder.createInputSurface()
            videoEncoder.start()

            audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            audioEncoder.start()

            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var outVideoFormat: MediaFormat? = null
            var outAudioFormat: MediaFormat? = null

            val bufferedVideo = mutableListOf<Pair<MediaCodec.BufferInfo, ByteArray>>()
            val bufferedAudio = mutableListOf<Pair<MediaCodec.BufferInfo, ByteArray>>()

            fun tryStartMuxer() {
                if (!muxerStarted && outVideoFormat != null && outAudioFormat != null) {
                    videoTrackIndex = muxer.addTrack(outVideoFormat!!)
                    audioTrackIndex = muxer.addTrack(outAudioFormat!!)
                    muxer.start()
                    muxerStarted = true
                    for ((info, data) in bufferedVideo) {
                        muxer.writeSampleData(videoTrackIndex, ByteBuffer.wrap(data), info)
                    }
                    bufferedVideo.clear()
                    for ((info, data) in bufferedAudio) {
                        muxer.writeSampleData(audioTrackIndex, ByteBuffer.wrap(data), info)
                    }
                    bufferedAudio.clear()
                }
            }

            fun drainVideo(endOfStream: Boolean): Boolean {
                val info = MediaCodec.BufferInfo()
                var done = false
                while (true) {
                    val outIdx = videoEncoder.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)
                    when {
                        outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> break
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            outVideoFormat = videoEncoder.outputFormat
                            tryStartMuxer()
                        }
                        outIdx >= 0 -> {
                            val buf = videoEncoder.getOutputBuffer(outIdx)
                            if (buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                val bytes = ByteArray(info.size)
                                buf.position(info.offset)
                                buf.get(bytes)
                                val copyInfo = MediaCodec.BufferInfo().apply {
                                    set(0, bytes.size, info.presentationTimeUs, info.flags)
                                }
                                if (muxerStarted) {
                                    muxer.writeSampleData(videoTrackIndex, ByteBuffer.wrap(bytes), copyInfo)
                                } else {
                                    bufferedVideo.add(copyInfo to bytes)
                                }
                            }
                            videoEncoder.releaseOutputBuffer(outIdx, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                done = true
                                break
                            }
                        }
                    }
                }
                return done
            }

            fun drainAudio(endOfStream: Boolean): Boolean {
                val info = MediaCodec.BufferInfo()
                var done = false
                while (true) {
                    val outIdx = audioEncoder.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)
                    when {
                        outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> break
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            outAudioFormat = audioEncoder.outputFormat
                            tryStartMuxer()
                        }
                        outIdx >= 0 -> {
                            val buf = audioEncoder.getOutputBuffer(outIdx)
                            if (buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                val bytes = ByteArray(info.size)
                                buf.position(info.offset)
                                buf.get(bytes)
                                val copyInfo = MediaCodec.BufferInfo().apply {
                                    set(0, bytes.size, info.presentationTimeUs, info.flags)
                                }
                                if (muxerStarted) {
                                    muxer.writeSampleData(audioTrackIndex, ByteBuffer.wrap(bytes), copyInfo)
                                } else {
                                    bufferedAudio.add(copyInfo to bytes)
                                }
                            }
                            audioEncoder.releaseOutputBuffer(outIdx, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                done = true
                                break
                            }
                        }
                    }
                }
                return done
            }

            var audioSampleCursor = 0
            var audioEosSent = false
            val totalDurationMs = (mono48k.size.toLong() * 1000L) / STUDIO_SAMPLE_RATE.toLong()

            fun feedAudioChunk() {
                if (audioEosSent) return
                var fed = 0
                while (fed < 4) {
                    val inIdx = audioEncoder.dequeueInputBuffer(2_000L)
                    if (inIdx < 0) break
                    val buf = audioEncoder.getInputBuffer(inIdx) ?: break
                    buf.clear()
                    if (audioSampleCursor >= mono48k.size) {
                        val ptsUs = (audioSampleCursor.toLong() * 1_000_000L) / STUDIO_SAMPLE_RATE.toLong()
                        audioEncoder.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        audioEosSent = true
                        break
                    } else {
                        val maxFramesInBuf = (buf.remaining() / 4).coerceAtMost(1024)
                        val count = minOf(maxFramesInBuf, mono48k.size - audioSampleCursor)
                        val ptsUs = (audioSampleCursor.toLong() * 1_000_000L) / STUDIO_SAMPLE_RATE.toLong()
                        for (i in 0 until count) {
                            val s = (mono48k[audioSampleCursor + i] * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                            val lo = (s.toInt() and 0xFF).toByte()
                            val hi = ((s.toInt() shr 8) and 0xFF).toByte()
                            buf.put(lo)
                            buf.put(hi)
                            buf.put(lo)
                            buf.put(hi)
                        }
                        audioEncoder.queueInputBuffer(inIdx, 0, count * 4, ptsUs, 0)
                        audioSampleCursor += count
                        fed++
                    }
                }
            }

            // Encode video frames & interleave audio chunks
            for (frameIdx in 0 until totalVideoFrames) {
                val canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    inputSurface.lockHardwareCanvas()
                } else {
                    inputSurface.lockCanvas(null)
                }
                try {
                    val currentMs = (frameIdx.toLong() * 1000L) / fps.toLong()
                    val bars = spectrumTimeline.getOrElse(frameIdx) { FloatArray(40) { 0.08f } }
                    LyricalVideoFrameRenderer.drawFrame(
                        canvas = canvas,
                        width = width,
                        height = height,
                        theme = theme,
                        songTitle = songTitle,
                        artistName = artistName,
                        metaLine = metaLine,
                        timedLines = timedLines,
                        spectrumBars = bars,
                        coverBitmap = coverBitmap,
                        currentMs = currentMs,
                        totalMs = totalDurationMs,
                    )
                } finally {
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                feedAudioChunk()
                drainVideo(endOfStream = false)
                drainAudio(endOfStream = false)

                if (frameIdx % 6 == 0) {
                    val pct = 0.08f + 0.86f * (frameIdx.toFloat() / totalVideoFrames.coerceAtLeast(1))
                    onProgress(pct.coerceIn(0f, 0.96f))
                }
            }

            // Flush remaining audio and signal video EOS
            videoEncoder.signalEndOfInputStream()
            var vDone = false
            var aDone = false
            var safety = 0
            while ((!vDone || !aDone) && safety < 250) {
                if (!audioEosSent) feedAudioChunk()
                if (!vDone) vDone = drainVideo(endOfStream = true)
                if (!aDone) aDone = drainAudio(endOfStream = true)
                safety++
            }
        } finally {
            runCatching { inputSurface?.release() }
            runCatching { videoEncoder.stop() }
            runCatching { videoEncoder.release() }
            runCatching { audioEncoder.stop() }
            runCatching { audioEncoder.release() }
            if (muxerStarted) {
                runCatching { muxer.stop() }
            }
            runCatching { muxer.release() }
        }
    }

    private fun loadScaledCoverBitmap(uri: Uri, targetW: Int, targetH: Int): Bitmap? {
        return runCatching {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOpts)
            }
            var sample = 1
            while (boundsOpts.outWidth / sample > targetW * 2 || boundsOpts.outHeight / sample > targetH * 2) {
                sample *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOpts)
            }
        }.getOrNull()
    }
}
