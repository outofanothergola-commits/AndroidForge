package com.example.lyrics

data class AnalyzedLine(
    val lineNumber: Int,
    val text: String,
    val isSectionHeader: Boolean,
    val syllableCount: Int,
    val endWord: String,
    val rhymeKey: String,
    val rhymeGroupIndex: Int?,
)

data class LyricStats(
    val barCount: Int,
    val wordCount: Int,
    val totalSyllables: Int,
    val avgSyllablesPerBar: Int,
    val rhymeGroupsCount: Int,
    val lines: List<AnalyzedLine>,
)

object LyricAnalyzer {

    private val vowelGroupRegex = Regex("[aeiouy]+")
    private val wordRegex = Regex("[a-zA-Z']+")

    private val builtInRhymeBank: Map<String, List<String>> = mapOf(
        "ow" to listOf("flow", "glow", "show", "slow", "know", "crow", "throw", "studio", "below", "pro"),
        "ight" to listOf("night", "light", "mic", "tight", "flight", "sight", "bright", "fight", "write", "ignite"),
        "ay" to listOf("day", "way", "say", "play", "stay", "pay", "fade", "blade", "made", "replay"),
        "ind" to listOf("grind", "mind", "find", "blind", "behind", "shine", "line", "time", "rhyme", "climb"),
        "ire" to listOf("fire", "wire", "higher", "desire", "inspire", "spire", "choir"),
        "ame" to listOf("game", "name", "fame", "flame", "frame", "same", "claim", "aim", "chain", "lane"),
        "eat" to listOf("beat", "heat", "street", "seat", "sheet", "feat", "sweet", "complete", "repeat"),
        "ack" to listOf("track", "back", "stack", "black", "crack", "pack", "attack", "racks", "facts"),
        "one" to listOf("zone", "tone", "throne", "own", "alone", "bone", "stone", "microphone"),
        "eal" to listOf("real", "feel", "steel", "deal", "wheel", "heal", "seal", "appeal"),
        "ock" to listOf("clock", "block", "rock", "lock", "knock", "shock", "stock"),
        "op" to listOf("drop", "top", "stop", "pop", "shop", "hiphop", "nonstop"),
        "ing" to listOf("king", "ring", "bring", "sing", "swing", "wing", "bling", "everything"),
        "ar" to listOf("bar", "star", "car", "far", "scar", "guitar", "superstar"),
        "ood" to listOf("hood", "good", "understood", "stood", "wood"),
        "art" to listOf("heart", "start", "art", "part", "smart", "chart", "apart"),
    )

    fun analyze(rawLyrics: String): LyricStats {
        if (rawLyrics.isBlank()) {
            return LyricStats(0, 0, 0, 0, 0, emptyList())
        }

        val rawLines = rawLyrics.lines()
        val prelim = rawLines.mapIndexed { index, line ->
            val trimmed = line.trim()
            val isHeader = trimmed.startsWith("[") && trimmed.endsWith("]")
            val syllables = if (trimmed.isEmpty() || isHeader) 0 else countSyllablesInLine(trimmed)
            val lastWord = if (trimmed.isEmpty() || isHeader) "" else extractLastWord(trimmed)
            val rhymeKey = if (lastWord.isEmpty()) "" else computeRhymeKey(lastWord)
            AnalyzedLine(
                lineNumber = index + 1,
                text = line,
                isSectionHeader = isHeader,
                syllableCount = syllables,
                endWord = lastWord,
                rhymeKey = rhymeKey,
                rhymeGroupIndex = null,
            )
        }

        // Group rhyme keys that appear at least twice
        val keyCounts = prelim
            .mapNotNull { it.rhymeKey.takeIf(String::isNotEmpty) }
            .groupingBy { it }
            .eachCount()

        val activeKeys = keyCounts.filterValues { it >= 2 }.keys.toList()
        val keyToIndex = activeKeys.withIndex().associate { (idx, key) -> key to idx }

        val finalLines = prelim.map { item ->
            val groupIdx = if (item.rhymeKey.isNotEmpty()) keyToIndex[item.rhymeKey] else null
            item.copy(rhymeGroupIndex = groupIdx)
        }

        val bars = finalLines.filter { it.text.isNotBlank() && !it.isSectionHeader }
        val barCount = bars.size
        val wordCount = bars.sumOf { wordRegex.findAll(it.text).count() }
        val totalSyllables = bars.sumOf { it.syllableCount }
        val avgSyllables = if (barCount > 0) totalSyllables / barCount else 0

        return LyricStats(
            barCount = barCount,
            wordCount = wordCount,
            totalSyllables = totalSyllables,
            avgSyllablesPerBar = avgSyllables,
            rhymeGroupsCount = activeKeys.size,
            lines = finalLines,
        )
    }

    fun countSyllablesInLine(line: String): Int {
        return wordRegex.findAll(line).sumOf { match ->
            countSyllablesInWord(match.value)
        }
    }

    fun countSyllablesInWord(rawWord: String): Int {
        val word = rawWord.lowercase().replace("'", "")
        if (word.isEmpty()) return 0
        if (word.length <= 3) return 1

        var cleaned = word.replace(Regex("(?:[^laeiouy]es|ed|[^laeiouy]e)$"), "")
        cleaned = cleaned.replace(Regex("^y"), "")
        val matches = vowelGroupRegex.findAll(cleaned).count()
        return maxOf(1, matches)
    }

    fun extractLastWord(line: String): String {
        val matches = wordRegex.findAll(line).toList()
        return matches.lastOrNull()?.value?.lowercase().orEmpty()
    }

    fun computeRhymeKey(word: String): String {
        val w = word.lowercase().filter { it.isLetter() }
        if (w.length <= 2) return w

        // Normalized trailing vowel-cluster + trailing consonants for phonetic rhyme grouping
        val normalized = w
            .replace("igh", "ai")
            .replace("eigh", "ay")
            .replace("tion", "shun")
            .replace("ck", "k")
            .replace("ph", "f")
            .replace(Regex("e$"), "")

        val vowels = "aeiouy"
        var lastVowelIdx = -1
        for (i in normalized.indices.reversed()) {
            if (normalized[i] in vowels) {
                lastVowelIdx = i
                // step back through contiguous vowels
                var j = i
                while (j > 0 && normalized[j - 1] in vowels) {
                    j--
                }
                lastVowelIdx = j
                break
            }
        }
        return if (lastVowelIdx >= 0) {
            normalized.substring(lastVowelIdx).takeLast(4)
        } else {
            w.takeLast(2)
        }
    }

    fun findRhymesFor(queryWord: String): List<String> {
        val cleaned = queryWord.trim().lowercase().filter { it.isLetter() }
        if (cleaned.isEmpty()) return emptyList()

        val directMatches = builtInRhymeBank.values
            .filter { list -> list.any { it.equals(cleaned, ignoreCase = true) } }
            .flatten()

        val targetKey = computeRhymeKey(cleaned)
        val suffixMatches = builtInRhymeBank.values
            .flatten()
            .filter { candidate ->
                !candidate.equals(cleaned, ignoreCase = true) &&
                    (computeRhymeKey(candidate) == targetKey ||
                        candidate.endsWith(cleaned.takeLast(2)))
            }

        return (directMatches + suffixMatches)
            .filterNot { it.equals(cleaned, ignoreCase = true) }
            .distinct()
            .take(18)
    }
}
