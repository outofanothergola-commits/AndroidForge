package com.example

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.FolderSpecial
import androidx.compose.material.icons.outlined.Lyrics
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MovieCreation
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.FolderSpecial
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ai.configureAppCheck
import com.example.ui.screens.AiStudioScreen
import com.example.ui.screens.BoothScreen
import com.example.ui.screens.LyricPadScreen
import com.example.ui.screens.OwnerLockScreen
import com.example.ui.screens.OwnerSecuritySheet
import com.example.ui.screens.ProjectsScreen
import com.example.ui.screens.VideoStudioScreen
import com.example.ui.screens.VoiceCloneScreen
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CyanWave
import com.example.ui.theme.EmeraldMeter
import com.example.ui.theme.IRapStudioTheme
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioRack
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StudioUiEvent
import com.example.ui.viewmodel.StudioViewModel
import kotlinx.coroutines.launch
import java.io.File

const val ROUTE_AI_STUDIO = "ai_studio"
const val ROUTE_VOICE_CLONE = "voice_clone"
const val ROUTE_BOOTH = "booth"
const val ROUTE_VIDEO_STUDIO = "video_studio"
const val ROUTE_LYRICS = "lyrics"
const val ROUTE_PROJECTS = "projects"

private data class StudioDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
)

private val studioBottomDestinations = listOf(
    StudioDestination(
        route = ROUTE_AI_STUDIO,
        labelRes = R.string.nav_ai_studio,
        selectedIcon = Icons.Rounded.AutoAwesome,
        unselectedIcon = Icons.Outlined.AutoAwesome,
        testTag = "nav_ai_studio",
    ),
    StudioDestination(
        route = ROUTE_VOICE_CLONE,
        labelRes = R.string.nav_voice_clone,
        selectedIcon = Icons.Rounded.RecordVoiceOver,
        unselectedIcon = Icons.Outlined.RecordVoiceOver,
        testTag = "nav_voice_clone",
    ),
    StudioDestination(
        route = ROUTE_BOOTH,
        labelRes = R.string.nav_booth,
        selectedIcon = Icons.Rounded.Mic,
        unselectedIcon = Icons.Outlined.Mic,
        testTag = "nav_booth",
    ),
    StudioDestination(
        route = ROUTE_VIDEO_STUDIO,
        labelRes = R.string.nav_video_studio,
        selectedIcon = Icons.Rounded.MovieCreation,
        unselectedIcon = Icons.Outlined.MovieCreation,
        testTag = "nav_video_studio",
    ),
    StudioDestination(
        route = ROUTE_LYRICS,
        labelRes = R.string.nav_lyrics,
        selectedIcon = Icons.Rounded.Lyrics,
        unselectedIcon = Icons.Outlined.Lyrics,
        testTag = "nav_lyrics",
    ),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            IRapStudioTheme {
                PsychStudioApp(activity = this)
            }
        }
    }
}

@Composable
fun PsychStudioApp(
    activity: ComponentActivity? = null,
    viewModel: StudioViewModel = viewModel(),
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val uiScope = rememberCoroutineScope()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_BOOTH

    var pendingSafMimeType by remember { mutableStateOf("application/octet-stream") }
    var pendingVoiceProfileName by remember { mutableStateOf("") }
    var selectedVideoCoverUri by remember { mutableStateOf<Uri?>(null) }
    var showSecuritySheet by remember { mutableStateOf(false) }

    // Enforce anti-screenshot / anti-recording FLAG_SECURE when enabled by owner
    LaunchedEffect(uiState.ownerSecurity.screenPrivacyShield, activity) {
        activity?.window?.let { window ->
            if (uiState.ownerSecurity.screenPrivacyShield) {
                window.setFlags(
                    WindowManager.LayoutParams.FLAG_SECURE,
                    WindowManager.LayoutParams.FLAG_SECURE,
                )
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }
    }

    // Track foreground/background transitions for auto-lock
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> viewModel.onAppBackgrounded()
                Lifecycle.Event.ON_RESUME -> viewModel.onAppForegrounded()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val deviceCredentialLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.onDeviceCredentialVerified()
        }
    }

    val beatPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            viewModel.attachCustomBeatUri(uri)
        }
    }

    val jsonImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            viewModel.importProjectJson(uri)
        }
    }

    val lyricsTxtImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            viewModel.importLyricsFromUri(uri)
        }
    }

    val voiceSampleImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            viewModel.importVoiceSampleUri(uri, pendingVoiceProfileName)
        }
    }

    val coverArtPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) {
            selectedVideoCoverUri = uri
        }
    }

    val safCreateLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(pendingSafMimeType),
    ) { uri ->
        if (uri != null) {
            viewModel.completePendingSafExport(uri)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is StudioUiEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(event.message)
                }
                is StudioUiEvent.LaunchDocumentCreator -> {
                    pendingSafMimeType = event.mimeType
                    viewModel.suppressNextAutoLockForSystemPicker()
                    safCreateLauncher.launch(event.suggestedName)
                }
                is StudioUiEvent.ShareText -> {
                    viewModel.suppressNextAutoLockForSystemPicker()
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, event.title)
                        putExtra(Intent.EXTRA_TEXT, "${event.title}\n\n${event.text}\n\n— PSYCH☯⚡ (100% Owned by psycho)")
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Lyrics"))
                }
                is StudioUiEvent.ShareFile -> {
                    viewModel.suppressNextAutoLockForSystemPicker()
                    runCatching {
                        val file = File(event.filePath)
                        val contentUri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            file,
                        )
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = event.mimeType
                            putExtra(Intent.EXTRA_SUBJECT, event.title)
                            putExtra(Intent.EXTRA_STREAM, contentUri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, event.title))
                    }.onFailure {
                        snackbarHostState.showSnackbar("Could not open share sheet for media file.")
                    }
                }
            }
        }
    }

    // Strict Single-Owner Access Gate: Zero third-party access without owner verification
    if (!uiState.ownerSecurity.isOwnerClaimed || !uiState.ownerSecurity.isUnlocked) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = StudioObsidian,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        ) { innerPadding ->
            OwnerLockScreen(
                securityState = uiState.ownerSecurity,
                onClaimOwnerPasscode = viewModel::claimOwnerPasscode,
                onVerifyPasscode = viewModel::unlockWithPasscode,
                onTriggerDeviceUnlock = {
                    val intent = viewModel.createDeviceCredentialUnlockIntent()
                    if (intent != null) {
                        viewModel.suppressNextAutoLockForSystemPicker()
                        deviceCredentialLauncher.launch(intent)
                    } else {
                        uiScope.launch {
                            snackbarHostState.showSnackbar("Enable device screen lock in Android Settings or enter your Master PIN.")
                        }
                    }
                },
                modifier = Modifier.padding(innerPadding),
            )
        }
        return
    }

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = StudioObsidian,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                StudioOwnershipHeader(
                    ownerLabel = uiState.ownerSecurity.ownerLabel,
                    projectCount = uiState.projects.size,
                    strictPrivateVault = uiState.ownerSecurity.strictPrivateVault,
                    isVaultSelected = currentRoute == ROUTE_PROJECTS,
                    onOpenVault = {
                        if (currentRoute == ROUTE_PROJECTS) {
                            navController.popBackStack()
                        } else {
                            navigateTo(ROUTE_PROJECTS)
                        }
                    },
                    onOpenSecurity = { showSecuritySheet = true },
                    onLockNow = viewModel::lockStudioNow,
                )
            },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        containerColor = StudioRack,
                        tonalElevation = 0.dp,
                    ) {
                        studioBottomDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes),
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes), maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AmberVu,
                                    selectedTextColor = AmberVu,
                                    indicatorColor = AmberVu.copy(alpha = 0.16f),
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                ),
                                modifier = Modifier.testTag(dest.testTag),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useNavRail) {
                    NavigationRail(
                        containerColor = StudioRack,
                        modifier = Modifier.fillMaxHeight(),
                    ) {
                        val railItems = studioBottomDestinations + StudioDestination(
                            route = ROUTE_PROJECTS,
                            labelRes = R.string.nav_projects,
                            selectedIcon = Icons.Rounded.FolderSpecial,
                            unselectedIcon = Icons.Outlined.FolderSpecial,
                            testTag = "nav_projects",
                        )
                        railItems.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes),
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = AmberVu,
                                    selectedTextColor = AmberVu,
                                    indicatorColor = StudioModule,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                ),
                                modifier = Modifier.testTag(dest.testTag),
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_BOOTH,
                    modifier = Modifier.weight(1f),
                ) {
                    composable(ROUTE_AI_STUDIO) {
                        AiStudioScreen(
                            uiState = uiState,
                            onSelectLanguage = viewModel::setLanguage,
                            onSelectScriptMode = viewModel::setScriptMode,
                            onGenerateSong = viewModel::generateAiSong,
                            onLoadMasterTemplateScaffold = viewModel::loadMasterTemplateScaffold,
                            onLoadOwnLyricsIntoStudio = viewModel::loadCustomLyricsIntoStudio,
                            onImportOwnLyricsTxt = {
                                viewModel.suppressNextAutoLockForSystemPicker()
                                lyricsTxtImportLauncher.launch(arrayOf("text/plain", "text/*"))
                            },
                            onLoadSongIntoBooth = viewModel::loadGeneratedSongIntoStudio,
                            onProduceFullSongWithClone = viewModel::produceCompleteSongWithClonedVoice,
                            onRunCoWriter = viewModel::runAiCoWriter,
                            onAppendCoWriter = viewModel::appendAiAssistToLyrics,
                            onReplaceWithCoWriter = viewModel::replaceLyricsWithAiAssist,
                            onToggleFlowVoicePreview = viewModel::toggleFlowVoicePreview,
                            onOpenBoothTab = { navigateTo(ROUTE_BOOTH) },
                            onOpenLyricsTab = { navigateTo(ROUTE_LYRICS) },
                        )
                    }

                    composable(ROUTE_VOICE_CLONE) {
                        VoiceCloneScreen(
                            uiState = uiState,
                            onSelectLanguage = viewModel::setLanguage,
                            onSelectVoiceProfile = viewModel::selectVoiceProfile,
                            onToggleRecordVoiceSample = viewModel::toggleRecordVoiceSample,
                            onImportVoiceSample = { profileName ->
                                pendingVoiceProfileName = profileName
                                viewModel.suppressNextAutoLockForSystemPicker()
                                voiceSampleImportLauncher.launch(arrayOf("audio/*"))
                            },
                            onCloneProfileFromTake = viewModel::cloneProfileFromTake,
                            onDeleteVoiceProfile = viewModel::deleteVoiceProfile,
                            onSelectClarityMode = viewModel::selectVocalClarityMode,
                            onUpdateClarityBoost = viewModel::updateVocalClarityBoost,
                            onGenerateClonedVoiceFromLyrics = viewModel::generateClonedVoiceTrack,
                            onMorphTakeWithClone = viewModel::morphTakeIntoClonedVoice,
                            onToggleTakePlay = viewModel::toggleTakePlayback,
                            onInspectTakeDetails = viewModel::inspectTakeAudioDetails,
                            onDismissAudioDetails = viewModel::dismissAudioDetails,
                            onExportTake = viewModel::exportTakeAudio,
                            onOpenBoothTab = { navigateTo(ROUTE_BOOTH) },
                            onOpenVideoTab = { navigateTo(ROUTE_VIDEO_STUDIO) },
                        )
                    }

                    composable(ROUTE_BOOTH) {
                        BoothScreen(
                            uiState = uiState,
                            onToggleBeat = viewModel::toggleBeatPlayback,
                            onSelectBeatStyle = viewModel::selectBeatStyle,
                            onUpdateBpm = viewModel::updateBpm,
                            onImportCustomBeat = {
                                viewModel.suppressNextAutoLockForSystemPicker()
                                beatPickerLauncher.launch(arrayOf("audio/*"))
                            },
                            onUpdateMixer = viewModel::updateMixer,
                            onSelectVocalPreset = viewModel::selectVocalPreset,
                            onSelectPcmFormat = viewModel::selectPcmFormat,
                            onSelectMasteringProfile = viewModel::selectMasteringProfile,
                            onSelectVocalClarityMode = viewModel::selectVocalClarityMode,
                            onUpdateVocalClarityBoost = viewModel::updateVocalClarityBoost,
                            onInspectTakeDetails = viewModel::inspectTakeAudioDetails,
                            onDismissAudioDetails = viewModel::dismissAudioDetails,
                            onSelectTrackMinutes = viewModel::updateTrackMinutes,
                            onSelectVocalStyle = viewModel::updateVocalStyle,
                            onBounceInstrumental = viewModel::bounceInstrumentalForDuration,
                            onToggleRecord = viewModel::toggleRecording,
                            onToggleTakePlay = viewModel::toggleTakePlayback,
                            onMixTakeWithBeat = viewModel::mixTakeWithBeat,
                            onExportTake = viewModel::exportTakeAudio,
                            onDeleteTake = viewModel::deleteTake,
                            onRenameActiveProject = viewModel::renameActiveProject,
                            onToggleFlowVoicePreview = viewModel::toggleFlowVoicePreview,
                            onOpenLyricsTab = { navigateTo(ROUTE_LYRICS) },
                        )
                    }

                    composable(ROUTE_VIDEO_STUDIO) {
                        VideoStudioScreen(
                            uiState = uiState,
                            coverImageUri = selectedVideoCoverUri,
                            onPickCoverArt = {
                                viewModel.suppressNextAutoLockForSystemPicker()
                                coverArtPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                                )
                            },
                            onClearCoverArt = { selectedVideoCoverUri = null },
                            onToggleTakePlay = viewModel::toggleTakePlayback,
                            onToggleBeat = viewModel::toggleBeatPlayback,
                            onRenderVideo = viewModel::renderLyricalVideo,
                            onExportVideoMp4 = viewModel::exportGeneratedVideoMp4,
                            onShareVideoMp4 = viewModel::shareGeneratedVideoMp4,
                        )
                    }

                    composable(ROUTE_LYRICS) {
                        LyricPadScreen(
                            uiState = uiState,
                            onLyricsChange = viewModel::updateLyrics,
                            onInsertSection = viewModel::insertSectionTag,
                            onCopyLyrics = viewModel::copyLyricsToClipboard,
                            onExportLyricsTxt = viewModel::exportLyricsTxt,
                            onShareLyrics = viewModel::shareLyrics,
                            onRhymeQueryChange = viewModel::updateRhymeQuery,
                            onSelectLanguage = viewModel::setLanguage,
                            onToggleFlowVoicePreview = viewModel::toggleFlowVoicePreview,
                            onSelectTrackMinutes = viewModel::updateTrackMinutes,
                            onInsertMasterTemplate = {
                                val proj = uiState.activeProject
                                viewModel.loadMasterTemplateScaffold(
                                    title = proj?.title.orEmpty(),
                                    genre = proj?.beatStyle ?: "Trap",
                                    mood = "Motivational",
                                    bpm = proj?.bpm ?: 94,
                                    vocalStyle = proj?.vocalStyle ?: "Deep",
                                    trackMinutes = proj?.trackMinutes ?: 3,
                                )
                            },
                            onPasteLyrics = viewModel::pasteLyricsToPad,
                            onImportLyricsTxt = {
                                viewModel.suppressNextAutoLockForSystemPicker()
                                lyricsTxtImportLauncher.launch(arrayOf("text/plain", "text/*"))
                            },
                            onClearLyrics = viewModel::clearLyricsPad,
                            onOpenBoothTab = { navigateTo(ROUTE_BOOTH) },
                        )
                    }

                    composable(ROUTE_PROJECTS) {
                        ProjectsScreen(
                            uiState = uiState,
                            onSelectProject = { project ->
                                viewModel.selectProject(project.id)
                                navigateTo(ROUTE_BOOTH)
                            },
                            onCreateProject = { title, bpm, style ->
                                viewModel.createProject(title, bpm, style)
                                navigateTo(ROUTE_BOOTH)
                            },
                            onRenameProject = viewModel::renameProject,
                            onDuplicateProject = viewModel::duplicateProject,
                            onDeleteProject = viewModel::deleteProject,
                            onExportProjectJson = viewModel::exportProjectJson,
                            onImportProjectJson = {
                                viewModel.suppressNextAutoLockForSystemPicker()
                                jsonImportLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                            },
                        )
                    }
                }
            }
        }
    }

    if (showSecuritySheet) {
        OwnerSecuritySheet(
            securityState = uiState.ownerSecurity,
            onDismiss = { showSecuritySheet = false },
            onLockNow = viewModel::lockStudioNow,
            onSetScreenShield = viewModel::setScreenPrivacyShield,
            onSetStrictPrivateVault = viewModel::setStrictPrivateVault,
            onSetBiometricUnlock = viewModel::setBiometricUnlockEnabled,
            onSetAutoLock = viewModel::setAutoLockBackground,
            onUpdateOwnerLabel = viewModel::updateOwnerLabel,
            onChangePasscode = viewModel::updateOwnerPasscode,
        )
    }
}

@Composable
private fun StudioOwnershipHeader(
    ownerLabel: String,
    projectCount: Int,
    strictPrivateVault: Boolean,
    isVaultSelected: Boolean,
    onOpenVault: () -> Unit,
    onOpenSecurity: () -> Unit,
    onLockNow: () -> Unit,
) {
    Surface(
        color = StudioRack,
        tonalElevation = 0.dp,
        border = BorderStroke(0.5.dp, StudioStroke.copy(alpha = 0.6f)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioRack)
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "PSYCH☯⚡",
                    style = MaterialTheme.typography.titleMedium,
                    color = AmberVu,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                )
                Text(
                    text = "100% Owned by $ownerLabel",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Surface(
                    color = if (isVaultSelected) AmberVu.copy(alpha = 0.2f) else StudioModuleElevated,
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(
                        1.dp,
                        if (isVaultSelected) AmberVu else StudioStroke,
                    ),
                    modifier = Modifier
                        .clickable { onOpenVault() }
                        .minimumInteractiveComponentSize()
                        .testTag("open_vault_button"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FolderSpecial,
                            contentDescription = "Open Project Vault",
                            tint = if (isVaultSelected) AmberVu else CyanWave,
                            modifier = Modifier.size(16.dp),
                        )
                        Text(
                            text = "Vault ($projectCount)",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isVaultSelected) AmberVu else TextPrimary,
                        )
                    }
                }

                Surface(
                    color = if (strictPrivateVault) EmeraldMeter.copy(alpha = 0.14f) else AmberVu.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(
                        1.dp,
                        if (strictPrivateVault) EmeraldMeter.copy(alpha = 0.55f) else AmberVu.copy(alpha = 0.55f),
                    ),
                    modifier = Modifier
                        .clickable { onOpenSecurity() }
                        .minimumInteractiveComponentSize()
                        .testTag("owner_security_button"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = "Owner Security Controls",
                            tint = if (strictPrivateVault) EmeraldMeter else AmberVu,
                            modifier = Modifier.size(16.dp),
                        )
                        Text(
                            text = if (strictPrivateVault) "Private" else "Export On",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (strictPrivateVault) EmeraldMeter else AmberVu,
                        )
                    }
                }

                IconButton(
                    onClick = onLockNow,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("header_lock_now_button"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "Lock studio",
                        tint = AmberVu,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }
    }
}
