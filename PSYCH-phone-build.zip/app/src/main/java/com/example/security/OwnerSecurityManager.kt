package com.example.security

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class OwnerSecurityState(
    val isOwnerClaimed: Boolean = false,
    val isUnlocked: Boolean = false,
    val ownerLabel: String = "psycho (Owner)",
    val screenPrivacyShield: Boolean = false,
    val strictPrivateVault: Boolean = true,
    val biometricUnlockEnabled: Boolean = true,
    val autoLockBackground: Boolean = true,
    val isDeviceSecureAvailable: Boolean = false,
    val failedAttempts: Int = 0,
    val lockoutUntilMs: Long = 0L,
)

/**
 * Single-Owner Exclusive Access Controller for PSYCH☯⚡.
 * - First-run atomic owner passcode claim (zero hardcoded credentials)
 * - PBKDF2WithHmacSHA256 (120,000 iterations + 16-byte SecureRandom salt)
 * - Constant-time hash comparison + brute-force exponential cooldown
 * - Device biometric / screen-lock credential unlock via KeyguardManager
 * - Privacy controls: FLAG_SECURE screenshot shield & Strict Private Vault export/share lock
 */
class OwnerSecurityManager(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val keyguardManager = appContext.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

    private val _state = MutableStateFlow(loadInitialState())
    val state: StateFlow<OwnerSecurityState> = _state.asStateFlow()

    @Volatile
    private var lastBackgroundTimestampMs: Long = 0L

    @Volatile
    private var suppressAutoLockOnce: Boolean = false

    private fun loadInitialState(): OwnerSecurityState {
        val claimed = prefs.contains(KEY_PASSCODE_HASH) && prefs.contains(KEY_PASSCODE_SALT)
        val deviceSecure = keyguardManager.isDeviceSecure
        return OwnerSecurityState(
            isOwnerClaimed = claimed,
            isUnlocked = false,
            ownerLabel = prefs.getString(KEY_OWNER_LABEL, DEFAULT_OWNER_LABEL) ?: DEFAULT_OWNER_LABEL,
            screenPrivacyShield = prefs.getBoolean(KEY_SCREEN_SHIELD, false),
            strictPrivateVault = prefs.getBoolean(KEY_STRICT_PRIVATE, true),
            biometricUnlockEnabled = prefs.getBoolean(KEY_BIOMETRIC_ENABLED, true),
            autoLockBackground = prefs.getBoolean(KEY_AUTO_LOCK, true),
            isDeviceSecureAvailable = deviceSecure,
            failedAttempts = prefs.getInt(KEY_FAILED_ATTEMPTS, 0),
            lockoutUntilMs = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L),
        )
    }

    fun claimOwnerPasscode(
        passcode: String,
        ownerLabel: String,
    ): Result<Unit> {
        if (_state.value.isOwnerClaimed) {
            return Result.failure(IllegalStateException("Owner lock is already claimed."))
        }
        val cleanPass = passcode.trim()
        if (cleanPass.length < 4) {
            return Result.failure(IllegalArgumentException("Enter at least 4 digits/characters for your Owner PIN."))
        }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = deriveHash(cleanPass, salt)
        val cleanOwner = ownerLabel.trim().ifBlank { DEFAULT_OWNER_LABEL }

        prefs.edit()
            .putString(KEY_PASSCODE_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .putString(KEY_PASSCODE_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_OWNER_LABEL, cleanOwner)
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .commit()

        _state.value = _state.value.copy(
            isOwnerClaimed = true,
            isUnlocked = true,
            ownerLabel = cleanOwner,
            failedAttempts = 0,
            lockoutUntilMs = 0L,
        )
        return Result.success(Unit)
    }

    fun verifyPasscode(passcode: String): Result<Unit> {
        val now = System.currentTimeMillis()
        val current = _state.value
        if (current.lockoutUntilMs > now) {
            val secLeft = ((current.lockoutUntilMs - now) / 1000L + 1L).coerceAtLeast(1L)
            return Result.failure(IllegalStateException("Too many attempts. Wait ${secLeft}s before retrying."))
        }

        val storedHashB64 = prefs.getString(KEY_PASSCODE_HASH, null)
            ?: return Result.failure(IllegalStateException("Owner passcode not configured yet."))
        val storedSaltB64 = prefs.getString(KEY_PASSCODE_SALT, null)
            ?: return Result.failure(IllegalStateException("Owner salt missing."))

        val storedHash = Base64.decode(storedHashB64, Base64.NO_WRAP)
        val storedSalt = Base64.decode(storedSaltB64, Base64.NO_WRAP)
        val candidateHash = deriveHash(passcode.trim(), storedSalt)

        return if (MessageDigest.isEqual(storedHash, candidateHash)) {
            prefs.edit()
                .putInt(KEY_FAILED_ATTEMPTS, 0)
                .putLong(KEY_LOCKOUT_UNTIL, 0L)
                .commit()
            _state.value = _state.value.copy(
                isUnlocked = true,
                failedAttempts = 0,
                lockoutUntilMs = 0L,
            )
            Result.success(Unit)
        } else {
            val nextFailed = current.failedAttempts + 1
            val lockoutMs = if (nextFailed >= 5) {
                now + 30_000L * (nextFailed - 4).coerceAtMost(4)
            } else {
                0L
            }
            prefs.edit()
                .putInt(KEY_FAILED_ATTEMPTS, nextFailed)
                .putLong(KEY_LOCKOUT_UNTIL, lockoutMs)
                .commit()
            _state.value = _state.value.copy(
                failedAttempts = nextFailed,
                lockoutUntilMs = lockoutMs,
            )
            val msg = if (lockoutMs > 0L) {
                "Incorrect Owner PIN. Locked for 30s to block unauthorized access."
            } else {
                "Incorrect Owner PIN (${5 - nextFailed} tries left before cooldown)."
            }
            Result.failure(IllegalArgumentException(msg))
        }
    }

    fun updatePasscode(currentPasscode: String, newPasscode: String): Result<Unit> {
        if (!_state.value.isUnlocked) {
            return Result.failure(IllegalStateException("Unlock studio first."))
        }
        val verified = verifyPasscode(currentPasscode)
        if (verified.isFailure) return verified

        val cleanNew = newPasscode.trim()
        if (cleanNew.length < 4) {
            return Result.failure(IllegalArgumentException("New PIN must be at least 4 characters."))
        }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = deriveHash(cleanNew, salt)
        prefs.edit()
            .putString(KEY_PASSCODE_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .putString(KEY_PASSCODE_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .commit()
        return Result.success(Unit)
    }

    @Suppress("DEPRECATION")
    fun createDeviceCredentialUnlockIntent(): Intent? {
        if (!keyguardManager.isDeviceSecure) return null
        return keyguardManager.createConfirmDeviceCredentialIntent(
            "PSYCH☯⚡ Owner Verification",
            "Verify your device fingerprint, face, or screen lock to access your private studio.",
        )
    }

    fun onDeviceCredentialVerified() {
        prefs.edit()
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .commit()
        _state.value = _state.value.copy(
            isUnlocked = true,
            failedAttempts = 0,
            lockoutUntilMs = 0L,
        )
    }

    fun lockNow() {
        if (_state.value.isOwnerClaimed) {
            _state.value = _state.value.copy(isUnlocked = false)
        }
    }

    fun suppressNextAutoLockForSystemPicker() {
        suppressAutoLockOnce = true
    }

    fun onAppBackgrounded() {
        lastBackgroundTimestampMs = System.currentTimeMillis()
    }

    fun onAppForegrounded() {
        val current = _state.value
        val deviceSecure = keyguardManager.isDeviceSecure
        if (current.isDeviceSecureAvailable != deviceSecure) {
            _state.value = current.copy(isDeviceSecureAvailable = deviceSecure)
        }
        if (suppressAutoLockOnce) {
            suppressAutoLockOnce = false
            return
        }
        if (current.isOwnerClaimed && current.autoLockBackground && current.isUnlocked && lastBackgroundTimestampMs > 0L) {
            val awayMs = System.currentTimeMillis() - lastBackgroundTimestampMs
            if (awayMs > 15_000L) {
                _state.value = _state.value.copy(isUnlocked = false)
            }
        }
    }

    fun setScreenPrivacyShield(enabled: Boolean) {
        if (!_state.value.isUnlocked && _state.value.isOwnerClaimed) return
        prefs.edit().putBoolean(KEY_SCREEN_SHIELD, enabled).commit()
        _state.value = _state.value.copy(screenPrivacyShield = enabled)
    }

    fun setStrictPrivateVault(enabled: Boolean) {
        if (!_state.value.isUnlocked && _state.value.isOwnerClaimed) return
        prefs.edit().putBoolean(KEY_STRICT_PRIVATE, enabled).commit()
        _state.value = _state.value.copy(strictPrivateVault = enabled)
    }

    fun setBiometricUnlockEnabled(enabled: Boolean) {
        if (!_state.value.isUnlocked && _state.value.isOwnerClaimed) return
        prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).commit()
        _state.value = _state.value.copy(biometricUnlockEnabled = enabled)
    }

    fun setAutoLockBackground(enabled: Boolean) {
        if (!_state.value.isUnlocked && _state.value.isOwnerClaimed) return
        prefs.edit().putBoolean(KEY_AUTO_LOCK, enabled).commit()
        _state.value = _state.value.copy(autoLockBackground = enabled)
    }

    fun updateOwnerLabel(label: String) {
        if (!_state.value.isUnlocked && _state.value.isOwnerClaimed) return
        val clean = label.trim().ifBlank { DEFAULT_OWNER_LABEL }
        prefs.edit().putString(KEY_OWNER_LABEL, clean).commit()
        _state.value = _state.value.copy(ownerLabel = clean)
    }

    private fun deriveHash(passcode: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(passcode.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    companion object {
        private const val PREFS_NAME = "psych_owner_vault_security"
        private const val KEY_PASSCODE_HASH = "owner_passcode_hash"
        private const val KEY_PASSCODE_SALT = "owner_passcode_salt"
        private const val KEY_OWNER_LABEL = "owner_label"
        private const val KEY_SCREEN_SHIELD = "screen_shield_enabled"
        private const val KEY_STRICT_PRIVATE = "strict_private_vault"
        private const val KEY_BIOMETRIC_ENABLED = "biometric_unlock_enabled"
        private const val KEY_AUTO_LOCK = "auto_lock_bg"
        private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
        private const val KEY_LOCKOUT_UNTIL = "lockout_until"
        private const val DEFAULT_OWNER_LABEL = "psycho (Owner)"
        private const val PBKDF2_ITERATIONS = 120_000
    }
}
