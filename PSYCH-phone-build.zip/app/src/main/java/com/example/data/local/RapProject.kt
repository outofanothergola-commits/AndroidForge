package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class RapProject(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val bpm: Int = 92,
    val beatStyle: String = BeatStyle.TRAP_808.name,
    val lyrics: String = "",
    val languageCode: String = "en",
    val chordProgression: String = "Cm - Ab - Fm - G",
    val vocalPreset: String = VocalPreset.WARM_BOOTH.name,
    val vocalStyle: String = VocalDeliveryStyle.DEEP.displayName,
    val trackMinutes: Int = 3,
    val customBeatUri: String? = null,
    val customBeatName: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

enum class VocalDeliveryStyle(val displayName: String) {
    DEEP("Deep"),
    MELODIC("Melodic"),
    RASPY("Raspy"),
    AGGRESSIVE("Aggressive"),
    CHOPPER("Fast Chopper"),
}

enum class BeatStyle(
    val displayName: String,
    val defaultBpm: Int,
    val tag: String,
) {
    TRAP_808("Trap", 136, "Sub + Bell Keys"),
    BOOM_BAP("Boom Bap", 92, "Rhodes + Live Kit"),
    DESI_TRAP("Desi Trap", 130, "Tabla + 808 + Pluck"),
    BIHU_FOLK_FUSION("Folk Fusion", 118, "Dholak + String Groove"),
    DRILL("Drill", 142, "Slide Sub + Piano"),
    LO_FI_SOUL("Melodic / Lo-Fi", 84, "Warm Rhodes + Vinyl"),
    AFRO_BOUNCE("Afro Bounce", 104, "Rimshot + Marimba"),
    ORCHESTRAL_CINEMATIC("Orchestral", 96, "Brass + Strings + Pad"),
    PHONK_MEMPHIS("Phonk", 128, "Cowbell + Distorted 808"),
    METRONOME("Click", 100, "Pure 4/4 Tempo"),
    CUSTOM("Custom", 100, "Imported Audio"),
    ;

    companion object {
        fun fromName(name: String): BeatStyle =
            when (name) {
                "LO_FI" -> LO_FI_SOUL
                else -> entries.firstOrNull { it.name == name } ?: TRAP_808
            }
    }
}

enum class VocalPreset(
    val displayName: String,
    val subtitle: String,
    val lowDb: Short,
    val midDb: Short,
    val highDb: Short,
    val reverbPreset: Short,
    val bassBoostStrength: Short,
) {
    RAW_MIC("Raw Mic", "Uncolored studio mic", 0, 0, 0, 0, 0),
    WARM_BOOTH("Warm Booth", "Presence + treated room", 200, 350, 300, 1, 200),
    CRISPY_TRAP("Crispy Lead", "Bright air + tight lows", -200, 300, 600, 2, 100),
    ARENA_ANTHEM("Arena Hall", "Big anthem reverb + punch", 350, 250, 450, 4, 350),
    LOFI_RADIO("Vintage Tape", "Focused analog mid-range", -400, 500, -350, 1, 0),
    ;

    companion object {
        fun fromName(name: String): VocalPreset =
            entries.firstOrNull { it.name == name } ?: WARM_BOOTH
    }
}
