package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RapStudioDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeAllProjects(): Flow<List<RapProject>>

    @Query("SELECT * FROM projects WHERE id = :projectId LIMIT 1")
    fun observeProject(projectId: Long): Flow<RapProject?>

    @Query("SELECT * FROM projects WHERE id = :projectId LIMIT 1")
    suspend fun getProjectById(projectId: Long): RapProject?

    @Query("SELECT COUNT(*) FROM projects")
    suspend fun getProjectCount(): Int

    @Query("SELECT id FROM projects ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getMostRecentProjectId(): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: RapProject): Long

    @Update
    suspend fun updateProject(project: RapProject)

    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun deleteProjectById(projectId: Long)

    @Query("SELECT * FROM vocal_takes WHERE projectId = :projectId ORDER BY createdAt DESC")
    fun observeTakesForProject(projectId: Long): Flow<List<VocalTake>>

    @Query("SELECT * FROM vocal_takes WHERE projectId = :projectId")
    suspend fun getTakesForProjectSync(projectId: Long): List<VocalTake>

    @Query("SELECT projectId, COUNT(*) as takeCount FROM vocal_takes GROUP BY projectId")
    fun observeTakeCounts(): Flow<List<ProjectTakeCount>>

    @Query("SELECT COUNT(*) FROM vocal_takes WHERE projectId = :projectId")
    suspend fun getTakeCountForProject(projectId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTake(take: VocalTake): Long

    @Query("DELETE FROM vocal_takes WHERE id = :takeId")
    suspend fun deleteTakeById(takeId: Long)

    @Query("SELECT * FROM voice_profiles ORDER BY isPreset ASC, createdAt DESC")
    fun observeAllVoiceProfiles(): Flow<List<VoiceProfile>>

    @Query("SELECT COUNT(*) FROM voice_profiles")
    suspend fun getVoiceProfileCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVoiceProfile(profile: VoiceProfile): Long

    @Update
    suspend fun updateVoiceProfile(profile: VoiceProfile)

    @Query("DELETE FROM voice_profiles WHERE id = :profileId")
    suspend fun deleteVoiceProfileById(profileId: Long)
}

data class ProjectTakeCount(
    val projectId: Long,
    val takeCount: Int,
)
