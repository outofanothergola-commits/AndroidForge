package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [RapProject::class, VocalTake::class, VoiceProfile::class],
    version = 5,
    exportSchema = false,
)
abstract class RapStudioDatabase : RoomDatabase() {
    abstract fun rapStudioDao(): RapStudioDao

    companion object {
        @Volatile
        private var instance: RapStudioDatabase? = null

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE voice_profiles ADD COLUMN spectralEnvelopeCsv TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE voice_profiles ADD COLUMN pitchVarianceHz REAL NOT NULL DEFAULT 18.0")
            }
        }

        fun getInstance(context: Context): RapStudioDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    RapStudioDatabase::class.java,
                    "irapstudio_db",
                )
                    .addMigrations(MIGRATION_4_5)
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { instance = it }
            }
        }
    }
}
