package com.example.data

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.example.data.local.BeatStyle
import com.example.data.local.ProjectTakeCount
import com.example.data.local.RapProject
import com.example.data.local.RapStudioDao
import com.example.data.local.VocalPreset
import com.example.data.local.VocalProfileHelpers
import com.example.data.local.VocalTake
import com.example.data.local.VoiceProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets

sealed interface ExportOutcome {
    data class SavedToDevice(val locationLabel: String) : ExportOutcome
    data class NeedsDocumentPicker(
        val suggestedName: String,
        val mimeType: String,
        val contentBytes: ByteArray? = null,
        val sourceFile: File? = null,
    ) : ExportOutcome

    data class Failure(val reason: String) : ExportOutcome
}

class RapStudioRepository(
    private val context: Context,
    private val dao: RapStudioDao,
) {
    val allProjects: Flow<List<RapProject>> = dao.observeAllProjects()
    val takeCounts: Flow<List<ProjectTakeCount>> = dao.observeTakeCounts()

    fun observeProject(projectId: Long): Flow<RapProject?> = dao.observeProject(projectId)

    fun observeTakesForProject(projectId: Long): Flow<List<VocalTake>> =
        dao.observeTakesForProject(projectId)

    suspend fun ensureInitialProject(): Long {
        val existingId = dao.getMostRecentProjectId()
        if (existingId != null) return existingId
        val now = System.currentTimeMillis()
        return dao.insertProject(
            RapProject(
                title = "Session 01",
                bpm = BeatStyle.TRAP_808.defaultBpm,
                beatStyle = BeatStyle.TRAP_808.name,
                lyrics = "",
                languageCode = "en",
                chordProgression = "Cm - Ab - Fm - G",
                vocalPreset = VocalPreset.WARM_BOOTH.name,
                createdAt = now,
                updatedAt = now,
            ),
        )
    }

    suspend fun createProject(
        title: String,
        bpm: Int,
        beatStyle: BeatStyle,
        lyrics: String = "",
        languageCode: String = "en",
        chordProgression: String = "Cm - Ab - Fm - G",
        vocalStyle: String = "Deep",
        trackMinutes: Int = 3,
    ): Long {
        val now = System.currentTimeMillis()
        return dao.insertProject(
            RapProject(
                title = title.trim().ifEmpty { "Untitled Track" },
                bpm = bpm.coerceIn(60, 180),
                beatStyle = beatStyle.name,
                lyrics = lyrics,
                languageCode = languageCode,
                chordProgression = chordProgression,
                vocalPreset = VocalPreset.WARM_BOOTH.name,
                vocalStyle = vocalStyle,
                trackMinutes = trackMinutes,
                createdAt = now,
                updatedAt = now,
            ),
        )
    }

    suspend fun updateProject(project: RapProject) {
        dao.updateProject(project.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun duplicateProject(project: RapProject): Long {
        val now = System.currentTimeMillis()
        return dao.insertProject(
            project.copy(
                id = 0L,
                title = "${project.title} (Copy)",
                createdAt = now,
                updatedAt = now,
            ),
        )
    }

    suspend fun deleteProject(projectId: Long) {
        val takes = dao.getTakesForProjectSync(projectId)
        if (takes.isNotEmpty()) {
            withContext(Dispatchers.IO) {
                takes.forEach { take -> runCatching { File(take.filePath).delete() } }
            }
        }
        dao.deleteProjectById(projectId)
    }

    suspend fun addTake(
        projectId: Long,
        filePath: String,
        durationMs: Long,
        prefix: String = "Take",
    ): Long {
        val count = dao.getTakeCountForProject(projectId) + 1
        return dao.insertTake(
            VocalTake(
                projectId = projectId,
                title = "$prefix ${count.toString().padStart(2, '0')}",
                filePath = filePath,
                durationMs = durationMs,
            ),
        )
    }

    suspend fun deleteTake(take: VocalTake) {
        withContext(Dispatchers.IO) {
            runCatching { File(take.filePath).delete() }
        }
        dao.deleteTakeById(take.id)
    }

    val allVoiceProfiles: Flow<List<VoiceProfile>> = dao.observeAllVoiceProfiles()

    suspend fun ensureInitialVoiceProfiles() {
        if (dao.getVoiceProfileCount() == 0) {
            VocalProfileHelpers.starterProfiles().forEach { profile ->
                dao.insertVoiceProfile(profile)
            }
        }
    }

    suspend fun insertVoiceProfile(profile: VoiceProfile): Long = dao.insertVoiceProfile(profile)

    suspend fun deleteVoiceProfile(profile: VoiceProfile) {
        if (profile.sampleFilePath.isNotBlank()) {
            withContext(Dispatchers.IO) {
                runCatching { File(profile.sampleFilePath).delete() }
            }
        }
        dao.deleteVoiceProfileById(profile.id)
    }

    suspend fun copyAudioSampleFromUri(uri: Uri): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "voice_samples").apply { mkdirs() }
            val ext = (resolveDisplayName(uri)?.substringAfterLast('.', "m4a") ?: "m4a")
                .take(8)
                .ifBlank { "m4a" }
            val outFile = File(dir, "sample_${System.currentTimeMillis()}.$ext")
            context.contentResolver.openInputStream(uri)?.use { input ->
                outFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: error("Could not read selected audio sample")
            outFile
        }
    }

    fun copyTextToClipboard(value: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("PSYCH☯⚡ Lyrics", value)
        clipboard.setPrimaryClip(clip)
    }

    fun readTextFromClipboard(): String? {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(context)?.toString()?.takeIf { it.isNotBlank() }
    }

    suspend fun readLyricsTextFromUri(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.readBytes()
            } ?: error("Could not read selected text file")
            require(bytes.size <= 512 * 1024) { "Lyrics file is too large (max 512 KB)." }
            bytes.toString(StandardCharsets.UTF_8).trim()
        }
    }

    fun serializeProjectToJson(project: RapProject): String {
        val json = JSONObject().apply {
            put("app", "PSYCH☯⚡")
            put("owner", "psycho")
            put("ownership", "100% Owner Controlled — Private Vault")
            put("version", 4)
            put("title", project.title)
            put("bpm", project.bpm)
            put("beatStyle", project.beatStyle)
            put("languageCode", project.languageCode)
            put("chordProgression", project.chordProgression)
            put("vocalPreset", project.vocalPreset)
            put("vocalStyle", project.vocalStyle)
            put("trackMinutes", project.trackMinutes)
            put("lyrics", project.lyrics)
            put("updatedAt", project.updatedAt)
        }
        return json.toString(2)
    }

    suspend fun importProjectFromUri(uri: Uri): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.readBytes().toString(StandardCharsets.UTF_8)
            } ?: error("Could not read selected file")

            val json = JSONObject(raw)
            val title = json.optString("title").ifBlank {
                resolveDisplayName(uri)?.removeSuffix(".json") ?: "Imported Track"
            }
            val bpm = json.optInt("bpm", 92).coerceIn(60, 180)
            val style = BeatStyle.fromName(json.optString("beatStyle", BeatStyle.TRAP_808.name))
            val languageCode = json.optString("languageCode", "en")
            val chordProgression = json.optString("chordProgression", "Cm - Ab - Fm - G")
            val vocalPreset = VocalPreset.fromName(json.optString("vocalPreset", VocalPreset.WARM_BOOTH.name)).name
            val vocalStyle = json.optString("vocalStyle", "Deep")
            val trackMinutes = json.optInt("trackMinutes", 3)
            val lyrics = json.optString("lyrics", "")
            val now = System.currentTimeMillis()
            dao.insertProject(
                RapProject(
                    title = title,
                    bpm = bpm,
                    beatStyle = style.name,
                    lyrics = lyrics,
                    languageCode = languageCode,
                    chordProgression = chordProgression,
                    vocalPreset = vocalPreset,
                    vocalStyle = vocalStyle,
                    trackMinutes = trackMinutes,
                    createdAt = now,
                    updatedAt = now,
                ),
            )
        }
    }

    fun resolveDisplayName(uri: Uri): String? {
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) return cursor.getString(idx)
                    }
                }
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    suspend fun exportAudioTake(take: VocalTake, projectTitle: String): ExportOutcome =
        withContext(Dispatchers.IO) {
            val sourceFile = File(take.filePath)
            if (!sourceFile.exists()) {
                return@withContext ExportOutcome.Failure("Recording file not found on device.")
            }
            val isWav = sourceFile.extension.equals("wav", ignoreCase = true)
            val ext = if (isWav) "wav" else "m4a"
            val mime = if (isWav) "audio/wav" else "audio/mp4"
            val safeName = sanitizeFileName("${projectTitle}_${take.title}") + ".$ext"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                runCatching {
                    val values = ContentValues().apply {
                        put(MediaStore.Audio.Media.DISPLAY_NAME, safeName)
                        put(MediaStore.Audio.Media.MIME_TYPE, mime)
                        put(
                            MediaStore.Audio.Media.RELATIVE_PATH,
                            "${Environment.DIRECTORY_MUSIC}/PSYCH",
                        )
                        put(MediaStore.Audio.Media.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                        ?: error("MediaStore insert failed")
                    resolver.openOutputStream(uri)?.use { out ->
                        sourceFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                        out.flush()
                    } ?: error("Cannot open audio output stream")
                    values.clear()
                    values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    ExportOutcome.SavedToDevice("Music/PSYCH/$safeName")
                }.getOrElse {
                    ExportOutcome.NeedsDocumentPicker(safeName, mime, sourceFile = sourceFile)
                }
            } else {
                ExportOutcome.NeedsDocumentPicker(safeName, mime, sourceFile = sourceFile)
            }
        }

    suspend fun exportVideoMp4(videoFile: File, projectTitle: String): ExportOutcome =
        withContext(Dispatchers.IO) {
            if (!videoFile.exists()) {
                return@withContext ExportOutcome.Failure("Generated MP4 video file not found.")
            }
            val safeName = sanitizeFileName("${projectTitle}_LyricalVideo") + ".mp4"
            val mime = "video/mp4"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                runCatching {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, safeName)
                        put(MediaStore.Video.Media.MIME_TYPE, mime)
                        put(
                            MediaStore.Video.Media.RELATIVE_PATH,
                            "${Environment.DIRECTORY_MOVIES}/PSYCH",
                        )
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                        ?: error("MediaStore video insert failed")
                    resolver.openOutputStream(uri)?.use { out ->
                        videoFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                        out.flush()
                    } ?: error("Cannot open video output stream")
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    ExportOutcome.SavedToDevice("Movies/PSYCH/$safeName")
                }.getOrElse {
                    ExportOutcome.NeedsDocumentPicker(safeName, mime, sourceFile = videoFile)
                }
            } else {
                ExportOutcome.NeedsDocumentPicker(safeName, mime, sourceFile = videoFile)
            }
        }

    suspend fun exportDocumentText(fileName: String, mimeType: String, content: String): ExportOutcome =
        withContext(Dispatchers.IO) {
            val safeName = sanitizeFileName(fileName.substringBeforeLast('.')) +
                "." + fileName.substringAfterLast('.', "txt")
            val bytes = content.toByteArray(StandardCharsets.UTF_8)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                runCatching {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                        put(
                            MediaStore.MediaColumns.RELATIVE_PATH,
                            "${Environment.DIRECTORY_DOCUMENTS}/PSYCH",
                        )
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    val uri = resolver.insert(collection, values)
                        ?: error("MediaStore document insert failed")
                    resolver.openOutputStream(uri)?.use { out ->
                        out.write(bytes)
                        out.flush()
                    } ?: error("Cannot open document output stream")
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    ExportOutcome.SavedToDevice("Documents/PSYCH/$safeName")
                }.getOrElse {
                    ExportOutcome.NeedsDocumentPicker(safeName, mimeType, bytes)
                }
            } else {
                ExportOutcome.NeedsDocumentPicker(safeName, mimeType, bytes)
            }
        }

    suspend fun writeBytesToUri(uri: Uri, bytes: ByteArray): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(bytes)
                    out.flush()
                } ?: error("Failed to open destination file")
            }
        }

    suspend fun writeFileToUri(uri: Uri, sourceFile: File): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(out)
                    }
                    out.flush()
                } ?: error("Failed to open destination file")
            }
        }

    private fun sanitizeFileName(raw: String): String {
        val cleaned = raw.replace(Regex("[^a-zA-Z0-9._-]+"), "_").trim('_')
        return cleaned.ifBlank { "PSYCH_file" }
    }
}
