package com.example.data

data class RapStyleCategory(
    val id: String,
    val title: String,
    val items: List<String>,
)

object RapStyleEncyclopedia {

    val subgenreCategories: List<RapStyleCategory> = listOf(
        RapStyleCategory(
            id = "classic",
            title = "1. Classic Hip-Hop",
            items = listOf(
                "Old School Hip-Hop", "New School Hip-Hop", "Boom Bap", "Golden Age Hip-Hop",
                "Underground Hip-Hop", "Alternative Hip-Hop", "Experimental Hip-Hop", "Abstract Hip-Hop",
                "Jazz Rap", "Lo-fi Hip-Hop", "Instrumental Hip-Hop", "Conscious Hip-Hop",
            ),
        ),
        RapStyleCategory(
            id = "trap",
            title = "2. Trap & Modern Rap",
            items = listOf(
                "Trap Rap", "Melodic Trap", "Dark Trap", "Emotional Trap", "Hard Trap",
                "Rage Rap", "Psychedelic Trap", "Ambient Trap", "Trap Soul", "Plug Rap",
                "PluggnB", "Cloud Rap", "Hyperpop Rap", "Electronic Rap", "Industrial Rap",
                "Experimental Trap",
            ),
        ),
        RapStyleCategory(
            id = "drill",
            title = "3. Drill Rap Styles",
            items = listOf(
                "UK Drill", "Brooklyn Drill", "Chicago Drill", "NY Drill", "Sample Drill",
                "Jersey Drill", "Melodic Drill", "Dark Drill", "Aggressive Drill", "Trap Drill",
                "Afro Drill", "Experimental Drill",
            ),
        ),
        RapStyleCategory(
            id = "hardcore",
            title = "4. Hardcore & Street",
            items = listOf(
                "Gangsta Rap", "Hardcore Rap", "Street Rap", "Mafioso Rap", "Gritty Rap",
                "Memphis Rap", "Horrorcore", "Dirty South Rap", "Crunk", "Hyphy",
                "Chopper Rap", "Phonk Rap", "Memphis Phonk", "Drift Phonk",
            ),
        ),
        RapStyleCategory(
            id = "lyrical",
            title = "5. Lyrical & Technical",
            items = listOf(
                "Lyrical Rap", "Technical Rap", "Fast Rap", "Speed Rap", "Double-Time Rap",
                "Triplet Flow Rap", "Multisyllabic Rap", "Internal Rhyme Rap", "Punchline Rap",
                "Wordplay Rap", "Metaphorical Rap", "Complex Scheme Rap", "Battle Rap",
                "Freestyle Rap", "Cypher Rap", "Acapella Rap", "One-Take Rap", "Conscious Lyrical Rap",
            ),
        ),
        RapStyleCategory(
            id = "melodic",
            title = "6. Melodic & Emotional",
            items = listOf(
                "Melodic Rap", "Emo Rap", "Sad Rap", "Heartbreak Rap", "Romantic Rap",
                "Love Rap", "Pain Rap", "Soulful Rap", "Atmospheric Rap", "Dreamy Rap",
                "R&B Rap", "Alternative R&B Rap", "Singing Rap", "Rap-Singing Fusion",
                "Melodic Drill", "Melodic Boom Bap",
            ),
        ),
        RapStyleCategory(
            id = "storytelling",
            title = "7. Storytelling & Message",
            items = listOf(
                "Storytelling Rap", "Narrative Rap", "Conscious Rap", "Political Rap",
                "Philosophical Rap", "Motivational Rap", "Inspirational Rap", "Social Commentary Rap",
                "Spiritual Rap", "Reflective Rap", "Reality Rap", "Biography Rap",
                "Cinematic Rap", "Documentary Rap",
            ),
        ),
        RapStyleCategory(
            id = "regional",
            title = "8. Regional & Desi Hip-Hop",
            items = listOf(
                "East Coast Rap", "West Coast Rap", "Southern Rap", "Midwest Rap", "New York Rap",
                "Atlanta Rap", "Detroit Rap", "Houston Rap", "Bay Area Rap", "UK Rap",
                "French Rap", "German Rap", "Latin Rap", "Latin Trap", "Afro-Rap",
                "Afrobeat Rap", "Nigerian Hip-Hop", "Indian Hip-Hop", "Desi Hip-Hop",
                "Punjabi Rap", "Hindi Rap", "Assamese Rap", "Bengali Rap", "Urdu Rap",
                "Tamil Rap", "Marathi Rap",
            ),
        ),
        RapStyleCategory(
            id = "party",
            title = "9. Party, Club & Anthem",
            items = listOf(
                "Party Rap", "Club Rap", "Dance Rap", "Pop Rap", "Comedy Rap", "Parody Rap",
                "Bounce Rap", "Jersey Club Rap", "Miami Bass Rap", "Electro Rap",
                "Festival Rap", "Anthem Rap", "Hype Rap",
            ),
        ),
        RapStyleCategory(
            id = "fusion",
            title = "10. Specialized & Fusion",
            items = listOf(
                "Jazz Fusion Rap", "Funk Rap", "Rock Rap", "Metal Rap", "Punk Rap",
                "Gospel Rap", "Christian Rap", "Reggae Rap", "Dancehall Rap", "Afro-Fusion Rap",
                "Latin Fusion Rap", "Classical Fusion Rap", "Orchestral Rap", "Acoustic Rap",
                "Lo-fi Melodic Rap", "Drill Fusion", "Trap Fusion", "Cinematic Trap Rap",
            ),
        ),
    )

    val flowDeliveryTechniques: List<String> = listOf(
        "Straight Flow", "Offbeat Flow", "Double-Time Flow", "Half-Time Flow", "Triplet Flow",
        "Polyrhythmic Flow", "Syncopated Flow", "Staccato Flow", "Legato Flow", "Pocket Flow",
        "Switch Flow", "Bounce Flow", "Chopper Flow", "Conversational Flow", "Aggressive Flow",
        "Whisper Flow", "Raspy Flow", "Deep Vocal Flow", "Melodic Flow", "Sing-Rap Flow",
        "Rapid-Fire Flow", "Stop-and-Go Flow", "Behind-the-Beat Flow", "Ahead-of-the-Beat Flow",
        "Multi-Cadence Flow",
    )

    val lyricWritingTechniques: List<String> = listOf(
        "Multisyllabic Rhymes", "Internal Rhymes", "End Rhymes", "Compound Rhymes", "Slant Rhymes",
        "Chain Rhymes", "Double Entendres", "Triple Entendres", "Wordplay", "Punchlines",
        "Metaphors", "Similes", "Alliteration", "Assonance", "Consonance",
        "Homophones", "Homonyms", "Double Meanings", "Extended Metaphors", "Rhyme Schemes",
        "Scheme Stacking", "Callback Punchlines", "Setup and Payoff", "Imagery", "Storytelling",
        "Internal Rhyme Chains", "Complex Syllable Patterns", "Unexpected Rhyme Switches",
        "Extended Wordplay", "Technical Rhyme Density",
    )

    val productionStyles: List<String> = listOf(
        "Boom Bap Drums", "808 Trap Beats", "Drill 808s", "Jazz Sampling", "Soul Sampling",
        "Funk Sampling", "Piano Trap", "Guitar Trap", "Dark Synth Production",
        "Orchestral Production", "Cinematic Production", "Ambient Production", "Lo-fi Production",
        "Memphis Sampling", "Distorted Bass Production", "Minimalist Production",
        "Live Instrument Hip-Hop", "Electronic Production", "Acoustic Production",
        "Beat Switch Production",
    )

    val songStructureBlocks: List<String> = listOf(
        "[Intro – 4 Bars]",
        "[Hook / Chorus – 8 Bars]",
        "[Verse 1 – 16 Bars]",
        "[Pre-Hook – 4 Bars]",
        "[Hook – 8 Bars]",
        "[Verse 2 – 16 Bars]",
        "[Verse 3 – 16 Bars]",
        "[Beat Switch – 8 Bars]",
        "[Breakdown – 4 Bars]",
        "[Bridge – 4 to 8 Bars]",
        "[Double Hook – 16 Bars]",
        "[Final Hook – 8 Bars]",
        "[Outro – 4 Bars]",
        "[Acapella Ending – 4 Bars]",
    )

    val ultimateCombinations: List<String> = listOf(
        "Melodic Drill + Technical Rap",
        "Dark Trap + Double-Time Flow",
        "Boom Bap + Multisyllabic Rhymes",
        "Emo Rap + Atmospheric Production",
        "Gangsta Rap + Cinematic Storytelling",
        "Trap + Soulful Singing",
        "Drill + Aggressive Punchlines",
        "Conscious Rap + Jazz Production",
        "Battle Rap + Complex Wordplay",
        "Rage Rap + Experimental Production",
        "Cloud Rap + Melodic Hooks",
        "Phonk + Rapid-Fire Flow",
        "Desi Hip-Hop + Global Trap",
        "Afro-Rap + Melodic Trap",
        "Melodic Drill + Emotional Storytelling",
        "Hardcore Rap + Technical Rhyming",
        "Boom Bap + Modern 808s",
        "Trap Soul + Deep Male Vocals",
        "Cinematic Rap + Orchestral Production",
        "Experimental Hip-Hop + Multiple Flow Switches",
    )

    val allSubgenresFlat: List<String> by lazy {
        subgenreCategories.flatMap { it.items }.distinct()
    }
}
