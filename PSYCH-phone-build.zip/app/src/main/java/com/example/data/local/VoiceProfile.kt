package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "voice_profiles")
data class VoiceProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val sampleFilePath: String = "",
    val pitchHz: Float = 128f,
    val spectralCentroidHz: Float = 1550f,
    val warmthDb: Float = 2.0f,
    val presenceDb: Float = 2.8f,
    val airDb: Float = 2.2f,
    val gritAmount: Float = 0.22f,
    val formantShift: Float = 1.0f,
    val breathiness: Float = 0.10f,
    val timbreSummary: String = "128 Hz Studio Baritone",
    val aiPersonaNotes: String = "",
    val languageCode: String = "en",
    val spectralEnvelopeCsv: String = "",
    val pitchVarianceHz: Float = 18f,
    val isPreset: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
)

object VocalProfileHelpers {
    fun starterProfiles(): List<VoiceProfile> = listOf(
        VoiceProfile(
            name = "Deep Studio Bass",
            pitchHz = 96f,
            spectralCentroidHz = 1120f,
            warmthDb = 4.2f,
            presenceDb = 2.4f,
            airDb = 1.6f,
            gritAmount = 0.28f,
            formantShift = 0.86f,
            breathiness = 0.08f,
            timbreSummary = "96 Hz Deep Bass • Warm Sub Chest",
            aiPersonaNotes = "Authoritative low-register booth resonance suited for Trap, Drill & Dark Hip-Hop.",
            isPreset = true,
        ),
        VoiceProfile(
            name = "Crisp Melodic Tenor",
            pitchHz = 166f,
            spectralCentroidHz = 1980f,
            warmthDb = 1.4f,
            presenceDb = 3.5f,
            airDb = 4.2f,
            gritAmount = 0.14f,
            formantShift = 1.08f,
            breathiness = 0.16f,
            timbreSummary = "166 Hz Tenor • Airy Melodic Shine",
            aiPersonaNotes = "Bright radio-ready top end for melodic hooks, Trap Soul & Pop Rap.",
            isPreset = true,
        ),
        VoiceProfile(
            name = "Raspy Street Grit",
            pitchHz = 122f,
            spectralCentroidHz = 1680f,
            warmthDb = 2.2f,
            presenceDb = 4.4f,
            airDb = 2.6f,
            gritAmount = 0.56f,
            formantShift = 0.95f,
            breathiness = 0.12f,
            timbreSummary = "122 Hz Baritone • Raw Tube Grit",
            aiPersonaNotes = "Aggressive mid-range bite and harmonic saturation for Hardcore, Desi & Cypher bars.",
            isPreset = true,
        ),
        VoiceProfile(
            name = "Velvet Alto Hook",
            pitchHz = 218f,
            spectralCentroidHz = 2240f,
            warmthDb = 2.0f,
            presenceDb = 3.0f,
            airDb = 4.6f,
            gritAmount = 0.12f,
            formantShift = 1.16f,
            breathiness = 0.20f,
            timbreSummary = "218 Hz Alto • Silky Hook Presence",
            aiPersonaNotes = "Smooth harmonic lift tailored for emotive choruses, R&B fusion & folk hooks.",
            isPreset = true,
        ),
    )
}
