package com.example.data

enum class StudioLanguage(
    val code: String,
    val englishName: String,
    val nativeLabel: String,
    val ttsLanguageTag: String,
    val culturalStyleHint: String,
) {
    ENGLISH("en", "English", "English", "en-US", "Modern global hip-hop, boom bap & melodic rap"),
    HINDI("hi", "Hindi", "हिन्दी", "hi-IN", "Desi Hip-Hop, poetic Bollywood & gully rap"),
    ASSAMESE("as", "Assamese", "অসমীয়া", "as-IN", "Axomiya folk-rap, Bihu groove & Brahmaputra storytelling"),
    NEPALI("ne", "Nepali", "नेपाली", "ne-NP", "NepHop street storytelling, Himalayan soul & melodic hooks"),
    BODO("brx", "Bodo / Boro", "बर' / बड़ो", "hi-IN", "Bodo & Boro cultural cadence, Bodoland folk-fusion & modern rap"),
    SANSKRIT("sa", "Sanskrit", "संस्कृतम्", "sa-IN", "Classical Sanskrit shloka meter fused with epic orchestral & trap rap"),
    ADIVASI("sck", "Aadivasi / Adivasi (Sadri)", "आदिवासी / सादरी", "hi-IN", "Aadivasi / Sadri / Nagpuri tribal rhythm, forest soul & pride"),
    PUNJABI("pa", "Punjabi", "ਪੰਜਾਬੀ", "pa-IN", "Punjabi Bhangra-trap, heavy 808s & high-energy anthem hooks"),
    BENGALI("bn", "Bengali", "বাংলা", "bn-IN", "Bangla underground rap, poetic storytelling & Baul fusion"),
    SANTALI("sat", "Santali", "ᱥᱟᱱᱛᱟᱲᱤ", "hi-IN", "Santali tribal groove, Jharkhand/Bengal/Assam Aadivasi rhythm"),
    BHOJPURI("bho", "Bhojpuri", "भोजपुरी", "hi-IN", "Bhojpuri folk-rap bounce & rustic punchlines"),
    MARATHI("mr", "Marathi", "मराठी", "mr-IN", "Marathi street rap, dhol-tasha energy & sharp wordplay"),
    GUJARATI("gu", "Gujarati", "ગુજરાતી", "gu-IN", "Gujarati garba-trap fusion & vibrant rhythm"),
    TAMIL("ta", "Tamil", "தமிழ்", "ta-IN", "Tamil kuthu-rap & Chennai hip-hop cadence"),
    TELUGU("te", "Telugu", "తెలుగు", "te-IN", "Telugu mass-beat rap & rhythmic hook lines"),
    KANNADA("kn", "Kannada", "ಕನ್ನಡ", "kn-IN", "Bengaluru Kannada cypher rap & rhythmic storytelling"),
    MALAYALAM("ml", "Malayalam", "മലയാളം", "ml-IN", "Kochi/Kerala Malayalam rap, fast percussive cadence"),
    URDU("ur", "Urdu", "اردو", "ur-PK", "Urdu shayari-infused rap with deep metaphors & internal rhymes"),
    ODIA("or", "Odia", "ଓଡ଼ିଆ", "or-IN", "Odia coastal folk-trap & rhythmic storytelling"),
    MAITHILI("mai", "Maithili", "मैथिली", "hi-IN", "Maithili poetic rap & classical folk bounce"),
    RAJASTHANI("raj", "Rajasthani", "राजस्थानी", "hi-IN", "Rajasthani desert-trap, Manganiyar groove & royal storytelling"),
    MANIPURI("mni", "Manipuri", "মৈতৈলোন্", "bn-IN", "Meitei melodic storytelling & Northeast indie-rap"),
    KHASI("kha", "Khasi", "Ka Ktien Khasi", "en-IN", "Meghalaya acoustic-rap & Khasi lyrical flow"),
    GARO("grt", "Garo", "A·chik", "en-IN", "Garo Hills indie-rap, rhythmic hooks & acoustic fusion"),
    MIZO("lus", "Mizo", "Mizo ṭawng", "en-IN", "Mizo soulful R&B-rap & crisp melodic hooks"),
    KOKBOROK("trp", "Kokborok", "ককবরক", "bn-IN", "Tripura Kokborok folk-rap & melodic verses"),
    KARBI("mjw", "Karbi", "Karbi", "en-IN", "Karbi Anglong storytelling & folk-percussion hip-hop"),
    NAGAMESE("nag", "Nagamese", "Nagamese", "en-IN", "Nagaland street cipher, melodic rap & storytelling"),
    SPANISH("es", "Spanish", "Español", "es-ES", "Latin trap, reggaeton bounce & melodic flow"),
    FRENCH("fr", "French", "Français", "fr-FR", "Parisian drill, Afro-trap & melodic French rap"),
    KOREAN("ko", "Korean", "한국어", "ko-KR", "K-Hip-Hop, rapid-fire K-Pop rap switches & crisp hooks"),
    JAPANESE("ja", "Japanese", "日本語", "ja-JP", "Tokyo phonk-rap, sharp syllable flow & melodic city-pop rap"),
    ARABIC("ar", "Arabic", "العربية", "ar-SA", "Arabic trap, oud-infused drill & poetic flow"),
    ;

    companion object {
        fun fromCode(code: String): StudioLanguage =
            entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}

enum class ScriptMode(val label: String, val instruction: String) {
    NATIVE_SCRIPT(
        "Native Script",
        "Write all lyrics strictly in the language's authentic native script (except standard section tags like [Verse 1], [Chorus]).",
    ),
    ROMANIZED(
        "Romanized",
        "Write the lyrics in Roman/Latin alphabet phonetic transliteration so anyone can read and rap the pronunciation easily.",
    ),
    BILINGUAL_FUSION(
        "Fusion Mix",
        "Blend authentic native-script lines or regional phrases naturally with English rap punchlines and hook lines.",
    ),
}
