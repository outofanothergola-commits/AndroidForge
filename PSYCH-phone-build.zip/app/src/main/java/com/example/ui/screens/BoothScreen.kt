package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.FiberManualRecord
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.audio.AudioDetailReport
import com.example.audio.MasteringProfile
import com.example.audio.StudioPcmFormat
import com.example.audio.VocalClarityMode
import com.example.audio.detectTakeAudioFormatLabel
import com.example.data.local.BeatStyle
import com.example.data.local.VocalDeliveryStyle
import com.example.data.local.VocalPreset
import com.example.data.local.VocalTake
import com.example.ui.components.BeatStepLedStrip
import com.example.ui.components.LiveWaveformCanvas
import com.example.ui.components.RenameProjectDialog
import com.example.ui.components.StudioBadge
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CrimsonRec
import com.example.ui.theme.CyanWave
import com.example.ui.theme.EmeraldMeter
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioRack
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StudioUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BoothScreen(
    uiState: StudioUiState,
    onToggleBeat: () -> Unit,
    onSelectBeatStyle: (BeatStyle) -> Unit,
    onUpdateBpm: (Int) -> Unit,
    onImportCustomBeat: () -> Unit,
    onUpdateMixer: (drums: Float, bass: Float, melody: Float, reverb: Boolean) -> Unit,
    onSelectVocalPreset: (VocalPreset) -> Unit,
    onSelectPcmFormat: (StudioPcmFormat) -> Unit,
    onSelectMasteringProfile: (MasteringProfile) -> Unit,
    onSelectVocalClarityMode: (VocalClarityMode) -> Unit,
    onUpdateVocalClarityBoost: (Float) -> Unit,
    onInspectTakeDetails: (VocalTake) -> Unit,
    onDismissAudioDetails: () -> Unit,
    onSelectTrackMinutes: (Int) -> Unit,
    onSelectVocalStyle: (String) -> Unit,
    onBounceInstrumental: () -> Unit,
    onToggleRecord: (withBeat: Boolean) -> Unit,
    onToggleTakePlay: (VocalTake) -> Unit,
    onMixTakeWithBeat: (VocalTake) -> Unit,
    onExportTake: (VocalTake) -> Unit,
    onDeleteTake: (VocalTake) -> Unit,
    onRenameActiveProject: (String) -> Unit,
    onToggleFlowVoicePreview: () -> Unit,
    onOpenLyricsTab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    var permissionDeniedOnce by remember { mutableStateOf(false) }
    var autoBeatWhileRecording by remember { mutableStateOf(true) }
    var showTeleprompter by remember { mutableStateOf(false) }
    var showStudioMixer by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasMicPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO,
                ) == PackageManager.PERMISSION_GRANTED
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        hasMicPermission = granted
        if (!granted) {
            permissionDeniedOnce = true
        }
    }

    val project = uiState.activeProject
    val activeStyle = BeatStyle.fromName(project?.beatStyle ?: BeatStyle.TRAP_808.name)
    val activeVocalPreset = VocalPreset.fromName(project?.vocalPreset ?: VocalPreset.WARM_BOOTH.name)

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Hero Studio Header Card
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(152.dp),
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_studio_banner),
                            contentDescription = "Vocal recording studio booth",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            StudioObsidian.copy(alpha = 0.35f),
                                            StudioObsidian.copy(alpha = 0.92f),
                                        ),
                                    ),
                                ),
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                val badgeLabel = when {
                                    uiState.isRecording -> "REC LIVE"
                                    uiState.isBeatPlaying -> "STUDIO MIX ON"
                                    else -> "BOOTH READY"
                                }
                                val badgeColor = when {
                                    uiState.isRecording -> CrimsonRec
                                    uiState.isBeatPlaying -> CyanWave
                                    else -> EmeraldMeter
                                }
                                StudioBadge(label = badgeLabel, accentColor = badgeColor)

                                Surface(
                                    color = StudioObsidian.copy(alpha = 0.72f),
                                    shape = RoundedCornerShape(50),
                                    border = BorderStroke(1.dp, StudioStroke),
                                ) {
                                    Text(
                                        text = "${uiState.selectedLanguage.nativeLabel} • ${stringResource(R.string.creator_footer)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    val trackMins = project?.trackMinutes ?: 3
                                    val vocalDeliv = project?.vocalStyle ?: VocalDeliveryStyle.DEEP.displayName
                                    Text(
                                        text = "${trackMins}m TRACK • ${vocalDeliv.uppercase()} • ${
                                            project?.chordProgression?.takeIf { it.isNotBlank() } ?: "STUDIO SESSION"
                                        }",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AmberVu,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    ) {
                                        Text(
                                            text = project?.title ?: "Session 01",
                                            style = MaterialTheme.typography.headlineMedium,
                                            color = TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false),
                                        )
                                        IconButton(
                                            onClick = { showRenameDialog = true },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .testTag("rename_active_track_button"),
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Edit,
                                                contentDescription = "Rename track",
                                                tint = TextSecondary,
                                                modifier = Modifier.size(18.dp),
                                            )
                                        }
                                    }
                                }

                                Surface(
                                    color = AmberVu.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, AmberVu.copy(alpha = 0.45f)),
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                    ) {
                                        Text(
                                            text = "${project?.bpm ?: 92}",
                                            style = MaterialTheme.typography.titleLarge,
                                            color = AmberVu,
                                        )
                                        Text(
                                            text = "BPM",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AmberVu.copy(alpha = 0.8f),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Studio Acoustic Beat & Instrumental Engine
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Text(
                                        text = "STUDIO INSTRUMENTAL ENGINE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyanWave,
                                    )
                                    if (uiState.isBeatPlaying) {
                                        StudioBadge(
                                            label = uiState.arrangementSection,
                                            accentColor = AmberVu,
                                        )
                                    }
                                }
                                Text(
                                    text = if (activeStyle == BeatStyle.CUSTOM) {
                                        project?.customBeatName ?: "Custom Audio Beat"
                                    } else {
                                        "${activeStyle.displayName} • ${activeStyle.tag}"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }

                            Button(
                                onClick = onToggleBeat,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (uiState.isBeatPlaying) CyanWave else StudioModuleElevated,
                                    contentColor = if (uiState.isBeatPlaying) StudioObsidian else TextPrimary,
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("toggle_beat_button"),
                            ) {
                                Icon(
                                    imageVector = if (uiState.isBeatPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (uiState.isBeatPlaying) "Stop" else "Play",
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }

                        BeatStepLedStrip(
                            currentStep = uiState.currentStep,
                            isPlaying = uiState.isBeatPlaying,
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            BeatStyle.entries.forEach { style ->
                                val selected = activeStyle == style
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSelectBeatStyle(style) },
                                    label = { Text(style.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                        selectedLabelColor = AmberVu,
                                    ),
                                    modifier = Modifier.testTag("beat_style_${style.name.lowercase()}"),
                                )
                            }
                        }

                        // Tempo + Import Beat + Mixer Drawer Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            val currentBpm = project?.bpm ?: 92
                            Surface(
                                color = StudioModule,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .size(48.dp)
                                    .clickable { onUpdateBpm(currentBpm - 2) }
                                    .testTag("bpm_decrease_button"),
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.Remove, contentDescription = "Decrease BPM")
                                }
                            }

                            Slider(
                                value = currentBpm.toFloat(),
                                onValueChange = { onUpdateBpm(it.toInt()) },
                                valueRange = 60f..180f,
                                colors = SliderDefaults.colors(
                                    thumbColor = AmberVu,
                                    activeTrackColor = AmberVu,
                                ),
                                modifier = Modifier.weight(1f),
                            )

                            Surface(
                                color = StudioModule,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .size(48.dp)
                                    .clickable { onUpdateBpm(currentBpm + 2) }
                                    .testTag("bpm_increase_button"),
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.Add, contentDescription = "Increase BPM")
                                }
                            }

                            IconButton(
                                onClick = { showStudioMixer = !showStudioMixer },
                                modifier = Modifier.testTag("toggle_mixer_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Tune,
                                    contentDescription = "Toggle studio mixer",
                                    tint = if (showStudioMixer) AmberVu else TextSecondary,
                                )
                            }

                            OutlinedButton(
                                onClick = onImportCustomBeat,
                                border = BorderStroke(1.dp, StudioStroke),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("import_custom_beat_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.AudioFile,
                                    contentDescription = null,
                                    tint = CyanWave,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Beat", color = TextPrimary)
                            }
                        }

                        // Track Duration (3m / 5m / 10m) & Bounce Timed Studio Instrumental
                        val trackMinutes = project?.trackMinutes ?: 3
                        val activeVocalDelivery = project?.vocalStyle ?: VocalDeliveryStyle.DEEP.displayName
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf(3, 5, 10).forEach { mins ->
                                FilterChip(
                                    selected = trackMinutes == mins,
                                    onClick = { onSelectTrackMinutes(mins) },
                                    label = { Text("${mins}m") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                                        selectedLabelColor = CyanWave,
                                    ),
                                    modifier = Modifier.testTag("booth_duration_${mins}m_chip"),
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            OutlinedButton(
                                onClick = onBounceInstrumental,
                                enabled = !uiState.isMixingMaster,
                                border = BorderStroke(1.dp, EmeraldMeter.copy(alpha = 0.55f)),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("bounce_instrumental_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Download,
                                    contentDescription = null,
                                    tint = EmeraldMeter,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Bounce ${trackMinutes}m Beat", color = EmeraldMeter)
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Delivery:",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                            )
                            VocalDeliveryStyle.entries.forEach { style ->
                                FilterChip(
                                    selected = activeVocalDelivery.equals(style.displayName, ignoreCase = true),
                                    onClick = { onSelectVocalStyle(style.displayName) },
                                    label = { Text(style.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldMeter.copy(alpha = 0.18f),
                                        selectedLabelColor = EmeraldMeter,
                                    ),
                                )
                            }
                        }

                        AnimatedVisibility(visible = showStudioMixer) {
                            Surface(
                                color = StudioObsidian,
                                shape = MaterialTheme.shapes.medium,
                                border = BorderStroke(1.dp, StudioStroke.copy(alpha = 0.7f)),
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Text(
                                        text = "STUDIO BUS MIXER",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AmberVu,
                                    )
                                    MixerSliderRow(
                                        label = "Drums & Tabla",
                                        value = uiState.mixer.drumsGain,
                                        onValueChange = {
                                            onUpdateMixer(
                                                it,
                                                uiState.mixer.bassGain,
                                                uiState.mixer.melodyGain,
                                                uiState.mixer.roomReverbEnabled,
                                            )
                                        },
                                    )
                                    MixerSliderRow(
                                        label = "808 & Sub Bass",
                                        value = uiState.mixer.bassGain,
                                        onValueChange = {
                                            onUpdateMixer(
                                                uiState.mixer.drumsGain,
                                                it,
                                                uiState.mixer.melodyGain,
                                                uiState.mixer.roomReverbEnabled,
                                            )
                                        },
                                    )
                                    MixerSliderRow(
                                        label = "Chords & Strings",
                                        value = uiState.mixer.melodyGain,
                                        onValueChange = {
                                            onUpdateMixer(
                                                uiState.mixer.drumsGain,
                                                uiState.mixer.bassGain,
                                                it,
                                                uiState.mixer.roomReverbEnabled,
                                            )
                                        },
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(
                                            text = "Studio Room Ambience",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = TextSecondary,
                                        )
                                        Switch(
                                            checked = uiState.mixer.roomReverbEnabled,
                                            onCheckedChange = {
                                                onUpdateMixer(
                                                    uiState.mixer.drumsGain,
                                                    uiState.mixer.bassGain,
                                                    uiState.mixer.melodyGain,
                                                    it,
                                                )
                                            },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Vocal Booth & Mastering Presets
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(
                        width = if (uiState.isRecording) 1.5.dp else 1.dp,
                        color = if (uiState.isRecording) CrimsonRec.copy(alpha = 0.8f) else StudioStroke,
                    ),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column {
                                Text(
                                    text = "VOCAL BOOTH & MASTERING FX",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (uiState.isRecording) CrimsonRec else AmberVu,
                                )
                                Text(
                                    text = if (uiState.isRecording) {
                                        "REC ${uiState.activeCaptureLabel}"
                                    } else {
                                        "Chain: ${activeVocalPreset.displayName} • 48kHz / ${uiState.selectedPcmFormat.shortBadge}"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                )
                            }

                            Text(
                                text = formatElapsedMs(uiState.recordElapsedMs),
                                style = MaterialTheme.typography.headlineSmall,
                                color = if (uiState.isRecording) CrimsonRec else TextSecondary,
                            )
                        }

                        // Studio PCM Engine Selector (32-Bit Float PCM vs 24-Bit PCM)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "PCM:",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberVu,
                            )
                            StudioPcmFormat.entries.forEach { fmt ->
                                FilterChip(
                                    selected = uiState.selectedPcmFormat == fmt,
                                    onClick = { onSelectPcmFormat(fmt) },
                                    label = { Text(fmt.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldMeter.copy(alpha = 0.20f),
                                        selectedLabelColor = EmeraldMeter,
                                    ),
                                    modifier = Modifier.testTag("pcm_format_${fmt.bitsPerSample}_chip"),
                                )
                            }
                        }

                        // Studio Mastering Chain Selector
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "MASTER:",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanWave,
                            )
                            MasteringProfile.entries.forEach { profile ->
                                FilterChip(
                                    selected = uiState.selectedMasteringProfile == profile,
                                    onClick = { onSelectMasteringProfile(profile) },
                                    label = { Text(profile.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                        selectedLabelColor = AmberVu,
                                    ),
                                    modifier = Modifier.testTag("mastering_profile_${profile.name.lowercase()}_chip"),
                                )
                            }
                        }

                        // Vocal Clarity Engine Chips (Noise Gate + De-Mud + Air Exciter + Beat Pocket)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = "CLARITY:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldMeter,
                                )
                                VocalClarityMode.entries.forEach { mode ->
                                    FilterChip(
                                        selected = uiState.selectedVocalClarityMode == mode,
                                        onClick = { onSelectVocalClarityMode(mode) },
                                        label = { Text(mode.displayName) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = EmeraldMeter.copy(alpha = 0.22f),
                                            selectedLabelColor = EmeraldMeter,
                                        ),
                                        modifier = Modifier.testTag("vocal_clarity_${mode.name.lowercase()}_chip"),
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Text(
                                    text = "Clarity Focus",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                )
                                Slider(
                                    value = uiState.vocalClarityBoost,
                                    onValueChange = onUpdateVocalClarityBoost,
                                    valueRange = 0f..1f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = EmeraldMeter,
                                        activeTrackColor = EmeraldMeter,
                                    ),
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    text = "${(uiState.vocalClarityBoost * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldMeter,
                                )
                            }
                        }

                        // Vocal Mastering Preset Chips
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            VocalPreset.entries.forEach { preset ->
                                FilterChip(
                                    selected = activeVocalPreset == preset,
                                    onClick = { onSelectVocalPreset(preset) },
                                    label = { Text(preset.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                                        selectedLabelColor = CyanWave,
                                    ),
                                )
                            }
                        }

                        if (!hasMicPermission) {
                            Surface(
                                color = StudioModule,
                                shape = MaterialTheme.shapes.medium,
                                border = BorderStroke(1.dp, AmberVu.copy(alpha = 0.4f)),
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Mic,
                                            contentDescription = null,
                                            tint = AmberVu,
                                        )
                                        Text(
                                            text = stringResource(R.string.mic_permission_title),
                                            style = MaterialTheme.typography.titleMedium,
                                        )
                                    }
                                    Text(
                                        text = if (permissionDeniedOnce) {
                                            "Microphone permission is required to record vocals. Tap below to grant access."
                                        } else {
                                            stringResource(R.string.mic_permission_body)
                                        },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary,
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = AmberVu,
                                                contentColor = StudioObsidian,
                                            ),
                                            modifier = Modifier.testTag("enable_mic_button"),
                                        ) {
                                            Text(stringResource(R.string.grant_mic_permission), fontWeight = FontWeight.Bold)
                                        }
                                        if (permissionDeniedOnce) {
                                            OutlinedButton(
                                                onClick = {
                                                    val intent = Intent(
                                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                        Uri.fromParts("package", context.packageName, null),
                                                    )
                                                    context.startActivity(intent)
                                                },
                                            ) {
                                                Text("Settings")
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            LiveWaveformCanvas(
                                amplitudes = uiState.waveformBars,
                                isRecording = uiState.isRecording,
                                isBeatPlaying = uiState.isBeatPlaying,
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Switch(
                                        checked = autoBeatWhileRecording,
                                        onCheckedChange = { autoBeatWhileRecording = it },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = StudioObsidian,
                                            checkedTrackColor = AmberVu,
                                        ),
                                    )
                                    Text(
                                        text = "Beat + Mic",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary,
                                    )
                                }

                                RecordPulseButton(
                                    isRecording = uiState.isRecording,
                                    onClick = { onToggleRecord(autoBeatWhileRecording) },
                                )
                            }
                        }
                    }
                }
            }

            // Collapsible Booth Teleprompter + Flow Guide Voice
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showTeleprompter = !showTeleprompter }
                                .minimumInteractiveComponentSize(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Lyrics,
                                    contentDescription = null,
                                    tint = AmberVu,
                                )
                                Column {
                                    Text(
                                        text = "Booth Teleprompter",
                                        style = MaterialTheme.typography.titleMedium,
                                    )
                                    Text(
                                        text = "${uiState.lyricStats.barCount} bars • ${uiState.selectedLanguage.englishName}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                    )
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = onToggleFlowVoicePreview) {
                                    Icon(
                                        imageVector = if (uiState.isFlowVoiceSpeaking) {
                                            Icons.Rounded.Stop
                                        } else {
                                            Icons.Rounded.RecordVoiceOver
                                        },
                                        contentDescription = "Hear AI flow voice preview",
                                        tint = CyanWave,
                                    )
                                }
                                Icon(
                                    imageVector = if (showTeleprompter) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                    contentDescription = "Toggle teleprompter",
                                    tint = TextSecondary,
                                )
                            }
                        }

                        AnimatedVisibility(visible = showTeleprompter) {
                            Column(
                                modifier = Modifier.padding(top = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                if (uiState.lyricsDraft.isBlank()) {
                                    Text(
                                        text = "No lyrics written yet for this track.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary,
                                    )
                                    OutlinedButton(
                                        onClick = onOpenLyricsTab,
                                        modifier = Modifier.testTag("put_own_lyrics_from_booth_button"),
                                    ) {
                                        Text("Put / Write Own Lyrics")
                                    }
                                } else {
                                    Surface(
                                        color = StudioObsidian,
                                        shape = MaterialTheme.shapes.medium,
                                        border = BorderStroke(1.dp, StudioStroke.copy(alpha = 0.6f)),
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Text(
                                            text = uiState.lyricsDraft,
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = TextPrimary,
                                            modifier = Modifier.padding(14.dp),
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = onOpenLyricsTab,
                                        modifier = Modifier.testTag("edit_own_lyrics_from_booth_button"),
                                    ) {
                                        Text("Edit Own Lyrics in Pad")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Recorded Vocal Takes & Studio Masters Rack
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "TAKES & MASTERS (${uiState.activeTakes.size})",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary,
                    )
                    if (uiState.isMixingMaster) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = AmberVu, strokeWidth = 2.dp)
                            Text("Mixing Master...", style = MaterialTheme.typography.labelSmall, color = AmberVu)
                        }
                    } else {
                        Text(
                            text = "Tap Mix icon to bounce Beat+Vocal",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                        )
                    }
                }
            }

            if (uiState.activeTakes.isEmpty()) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(1.dp, StudioStroke.copy(alpha = 0.6f)),
                        colors = CardDefaults.cardColors(containerColor = StudioRack.copy(alpha = 0.7f)),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.MusicNote,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(34.dp),
                            )
                            Text(
                                text = "No vocal takes recorded yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextSecondary,
                            )
                            Text(
                                text = "Play a studio beat above, select a Vocal FX preset, and tap REC to lay down your verse.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted,
                            )
                        }
                    }
                }
            } else {
                items(uiState.activeTakes, key = { it.id }) { take ->
                    VocalTakeCard(
                        take = take,
                        isPlaying = uiState.playingTakeId == take.id,
                        progress = if (uiState.playingTakeId == take.id) uiState.takePlaybackProgress else 0f,
                        onTogglePlay = { onToggleTakePlay(take) },
                        onInspectDetails = { onInspectTakeDetails(take) },
                        onMixWithBeat = { onMixTakeWithBeat(take) },
                        onExport = { onExportTake(take) },
                        onDelete = { onDeleteTake(take) },
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }

    if (showRenameDialog && project != null) {
        RenameProjectDialog(
            initialTitle = project.title,
            onDismiss = { showRenameDialog = false },
            onConfirm = { newTitle ->
                showRenameDialog = false
                onRenameActiveProject(newTitle)
            },
        )
    }

    uiState.inspectedAudioDetails?.let { report ->
        AudioDetailsDialog(
            report = report,
            onDismiss = onDismissAudioDetails,
        )
    }
}

@Composable
private fun MixerSliderRow(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            modifier = Modifier.width(105.dp),
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 0f..1.2f,
            colors = SliderDefaults.colors(
                thumbColor = CyanWave,
                activeTrackColor = CyanWave,
            ),
            modifier = Modifier.weight(1f),
        )
        Text(
            text = "${(value * 100).toInt()}%",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            modifier = Modifier.width(38.dp),
        )
    }
}

@Composable
private fun RecordPulseButton(
    isRecording: Boolean,
    onClick: () -> Unit,
) {
    val transition = rememberInfiniteTransition(label = "recPulse")
    val pulseScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (isRecording) 1.07f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(650),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "recScale",
    )

    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isRecording) StudioModuleElevated else CrimsonRec,
            contentColor = TextPrimary,
        ),
        border = if (isRecording) BorderStroke(1.5.dp, CrimsonRec) else null,
        shape = CircleShape,
        contentPadding = PaddingValues(horizontal = 22.dp, vertical = 14.dp),
        modifier = Modifier
            .scale(pulseScale)
            .minimumInteractiveComponentSize()
            .testTag("record_toggle_button"),
    ) {
        Icon(
            imageVector = if (isRecording) Icons.Rounded.Stop else Icons.Rounded.FiberManualRecord,
            contentDescription = if (isRecording) "Stop recording" else "Start recording",
            tint = if (isRecording) CrimsonRec else Color.White,
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = if (isRecording) stringResource(R.string.record_stop) else stringResource(R.string.record_start),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun VocalTakeCard(
    take: VocalTake,
    isPlaying: Boolean,
    progress: Float,
    onTogglePlay: () -> Unit,
    onInspectDetails: () -> Unit,
    onMixWithBeat: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit,
) {
    val isLosslessWav = take.filePath.endsWith(".wav", ignoreCase = true)
    val formatBadge by produceState(
        initialValue = if (isLosslessWav) "48kHz WAV" else "M4A",
        take.filePath,
    ) {
        value = withContext(Dispatchers.IO) {
            detectTakeAudioFormatLabel(take.filePath)
        }
    }
    val canMixWithBeat = !take.title.startsWith("Master", ignoreCase = true) &&
        !take.title.contains("Mix", ignoreCase = true) &&
        !take.title.contains("Beat", ignoreCase = true)
    val dateLabel = remember(take.createdAt) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(take.createdAt))
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        border = BorderStroke(
            width = 1.dp,
            color = when {
                isPlaying -> CyanWave.copy(alpha = 0.8f)
                isLosslessWav -> EmeraldMeter.copy(alpha = 0.55f)
                else -> StudioStroke
            },
        ),
        colors = CardDefaults.cardColors(containerColor = StudioModule),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Surface(
                    color = if (isPlaying) CyanWave else if (isLosslessWav) EmeraldMeter.copy(alpha = 0.2f) else AmberVu.copy(alpha = 0.2f),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(48.dp)
                        .clickable { onTogglePlay() }
                        .testTag("play_take_${take.id}"),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (isPlaying) "Pause ${take.title}" else "Play ${take.title}",
                            tint = if (isPlaying) StudioObsidian else if (isLosslessWav) EmeraldMeter else AmberVu,
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = take.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                        )
                        Surface(
                            color = if (isLosslessWav) EmeraldMeter.copy(alpha = 0.16f) else AmberVu.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(6.dp),
                        ) {
                            Text(
                                text = formatBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isLosslessWav) EmeraldMeter else AmberVu,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        }
                    }
                    Text(
                        text = "${formatDurationSec(take.durationMs)} • $dateLabel",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                    )
                }

                if (canMixWithBeat) {
                    IconButton(
                        onClick = onMixWithBeat,
                        modifier = Modifier.testTag("mix_take_${take.id}"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoFixHigh,
                            contentDescription = "Mix ${take.title} with studio beat",
                            tint = AmberVu,
                        )
                    }
                }

                IconButton(
                    onClick = onInspectDetails,
                    modifier = Modifier.testTag("details_take_${take.id}"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Info,
                        contentDescription = "Inspect audio details for ${take.title}",
                        tint = EmeraldMeter,
                    )
                }

                IconButton(
                    onClick = onExport,
                    modifier = Modifier.testTag("export_take_${take.id}"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Download,
                        contentDescription = "Save audio to Music/PSYCH",
                        tint = CyanWave,
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("delete_take_${take.id}"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete ${take.title}",
                        tint = TextMuted,
                    )
                }
            }

            if (isPlaying) {
                LinearProgressIndicator(
                    progress = { progress },
                    color = CyanWave,
                    trackColor = StudioObsidian,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                )
            }
        }
    }
}

private fun formatElapsedMs(ms: Long): String {
    val totalTenths = (ms / 100L).coerceAtLeast(0L)
    val tenths = totalTenths % 10L
    val totalSec = totalTenths / 10L
    val minutes = totalSec / 60L
    val seconds = totalSec % 60L
    return String.format(Locale.US, "%02d:%02d.%d", minutes, seconds, tenths)
}

private fun formatDurationSec(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(1L)
    val minutes = totalSec / 60L
    val seconds = totalSec % 60L
    return String.format(Locale.US, "%d:%02d", minutes, seconds)
}

@Composable
internal fun AudioDetailsDialog(
    report: AudioDetailReport,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioRack,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "STUDIO AUDIO TELEMETRY",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldMeter,
                )
                Text(
                    text = report.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AudioTelemetryRow("Format", report.formatLabel, EmeraldMeter)
                AudioTelemetryRow("Sample Rate", "${report.sampleRateHz} Hz", CyanWave)
                AudioTelemetryRow("Bit Depth", report.bitDepthLabel, TextPrimary)
                AudioTelemetryRow("Channels", report.channelsLabel, TextPrimary)
                AudioTelemetryRow("Bitrate", report.bitrateKbpsLabel, TextPrimary)
                AudioTelemetryRow("File Size", report.fileSizeLabel, TextPrimary)
                AudioTelemetryRow("Duration", report.durationLabel, TextPrimary)
                HorizontalDivider(color = StudioStroke.copy(alpha = 0.6f))
                AudioTelemetryRow("True Peak", report.peakDbfsLabel, AmberVu)
                AudioTelemetryRow("Integrated RMS", report.rmsDbfsLabel, CyanWave)
                AudioTelemetryRow("Dynamic Range", report.dynamicRangeLabel, EmeraldMeter)
                AudioTelemetryRow("Clipping", report.clippingLabel, TextSecondary)
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("close_audio_details_button"),
            ) {
                Text("Close", color = AmberVu, fontWeight = FontWeight.Bold)
            }
        },
    )
}

@Composable
private fun AudioTelemetryRow(
    label: String,
    value: String,
    valueColor: Color,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = valueColor,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

