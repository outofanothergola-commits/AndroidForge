package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ai.AiGeneratedSong
import com.example.ai.HipHopMasterTemplate
import com.example.data.RapStyleEncyclopedia
import com.example.data.ScriptMode
import com.example.data.StudioLanguage
import com.example.data.local.VocalDeliveryStyle
import com.example.ui.components.LanguagePickerSheet
import com.example.ui.components.RapMasterDraftPickerSheet
import com.example.ui.components.StudioBadge
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CrimsonRec
import com.example.ui.theme.CyanWave
import com.example.ui.theme.EmeraldMeter
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioRack
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AiAssistUiState
import com.example.ui.viewmodel.AiSongUiState
import com.example.ui.viewmodel.StudioUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiStudioScreen(
    uiState: StudioUiState,
    onSelectLanguage: (StudioLanguage) -> Unit,
    onSelectScriptMode: (ScriptMode) -> Unit,
    onGenerateSong: (
        songTitle: String,
        promptOrSeedLyrics: String,
        genre: String,
        mood: String,
        vocalStyle: String,
        flowTechnique: String,
        lyricTechnique: String,
        productionStyle: String,
        requestedBpm: Int?,
        trackMinutes: Int,
    ) -> Unit,
    onLoadMasterTemplateScaffold: (
        title: String,
        genre: String,
        mood: String,
        bpm: Int,
        vocalStyle: String,
        trackMinutes: Int,
    ) -> Unit,
    onLoadOwnLyricsIntoStudio: (
        title: String,
        ownLyrics: String,
        genre: String,
        requestedBpm: Int?,
        vocalStyle: String,
        trackMinutes: Int,
        startBeat: Boolean,
    ) -> Boolean,
    onImportOwnLyricsTxt: () -> Unit,
    onLoadSongIntoBooth: (AiGeneratedSong, startBeat: Boolean) -> Unit,
    onProduceFullSongWithClone: (AiGeneratedSong) -> Unit,
    onRunCoWriter: (instruction: String, replaceWhole: Boolean) -> Unit,
    onAppendCoWriter: () -> Unit,
    onReplaceWithCoWriter: () -> Unit,
    onToggleFlowVoicePreview: () -> Unit,
    onOpenBoothTab: () -> Unit,
    onOpenLyricsTab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var useOwnLyricsMode by remember { mutableStateOf(false) }
    var awaitingImportSync by remember { mutableStateOf(false) }
    var songTitleInput by remember { mutableStateOf("") }
    var songPrompt by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("Trap Rap") }
    var selectedMood by remember { mutableStateOf("Motivational") }
    var selectedVocal by remember { mutableStateOf(VocalDeliveryStyle.DEEP.displayName) }
    var selectedFlow by remember { mutableStateOf("Switch Flow") }
    var selectedLyricTechnique by remember { mutableStateOf("Multisyllabic Rhymes") }
    var selectedProduction by remember { mutableStateOf("808 Trap Beats") }
    var selectedMinutes by remember { mutableIntStateOf(3) }
    var autoBpm by remember { mutableStateOf(true) }
    var customBpm by remember { mutableFloatStateOf(136f) }
    var showLanguagePicker by remember { mutableStateOf(false) }
    var showMasterDraftSheet by remember { mutableStateOf(false) }
    var masterDraftInitialTab by remember { mutableIntStateOf(0) }

    LaunchedEffect(uiState.lyricsDraft) {
        if (awaitingImportSync && uiState.lyricsDraft.isNotBlank()) {
            songPrompt = uiState.lyricsDraft
            awaitingImportSync = false
        }
    }

    val quickGenres = remember(selectedGenre) {
        val defaults = listOf(
            "Trap Rap",
            "UK Drill",
            "Boom Bap",
            "Melodic Rap",
            "Desi Hip-Hop",
            "Assamese Rap",
            "Hindi Rap",
            "Punjabi Rap",
            "Chopper Rap",
            "Lo-fi Hip-Hop",
            "Afro-Rap",
        )
        if (defaults.any { it.equals(selectedGenre, ignoreCase = true) }) {
            defaults
        } else {
            listOf(selectedGenre) + defaults
        }
    }
    val moods = listOf("Dark", "Emotional", "Aggressive", "Motivational", "Hype", "Storytelling")
    val vocalStyles = VocalDeliveryStyle.entries.map { it.displayName }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "HIP-HOP SONG MASTER STUDIO",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanWave,
                        )
                        Text(
                            text = "AI Song & Rap Architect",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary,
                        )
                    }
                    StudioBadge(label = "160+ STYLES", accentColor = AmberVu)
                }
            }

            // Language & Script Selector
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.45f)),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showLanguagePicker = true }
                                .minimumInteractiveComponentSize()
                                .testTag("open_language_picker_button"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f),
                            ) {
                                Surface(
                                    color = CyanWave.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(10.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Language,
                                        contentDescription = null,
                                        tint = CyanWave,
                                        modifier = Modifier.padding(8.dp),
                                    )
                                }
                                Column {
                                    Text(
                                        text = "Song Language",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                    )
                                    Text(
                                        text = "${uiState.selectedLanguage.englishName} (${uiState.selectedLanguage.nativeLabel})",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary,
                                    )
                                }
                            }
                            Surface(
                                color = StudioModuleElevated,
                                shape = RoundedCornerShape(8.dp),
                            ) {
                                Text(
                                    text = "All ${StudioLanguage.entries.size}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CyanWave,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf(
                                StudioLanguage.HINDI,
                                StudioLanguage.ENGLISH,
                                StudioLanguage.ASSAMESE,
                                StudioLanguage.NEPALI,
                                StudioLanguage.BODO,
                                StudioLanguage.SANSKRIT,
                                StudioLanguage.ADIVASI,
                                StudioLanguage.PUNJABI,
                                StudioLanguage.BENGALI,
                            ).forEach { lang ->
                                val selected = uiState.selectedLanguage == lang
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSelectLanguage(lang) },
                                    label = {
                                        Text(
                                            when (lang) {
                                                StudioLanguage.BODO -> "Bodo / Boro"
                                                StudioLanguage.ADIVASI -> "Aadivasi"
                                                else -> lang.englishName.substringBefore(" ")
                                            },
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                                        selectedLabelColor = CyanWave,
                                    ),
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            ScriptMode.entries.forEach { mode ->
                                val selected = uiState.selectedScriptMode == mode
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSelectScriptMode(mode) },
                                    label = { Text(mode.label, maxLines = 1) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                        selectedLabelColor = AmberVu,
                                    ),
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }
                }
            }

            // HIP-HOP SONG MASTER TEMPLATE Builder
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "HIP-HOP SONG MASTER TEMPLATE",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberVu,
                            )
                            AssistChip(
                                onClick = {
                                    masterDraftInitialTab = 0
                                    showMasterDraftSheet = true
                                },
                                label = { Text("All 160+ Styles") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Tune,
                                        contentDescription = null,
                                        tint = CyanWave,
                                        modifier = Modifier.size(16.dp),
                                    )
                                },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = CyanWave.copy(alpha = 0.14f),
                                    labelColor = CyanWave,
                                ),
                                modifier = Modifier.testTag("open_master_draft_picker_button"),
                            )
                        }

                        // Mode toggle: AI Song Generator vs Put Own Lyrics
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            FilterChip(
                                selected = !useOwnLyricsMode,
                                onClick = { useOwnLyricsMode = false },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                    )
                                },
                                label = { Text("AI Generate Song", maxLines = 1) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                    selectedLabelColor = AmberVu,
                                    selectedLeadingIconColor = AmberVu,
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("ai_generate_mode_chip"),
                            )
                            FilterChip(
                                selected = useOwnLyricsMode,
                                onClick = { useOwnLyricsMode = true },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.EditNote,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                    )
                                },
                                label = { Text("Put Own Lyrics", maxLines = 1) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldMeter.copy(alpha = 0.22f),
                                    selectedLabelColor = EmeraldMeter,
                                    selectedLeadingIconColor = EmeraldMeter,
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("own_lyrics_mode_chip"),
                            )
                        }

                        OutlinedTextField(
                            value = songTitleInput,
                            onValueChange = { songTitleInput = it },
                            label = { Text("Song Title (optional)") },
                            placeholder = { Text("e.g. Brahmaputra Rising") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = StudioObsidian,
                                unfocusedContainerColor = StudioObsidian,
                                focusedBorderColor = AmberVu,
                                unfocusedBorderColor = StudioStroke,
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_song_title_input"),
                        )

                        // Quick tools to put own lyrics: Paste, Import .TXT, Structure Template, Clear
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            AssistChip(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clipText = clipboard.primaryClip?.takeIf { it.itemCount > 0 }
                                        ?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                                    if (clipText.isNotBlank()) {
                                        songPrompt = if (songPrompt.isBlank()) clipText else "$songPrompt\n\n$clipText"
                                    }
                                },
                                label = { Text("Paste Lyrics") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                modifier = Modifier.testTag("ai_studio_paste_lyrics_chip"),
                            )
                            AssistChip(
                                onClick = {
                                    awaitingImportSync = true
                                    onImportOwnLyricsTxt()
                                },
                                label = { Text("Import .TXT") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                modifier = Modifier.testTag("ai_studio_import_txt_chip"),
                            )
                            AssistChip(
                                onClick = {
                                    val scaffold = HipHopMasterTemplate.buildScaffold(
                                        title = songTitleInput,
                                        genre = selectedGenre,
                                        mood = selectedMood,
                                        bpm = if (autoBpm) 94 else customBpm.toInt(),
                                        vocalStyle = selectedVocal,
                                        trackMinutes = selectedMinutes,
                                    )
                                    songPrompt = if (songPrompt.isBlank()) scaffold else "$songPrompt\n\n$scaffold"
                                },
                                label = { Text("+ Master Outline") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                            )
                            if (songPrompt.isNotBlank()) {
                                AssistChip(
                                    onClick = { songPrompt = "" },
                                    label = { Text("Clear") },
                                    leadingIcon = {
                                        Icon(Icons.Rounded.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                                    },
                                )
                            }
                        }

                        // Suno-Style One-Tap Sound & Vibe Prompt Chips
                        if (!useOwnLyricsMode) {
                            Text(
                                text = "Quick AI Style Sparks (Suno-Mode)",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanWave,
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                listOf(
                                    "Dark 808 Trap Anthem" to "Late night hustle, heavy 808 glides, aggressive double-time verse 2, stadium hook",
                                    "Melodic Soul Hook" to "Heartbreak to triumph story, warm piano chords, catchy singing hook, crisp vocal harmonies",
                                    "Desi Folk Drill" to "Cultural roots meet sliding 808 drill bass, energetic street pride bars, tabla & flute drop",
                                    "Chopper Lyrical Showcase" to "Rapid multisyllabic chopper cadence, clever wordplay, breath-control showcase",
                                ).forEach { (chipTitle, sparkPrompt) ->
                                    AssistChip(
                                        onClick = { songPrompt = sparkPrompt },
                                        label = { Text(chipTitle) },
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = songPrompt,
                            onValueChange = { songPrompt = it },
                            label = {
                                Text(
                                    if (useOwnLyricsMode) {
                                        "Your Own Lyrics (Perform & Record Directly)"
                                    } else {
                                        "Your Lyrics / Theme / Story"
                                    },
                                )
                            },
                            placeholder = {
                                Text(
                                    if (useOwnLyricsMode) {
                                        "Type or paste your complete verses, hooks, and bars here — they will go straight to the Booth & Lyric Pad without AI changes."
                                    } else {
                                        "Paste starting lines or describe the theme (Intro -> Hook -> Verse 1 -> Pre-Hook -> Verse 2 -> Bridge -> Final Hook -> Outro)"
                                    },
                                )
                            },
                            minLines = if (useOwnLyricsMode) 6 else 3,
                            maxLines = if (useOwnLyricsMode) 12 else 5,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = StudioObsidian,
                                unfocusedContainerColor = StudioObsidian,
                                focusedBorderColor = if (useOwnLyricsMode) EmeraldMeter else AmberVu,
                                unfocusedBorderColor = StudioStroke,
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_song_prompt_input"),
                        )

                        // Track Length (3 Min / 5 Min / 10 Min)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Timer,
                                    contentDescription = null,
                                    tint = CyanWave,
                                    modifier = Modifier.size(18.dp),
                                )
                                Text(
                                    text = "Track Duration",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = TextSecondary,
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                listOf(
                                    3 to "3 Min (Radio)",
                                    5 to "5 Min (Extended)",
                                    10 to "10 Min (Epic)",
                                ).forEach { (mins, label) ->
                                    val selected = selectedMinutes == mins
                                    FilterChip(
                                        selected = selected,
                                        onClick = { selectedMinutes = mins },
                                        label = { Text(label, maxLines = 1) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                                            selectedLabelColor = CyanWave,
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("duration_${mins}_min_chip"),
                                    )
                                }
                            }
                        }

                        // Genre / Ultimate Combos
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Genre / Subgenre",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextSecondary,
                            )
                            Text(
                                text = "Browse 160+",
                                style = MaterialTheme.typography.labelMedium,
                                color = CyanWave,
                                modifier = Modifier.clickable {
                                    masterDraftInitialTab = 0
                                    showMasterDraftSheet = true
                                },
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            quickGenres.forEach { g ->
                                FilterChip(
                                    selected = selectedGenre.equals(g, ignoreCase = true),
                                    onClick = { selectedGenre = g },
                                    label = { Text(g) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                        selectedLabelColor = AmberVu,
                                    ),
                                )
                            }
                        }

                        // Ultimate Rap Combinations Quick Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Ultimate Style Combos",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextSecondary,
                            )
                            Text(
                                text = "All 20",
                                style = MaterialTheme.typography.labelMedium,
                                color = AmberVu,
                                modifier = Modifier.clickable {
                                    masterDraftInitialTab = 1
                                    showMasterDraftSheet = true
                                },
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            RapStyleEncyclopedia.ultimateCombinations.take(6).forEach { combo ->
                                FilterChip(
                                    selected = selectedGenre.equals(combo, ignoreCase = true),
                                    onClick = { selectedGenre = combo },
                                    label = { Text(combo) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                        selectedLabelColor = AmberVu,
                                    ),
                                )
                            }
                        }

                        // Mood
                        Text(
                            text = "Mood",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextSecondary,
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            moods.forEach { m ->
                                FilterChip(
                                    selected = selectedMood == m,
                                    onClick = { selectedMood = m },
                                    label = { Text(m) },
                                )
                            }
                        }

                        // Vocal Delivery Style
                        Text(
                            text = "Vocal",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextSecondary,
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            vocalStyles.forEach { v ->
                                FilterChip(
                                    selected = selectedVocal == v,
                                    onClick = { selectedVocal = v },
                                    label = { Text(v) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldMeter.copy(alpha = 0.2f),
                                        selectedLabelColor = EmeraldMeter,
                                    ),
                                )
                            }
                        }

                        // Flow, Lyric Craft & Production Selectors (All 75 Techniques)
                        Text(
                            text = "Master Craft (Flow • Lyrics • Production)",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextSecondary,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            MasterCraftButton(
                                label = "Flow",
                                value = selectedFlow,
                                onClick = {
                                    masterDraftInitialTab = 2
                                    showMasterDraftSheet = true
                                },
                                modifier = Modifier.weight(1f),
                            )
                            MasterCraftButton(
                                label = "Lyric Craft",
                                value = selectedLyricTechnique,
                                onClick = {
                                    masterDraftInitialTab = 3
                                    showMasterDraftSheet = true
                                },
                                modifier = Modifier.weight(1f),
                            )
                            MasterCraftButton(
                                label = "Beat Style",
                                value = selectedProduction,
                                onClick = {
                                    masterDraftInitialTab = 4
                                    showMasterDraftSheet = true
                                },
                                modifier = Modifier.weight(1f),
                            )
                        }

                        // BPM Control
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = if (autoBpm) "BPM: Auto-match genre" else "BPM: ${customBpm.toInt()}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = AmberVu,
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Text("Auto BPM", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Switch(checked = autoBpm, onCheckedChange = { autoBpm = it })
                                }
                            }
                            if (!autoBpm) {
                                Slider(
                                    value = customBpm,
                                    onValueChange = { customBpm = it },
                                    valueRange = 60f..180f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = AmberVu,
                                        activeTrackColor = AmberVu,
                                    ),
                                )
                            }
                        }

                        // Action Buttons: Own Lyrics Direct Load OR AI Generate + Blank Master Template
                        val isLoading = uiState.aiSongState is AiSongUiState.Loading
                        if (useOwnLyricsMode) {
                            Button(
                                onClick = {
                                    val loaded = onLoadOwnLyricsIntoStudio(
                                        songTitleInput,
                                        songPrompt,
                                        selectedGenre,
                                        if (autoBpm) null else customBpm.toInt(),
                                        selectedVocal,
                                        selectedMinutes,
                                        true,
                                    )
                                    if (loaded) {
                                        onOpenBoothTab()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldMeter,
                                    contentColor = StudioObsidian,
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("load_own_lyrics_booth_button"),
                            ) {
                                Icon(Icons.Rounded.Mic, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Use My Own Lyrics in Booth & Play Beat",
                                    fontWeight = FontWeight.Bold,
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    val loaded = onLoadOwnLyricsIntoStudio(
                                        songTitleInput,
                                        songPrompt,
                                        selectedGenre,
                                        if (autoBpm) null else customBpm.toInt(),
                                        selectedVocal,
                                        selectedMinutes,
                                        false,
                                    )
                                    if (loaded) {
                                        onOpenLyricsTab()
                                    }
                                },
                                border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("open_own_lyrics_pad_button"),
                            ) {
                                Icon(Icons.Rounded.EditNote, contentDescription = null, tint = CyanWave)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Save & Edit Own Lyrics in Lyric Pad", color = CyanWave)
                            }
                        } else {
                            Button(
                                onClick = {
                                    onGenerateSong(
                                        songTitleInput,
                                        songPrompt,
                                        selectedGenre,
                                        selectedMood,
                                        selectedVocal,
                                        selectedFlow,
                                        selectedLyricTechnique,
                                        selectedProduction,
                                        if (autoBpm) null else customBpm.toInt(),
                                        selectedMinutes,
                                    )
                                },
                                enabled = !isLoading,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AmberVu,
                                    contentColor = StudioObsidian,
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("generate_ai_song_button"),
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = StudioObsidian,
                                        strokeWidth = 2.dp,
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text("Crafting $selectedMinutes-Min Master Track...", fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Generate $selectedMinutes-Min Song (${uiState.selectedLanguage.englishName})",
                                        fontWeight = FontWeight.Bold,
                                    )
                                }
                            }

                            if (songPrompt.isNotBlank()) {
                                OutlinedButton(
                                    onClick = {
                                        val loaded = onLoadOwnLyricsIntoStudio(
                                            songTitleInput,
                                            songPrompt,
                                            selectedGenre,
                                            if (autoBpm) null else customBpm.toInt(),
                                            selectedVocal,
                                            selectedMinutes,
                                            true,
                                        )
                                        if (loaded) {
                                            onOpenBoothTab()
                                        }
                                    },
                                    border = BorderStroke(1.dp, EmeraldMeter.copy(alpha = 0.65f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .minimumInteractiveComponentSize()
                                        .testTag("use_prompt_as_own_lyrics_button"),
                                ) {
                                    Icon(Icons.Rounded.Mic, contentDescription = null, tint = EmeraldMeter)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Use My Lyrics Directly (Skip AI)", color = EmeraldMeter)
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    onLoadMasterTemplateScaffold(
                                        songTitleInput,
                                        selectedGenre,
                                        selectedMood,
                                        if (autoBpm) 94 else customBpm.toInt(),
                                        selectedVocal,
                                        selectedMinutes,
                                    )
                                    onOpenLyricsTab()
                                },
                                border = BorderStroke(1.dp, StudioStroke),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("load_blank_master_template_button"),
                            ) {
                                Icon(Icons.Rounded.Description, contentDescription = null, tint = CyanWave)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Insert Blank $selectedMinutes-Min Master Template in Pad", color = CyanWave)
                            }
                        }
                    }
                }
            }

            // Generated Song Result
            when (val songState = uiState.aiSongState) {
                is AiSongUiState.Error -> {
                    item {
                        Card(
                            shape = MaterialTheme.shapes.medium,
                            border = BorderStroke(1.dp, CrimsonRec),
                            colors = CardDefaults.cardColors(containerColor = CrimsonRec.copy(alpha = 0.14f)),
                        ) {
                            Text(
                                text = songState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CrimsonRec,
                                modifier = Modifier.padding(14.dp),
                            )
                        }
                    }
                }

                is AiSongUiState.Success -> {
                    item {
                        val song = songState.song
                        Card(
                            shape = MaterialTheme.shapes.large,
                            border = BorderStroke(1.5.dp, EmeraldMeter.copy(alpha = 0.7f)),
                            colors = CardDefaults.cardColors(containerColor = StudioModule),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${song.trackMinutes} MIN MASTER • ${song.vocalStyle.uppercase()} VOCAL",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = EmeraldMeter,
                                        )
                                        Text(
                                            text = song.title,
                                            style = MaterialTheme.typography.headlineSmall,
                                            color = TextPrimary,
                                        )
                                    }
                                    Surface(
                                        color = AmberVu.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(10.dp),
                                    ) {
                                        Text(
                                            text = "${song.recommendedBpm} BPM • ${song.recommendedBeatStyle.displayName}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AmberVu,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        )
                                    }
                                }

                                Surface(
                                    color = StudioObsidian,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, StudioStroke.copy(alpha = 0.6f)),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp),
                                    ) {
                                        Text(
                                            text = "Chords: ${song.chordProgression}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = CyanWave,
                                        )
                                        Text(
                                            text = "Booth Delivery: ${song.vocalDeliveryNotes}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                        )
                                    }
                                }

                                Surface(
                                    color = StudioObsidian,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Text(
                                        text = song.lyrics,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary,
                                        modifier = Modifier.padding(14.dp),
                                    )
                                }

                                val isProducingTrack = uiState.isProcessingVoiceClone
                                val selectedProfileName = uiState.voiceProfiles
                                    .firstOrNull { it.id == uiState.selectedVoiceProfileId }?.name ?: "Cloned Voice"

                                Button(
                                    onClick = { onProduceFullSongWithClone(song) },
                                    enabled = !isProducingTrack,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AmberVu,
                                        contentColor = StudioObsidian,
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .minimumInteractiveComponentSize()
                                        .testTag("produce_full_song_with_clone_button"),
                                ) {
                                    if (isProducingTrack) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(18.dp),
                                            color = StudioObsidian,
                                            strokeWidth = 2.dp,
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Producing Beat + $selectedProfileName...", fontWeight = FontWeight.Bold)
                                    } else {
                                        Icon(Icons.Rounded.GraphicEq, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Produce Full Song (Beat + $selectedProfileName)",
                                            fontWeight = FontWeight.Bold,
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        onLoadSongIntoBooth(song, true)
                                        onOpenBoothTab()
                                    },
                                    border = BorderStroke(1.dp, EmeraldMeter.copy(alpha = 0.7f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .minimumInteractiveComponentSize()
                                        .testTag("load_ai_song_booth_button"),
                                ) {
                                    Icon(Icons.Rounded.Mic, contentDescription = null, tint = EmeraldMeter)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open in Booth & Record My Own Mic", color = EmeraldMeter, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                else -> Unit
            }

            // AI Co-Writer & Translator
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "LIVE STUDIO CO-WRITER & TRANSLATOR",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanWave,
                                )
                                Text(
                                    text = "Active: ${uiState.activeProject?.title ?: "Session"}",
                                    style = MaterialTheme.typography.titleMedium,
                                )
                            }

                            OutlinedButton(
                                onClick = onToggleFlowVoicePreview,
                                border = BorderStroke(1.dp, AmberVu.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(10.dp),
                            ) {
                                Icon(
                                    imageVector = if (uiState.isFlowVoiceSpeaking) Icons.Rounded.Stop else Icons.Rounded.RecordVoiceOver,
                                    contentDescription = null,
                                    tint = AmberVu,
                                    modifier = Modifier.size(18.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (uiState.isFlowVoiceSpeaking) "Stop Voice" else "Hear Flow",
                                    color = AmberVu,
                                )
                            }
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            AssistChip(
                                onClick = {
                                    onRunCoWriter(
                                        "Write the next 4 killer rhyming bars using $selectedFlow and $selectedLyricTechnique that seamlessly continue the rhyme scheme.",
                                        false,
                                    )
                                },
                                label = { Text("+4 Next Bars") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.GraphicEq, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                            )
                            AssistChip(
                                onClick = {
                                    onRunCoWriter(
                                        "Write a [Hook / Chorus – 8 Bars] section with a catchy, unforgettable melody and tight rhyme pattern.",
                                        false,
                                    )
                                },
                                label = { Text("+ 8-Bar Hook") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                            )
                            AssistChip(
                                onClick = {
                                    onRunCoWriter(
                                        "Translate and poetically adapt these entire lyrics into ${uiState.selectedLanguage.englishName} while preserving all Hip-Hop Master Template section headers, rap rhythm, and end rhymes.",
                                        true,
                                    )
                                },
                                label = { Text("Translate to ${uiState.selectedLanguage.englishName.substringBefore(" ")}") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.Translate, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                            )
                            AssistChip(
                                onClick = {
                                    onRunCoWriter(
                                        "Upgrade these lyrics with sharper $selectedLyricTechnique, callback punchlines, and double entendres.",
                                        false,
                                    )
                                },
                                label = { Text("Upgrade Punchlines") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                            )
                        }

                        when (val assist = uiState.aiAssistState) {
                            is AiAssistUiState.Loading -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = CyanWave, strokeWidth = 2.dp)
                                    Text("Writing bars in ${uiState.selectedLanguage.englishName}...", color = TextSecondary)
                                }
                            }
                            is AiAssistUiState.Streaming -> {
                                Surface(
                                    color = StudioObsidian,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Text(
                                        text = assist.text,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary,
                                        modifier = Modifier.padding(12.dp),
                                    )
                                }
                            }
                            is AiAssistUiState.Success -> {
                                Surface(
                                    color = StudioObsidian,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Text(
                                        text = assist.text,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary,
                                        modifier = Modifier.padding(12.dp),
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = onAppendCoWriter,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = CyanWave,
                                            contentColor = StudioObsidian,
                                        ),
                                        modifier = Modifier.weight(1f),
                                    ) {
                                        Text("Append to Pad", fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedButton(
                                        onClick = onReplaceWithCoWriter,
                                        modifier = Modifier.weight(1f),
                                    ) {
                                        Text("Replace Pad")
                                    }
                                }
                            }
                            is AiAssistUiState.Error -> {
                                Text(
                                    text = assist.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CrimsonRec,
                                )
                            }
                            AiAssistUiState.Idle -> Unit
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(14.dp)) }
        }
    }

    if (showLanguagePicker) {
        LanguagePickerSheet(
            selected = uiState.selectedLanguage,
            onSelect = {
                onSelectLanguage(it)
                showLanguagePicker = false
            },
            onDismiss = { showLanguagePicker = false },
        )
    }

    if (showMasterDraftSheet) {
        RapMasterDraftPickerSheet(
            initialTab = masterDraftInitialTab,
            selectedGenre = selectedGenre,
            selectedFlow = selectedFlow,
            selectedLyricTechnique = selectedLyricTechnique,
            selectedProduction = selectedProduction,
            onSelectGenre = {
                selectedGenre = it
                showMasterDraftSheet = false
            },
            onSelectFlow = {
                selectedFlow = it
                showMasterDraftSheet = false
            },
            onSelectLyricTechnique = {
                selectedLyricTechnique = it
                showMasterDraftSheet = false
            },
            onSelectProduction = {
                selectedProduction = it
                showMasterDraftSheet = false
            },
            onSelectCombination = {
                selectedGenre = it
                showMasterDraftSheet = false
            },
            onDismiss = { showMasterDraftSheet = false },
        )
    }
}

@Composable
private fun MasterCraftButton(
    label: String,
    value: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = StudioObsidian,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, StudioStroke),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clickable { onClick() },
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = CyanWave,
            )
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

