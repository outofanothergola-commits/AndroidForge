package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FiberManualRecord
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Transform
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.audio.VocalClarityMode
import com.example.audio.VoiceCloneRealismMode
import com.example.audio.detectTakeAudioFormatLabel
import com.example.data.StudioLanguage
import com.example.data.local.VocalTake
import com.example.data.local.VoiceProfile
import com.example.ui.components.LanguagePickerSheet
import com.example.ui.components.LiveWaveformCanvas
import com.example.ui.components.StudioBadge
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CrimsonRec
import com.example.ui.theme.CyanWave
import com.example.ui.theme.EmeraldMeter
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioRack
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StudioUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceCloneScreen(
    uiState: StudioUiState,
    onSelectLanguage: (StudioLanguage) -> Unit,
    onSelectVoiceProfile: (Long) -> Unit,
    onToggleRecordVoiceSample: (profileName: String) -> Unit,
    onImportVoiceSample: (profileName: String) -> Unit,
    onCloneProfileFromTake: (VocalTake, profileName: String) -> Unit,
    onDeleteVoiceProfile: (VoiceProfile) -> Unit,
    onSelectClarityMode: (VocalClarityMode) -> Unit,
    onUpdateClarityBoost: (Float) -> Unit,
    onGenerateClonedVoiceFromLyrics: (
        customLyrics: String?,
        pitchSemitones: Float,
        formantOffset: Float,
        gritBoost: Float,
        mixWithBeat: Boolean,
        realismMode: VoiceCloneRealismMode,
        clarityBoost: Float,
        stereoDoubleLayer: Boolean,
    ) -> Unit,
    onMorphTakeWithClone: (
        take: VocalTake,
        pitchSemitones: Float,
        formantOffset: Float,
        gritBoost: Float,
        mixWithBeat: Boolean,
        realismMode: VoiceCloneRealismMode,
        clarityBoost: Float,
        stereoDoubleLayer: Boolean,
    ) -> Unit,
    onToggleTakePlay: (VocalTake) -> Unit,
    onInspectTakeDetails: (VocalTake) -> Unit,
    onDismissAudioDetails: () -> Unit,
    onExportTake: (VocalTake) -> Unit,
    onOpenBoothTab: () -> Unit,
    onOpenVideoTab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        hasMicPermission = granted
    }

    var profileNameInput by remember { mutableStateOf("") }
    var useMorphTakeMode by remember { mutableStateOf(false) }
    var customLyricsInput by remember { mutableStateOf("") }
    var useProjectLyrics by remember { mutableStateOf(true) }
    var selectedSourceTakeId by remember { mutableStateOf<Long?>(null) }
    var pitchSemitones by remember { mutableFloatStateOf(0f) }
    var formantScale by remember { mutableFloatStateOf(1.0f) }
    var gritBoost by remember { mutableFloatStateOf(0.05f) }
    var realismMode by remember { mutableStateOf(VoiceCloneRealismMode.CRYSTAL_RAP_HD) }
    var stereoDoubleLayer by remember { mutableStateOf(true) }
    var mixWithBeat by remember { mutableStateOf(true) }
    var showLanguagePicker by remember { mutableStateOf(false) }

    val selectedProfile = uiState.voiceProfiles.firstOrNull { it.id == uiState.selectedVoiceProfileId }
    val clonedOutputs = remember(uiState.activeTakes) {
        uiState.activeTakes.filter {
            it.title.startsWith("Clone", ignoreCase = true) || it.title.startsWith("Morph", ignoreCase = true)
        }
    }
    val rawOrMasterTakes = remember(uiState.activeTakes) { uiState.activeTakes }
    val activeSourceTake = rawOrMasterTakes.firstOrNull { it.id == selectedSourceTakeId } ?: rawOrMasterTakes.firstOrNull()

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "REALISTIC VOICE CLONE STUDIO",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldMeter,
                        )
                        Text(
                            text = "48kHz Acoustic Voice Twin",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary,
                        )
                    }
                    StudioBadge(label = uiState.selectedPcmFormat.shortBadge, accentColor = CyanWave)
                }
            }

            // Step 1: Capture / Import Voice Sample to Clone
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.45f)),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = "1. CLONE YOUR VOICE (CAPTURE OR IMPORT)",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanWave,
                        )
                        Text(
                            text = "Record 5–15 seconds of your natural speaking or rapping voice (or import an audio clip) to extract fundamental pitch F₀, formant resonance, and vocal grit.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )

                        OutlinedTextField(
                            value = profileNameInput,
                            onValueChange = { profileNameInput = it },
                            label = { Text("Voice Clone Name") },
                            placeholder = { Text("e.g. psycho Studio Voice") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = StudioObsidian,
                                unfocusedContainerColor = StudioObsidian,
                                focusedBorderColor = CyanWave,
                                unfocusedBorderColor = StudioStroke,
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("voice_clone_name_input"),
                        )

                        if (uiState.isRecordingVoiceSample) {
                            LiveWaveformCanvas(
                                amplitudes = uiState.waveformBars,
                                isRecording = true,
                                isBeatPlaying = false,
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Button(
                                onClick = {
                                    if (!hasMicPermission) {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        onToggleRecordVoiceSample(profileNameInput)
                                    }
                                },
                                enabled = !uiState.isProcessingVoiceClone,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (uiState.isRecordingVoiceSample) CrimsonRec else AmberVu,
                                    contentColor = if (uiState.isRecordingVoiceSample) TextPrimary else StudioObsidian,
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("record_voice_clone_button"),
                            ) {
                                Icon(
                                    imageVector = if (uiState.isRecordingVoiceSample) Icons.Rounded.Stop else Icons.Rounded.FiberManualRecord,
                                    contentDescription = null,
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (uiState.isRecordingVoiceSample) {
                                        "Stop & Analyze"
                                    } else if (!hasMicPermission) {
                                        "Allow Mic"
                                    } else {
                                        "Record Sample"
                                    },
                                    fontWeight = FontWeight.Bold,
                                )
                            }

                            OutlinedButton(
                                onClick = { onImportVoiceSample(profileNameInput) },
                                enabled = !uiState.isProcessingVoiceClone && !uiState.isRecordingVoiceSample,
                                border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("import_voice_clone_button"),
                            ) {
                                Icon(Icons.Rounded.UploadFile, contentDescription = null, tint = CyanWave)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Import Audio", color = CyanWave)
                            }
                        }

                        if (rawOrMasterTakes.isNotEmpty()) {
                            Text(
                                text = "Or extract Voiceprint from an existing Booth take:",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                rawOrMasterTakes.take(5).forEach { take ->
                                    AssistChip(
                                        onClick = { onCloneProfileFromTake(take, profileNameInput) },
                                        enabled = !uiState.isProcessingVoiceClone,
                                        label = { Text("Clone ${take.title}") },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Step 2: Saved Voice Profiles & Extracted Acoustic DNA
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "2. VOICE CLONE PROFILES (${uiState.voiceProfiles.size})",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberVu,
                            )
                            if (uiState.isProcessingVoiceClone) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), color = CyanWave, strokeWidth = 2.dp)
                                    Text("Synthesizing 48kHz...", style = MaterialTheme.typography.labelSmall, color = CyanWave)
                                }
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            uiState.voiceProfiles.forEach { profile ->
                                val selected = profile.id == selectedProfile?.id
                                Surface(
                                    color = if (selected) EmeraldMeter.copy(alpha = 0.14f) else StudioModuleElevated,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(
                                        1.dp,
                                        if (selected) EmeraldMeter else StudioStroke.copy(alpha = 0.6f),
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelectVoiceProfile(profile.id) }
                                        .testTag("voice_profile_card_${profile.id}"),
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    ) {
                                        Icon(
                                            imageVector = if (selected) Icons.Rounded.CheckCircle else Icons.Rounded.RecordVoiceOver,
                                            contentDescription = null,
                                            tint = if (selected) EmeraldMeter else CyanWave,
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            ) {
                                                Text(
                                                    text = profile.name,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    color = TextPrimary,
                                                )
                                                if (!profile.isPreset) {
                                                    Surface(
                                                        color = AmberVu.copy(alpha = 0.18f),
                                                        shape = RoundedCornerShape(6.dp),
                                                    ) {
                                                        Text(
                                                            text = "CLONED",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = AmberVu,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                }
                                            }
                                            Text(
                                                text = profile.timbreSummary,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = CyanWave,
                                            )
                                            if (profile.aiPersonaNotes.isNotBlank()) {
                                                Text(
                                                    text = profile.aiPersonaNotes,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = TextSecondary,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                        }
                                        if (!profile.isPreset) {
                                            IconButton(onClick = { onDeleteVoiceProfile(profile) }) {
                                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete profile", tint = TextMuted)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Step 3: Clone Generator Engine (Lyrics -> Voice OR Morph Real Take)
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, EmeraldMeter.copy(alpha = 0.45f)),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = "3. GENERATE OR MORPH WITH CLONED VOICE",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldMeter,
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            FilterChip(
                                selected = !useMorphTakeMode,
                                onClick = { useMorphTakeMode = false },
                                leadingIcon = { Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text("Lyrics -> Cloned Voice", maxLines = 1) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldMeter.copy(alpha = 0.22f),
                                    selectedLabelColor = EmeraldMeter,
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("clone_lyrics_mode_chip"),
                            )
                            FilterChip(
                                selected = useMorphTakeMode,
                                onClick = { useMorphTakeMode = true },
                                leadingIcon = { Icon(Icons.Rounded.Transform, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text("Morph Real Take", maxLines = 1) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                                    selectedLabelColor = CyanWave,
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("clone_morph_mode_chip"),
                            )
                        }

                        if (!useMorphTakeMode) {
                            // Language Selector for Multilingual Cloned Voice Singing/Rapping
                            Surface(
                                color = StudioModuleElevated,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, StudioStroke),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showLanguagePicker = true },
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Icon(Icons.Rounded.Language, contentDescription = null, tint = CyanWave)
                                        Column {
                                            Text("Voice Output Language", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                            Text(
                                                text = "${uiState.selectedLanguage.englishName} (${uiState.selectedLanguage.nativeLabel})",
                                                style = MaterialTheme.typography.titleSmall,
                                                color = TextPrimary,
                                            )
                                        }
                                    }
                                    Text("Change", style = MaterialTheme.typography.labelMedium, color = CyanWave)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text("Use Active Project Lyrics", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                                Switch(
                                    checked = useProjectLyrics,
                                    onCheckedChange = { useProjectLyrics = it },
                                    colors = SwitchDefaults.colors(checkedTrackColor = EmeraldMeter, checkedThumbColor = StudioObsidian),
                                )
                            }

                            if (!useProjectLyrics) {
                                OutlinedTextField(
                                    value = customLyricsInput,
                                    onValueChange = { customLyricsInput = it },
                                    label = { Text("Custom Bars / Hook for Cloned Voice") },
                                    minLines = 3,
                                    maxLines = 6,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = StudioObsidian,
                                        unfocusedContainerColor = StudioObsidian,
                                        focusedBorderColor = EmeraldMeter,
                                        unfocusedBorderColor = StudioStroke,
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            } else {
                                Text(
                                    text = if (uiState.lyricsDraft.isBlank()) {
                                        "Lyric Pad is currently empty — generate lyrics in AI Lab or write in Lyrics tab first."
                                    } else {
                                        "Ready to voice ${uiState.lyricStats.barCount} bars from \"${uiState.activeProject?.title ?: "Track"}\"."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                )
                            }
                        } else {
                            if (rawOrMasterTakes.isEmpty()) {
                                Text(
                                    text = "Record a vocal take in Booth first to morph your voice recording into another cloned timbre.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AmberVu,
                                )
                            } else {
                                Text("Select Vocal Take to Morph:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    rawOrMasterTakes.forEach { take ->
                                        FilterChip(
                                            selected = activeSourceTake?.id == take.id,
                                            onClick = { selectedSourceTakeId = take.id },
                                            label = { Text(take.title) },
                                        )
                                    }
                                }
                            }
                        }

                        // Realism Engine Mode & Clarity Engine
                        Text("Clone Realism Engine", style = MaterialTheme.typography.labelLarge, color = CyanWave)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            VoiceCloneRealismMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = realismMode == mode,
                                    onClick = { realismMode = mode },
                                    label = { Text(mode.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                                        selectedLabelColor = CyanWave,
                                    ),
                                )
                            }
                        }

                        Text("Vocal Clarity Engine", style = MaterialTheme.typography.labelLarge, color = EmeraldMeter)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            VocalClarityMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = uiState.selectedVocalClarityMode == mode,
                                    onClick = { onSelectClarityMode(mode) },
                                    label = { Text(mode.displayName) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldMeter.copy(alpha = 0.22f),
                                        selectedLabelColor = EmeraldMeter,
                                    ),
                                )
                            }
                        }

                        CloneSliderRow(
                            label = "Vocal Clarity & Consonants",
                            valueText = "${(uiState.vocalClarityBoost * 100).toInt()}%",
                            value = uiState.vocalClarityBoost,
                            range = 0f..1f,
                            onValueChange = onUpdateClarityBoost,
                        )

                        CloneSliderRow(
                            label = "Pitch Shift",
                            valueText = "${if (pitchSemitones >= 0f) "+" else ""}${pitchSemitones.toInt()} st",
                            value = pitchSemitones,
                            range = -8f..8f,
                            onValueChange = { pitchSemitones = it },
                        )
                        CloneSliderRow(
                            label = "Formant / Throat",
                            valueText = "${String.format("%.2f", formantScale)}x",
                            value = formantScale,
                            range = 0.80f..1.25f,
                            onValueChange = { formantScale = it },
                        )
                        CloneSliderRow(
                            label = "Vocal Grit",
                            valueText = "${(gritBoost * 100).toInt()}%",
                            value = gritBoost,
                            range = 0f..0.45f,
                            onValueChange = { gritBoost = it },
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Stereo Hook Layer (L/R Double)", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                Text("Adds studio width & crisp vocal double stack", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                            Switch(
                                checked = stereoDoubleLayer,
                                onCheckedChange = { stereoDoubleLayer = it },
                                colors = SwitchDefaults.colors(checkedTrackColor = CyanWave, checkedThumbColor = StudioObsidian),
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Mix Over Studio Beat", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                Text(
                                    text = "Render full 48kHz / ${uiState.selectedPcmFormat.displayName} track with beat sidechain",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                )
                            }
                            Switch(
                                checked = mixWithBeat,
                                onCheckedChange = { mixWithBeat = it },
                                colors = SwitchDefaults.colors(checkedTrackColor = AmberVu, checkedThumbColor = StudioObsidian),
                            )
                        }

                        if (uiState.isProcessingVoiceClone) {
                            LinearProgressIndicator(
                                color = EmeraldMeter,
                                trackColor = StudioObsidian,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }

                        Button(
                            onClick = {
                                if (!useMorphTakeMode) {
                                    onGenerateClonedVoiceFromLyrics(
                                        if (useProjectLyrics) null else customLyricsInput,
                                        pitchSemitones,
                                        formantScale,
                                        gritBoost,
                                        mixWithBeat,
                                        realismMode,
                                        uiState.vocalClarityBoost,
                                        stereoDoubleLayer,
                                    )
                                } else {
                                    activeSourceTake?.let { take ->
                                        onMorphTakeWithClone(
                                            take,
                                            pitchSemitones,
                                            formantScale,
                                            gritBoost,
                                            mixWithBeat,
                                            realismMode,
                                            uiState.vocalClarityBoost,
                                            stereoDoubleLayer,
                                        )
                                    }
                                }
                            },
                            enabled = !uiState.isProcessingVoiceClone &&
                                selectedProfile != null &&
                                (!useMorphTakeMode || activeSourceTake != null),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldMeter,
                                contentColor = StudioObsidian,
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("generate_cloned_voice_button"),
                        ) {
                            Icon(Icons.Rounded.GraphicEq, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (!useMorphTakeMode) {
                                    "Generate Cloned Voice Track (${selectedProfile?.name ?: "Select Voice"})"
                                } else {
                                    "Morph Take into ${selectedProfile?.name ?: "Voice Clone"}"
                                },
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }

            // Recent Cloned Voice Outputs
            if (clonedOutputs.isNotEmpty()) {
                item {
                    Text(
                        text = "GENERATED CLONE TRACKS (${clonedOutputs.size})",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary,
                    )
                }
                items(clonedOutputs, key = { it.id }) { take ->
                    val isPlaying = uiState.playingTakeId == take.id
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(1.dp, if (isPlaying) CyanWave else EmeraldMeter.copy(alpha = 0.45f)),
                        colors = CardDefaults.cardColors(containerColor = StudioModule),
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Surface(
                                    color = if (isPlaying) CyanWave else EmeraldMeter.copy(alpha = 0.2f),
                                    shape = CircleShape,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clickable { onToggleTakePlay(take) },
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                            contentDescription = "Play cloned vocal",
                                            tint = if (isPlaying) StudioObsidian else EmeraldMeter,
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    val formatBadge by produceState(
                                        initialValue = "48kHz WAV",
                                        take.filePath,
                                    ) {
                                        value = withContext(Dispatchers.IO) {
                                            detectTakeAudioFormatLabel(take.filePath)
                                        }
                                    }
                                    Text(take.title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                    Text(
                                        text = "${(take.durationMs / 1000L).coerceAtLeast(1L)}s • $formatBadge",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                    )
                                }
                                IconButton(onClick = { onInspectTakeDetails(take) }) {
                                    Icon(Icons.Rounded.Info, contentDescription = "Audio telemetry", tint = EmeraldMeter)
                                }
                                IconButton(onClick = { onExportTake(take) }) {
                                    Icon(Icons.Rounded.Download, contentDescription = "Export audio", tint = TextPrimary)
                                }
                                IconButton(onClick = onOpenVideoTab) {
                                    Icon(Icons.Rounded.MovieCreation, contentDescription = "Make lyrical video", tint = AmberVu)
                                }
                                IconButton(onClick = onOpenBoothTab) {
                                    Icon(Icons.Rounded.Mic, contentDescription = "Open in Booth", tint = CyanWave)
                                }
                            }
                            if (isPlaying) {
                                LinearProgressIndicator(
                                    progress = { uiState.takePlaybackProgress },
                                    color = CyanWave,
                                    trackColor = StudioObsidian,
                                    modifier = Modifier.fillMaxWidth().height(4.dp),
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }

    if (showLanguagePicker) {
        LanguagePickerSheet(
            selected = uiState.selectedLanguage,
            onSelect = {
                onSelectLanguage(it)
                showLanguagePicker = false
            },
            onDismiss = { showLanguagePicker = false },
        )
    }

    uiState.inspectedAudioDetails?.let { report ->
        AudioDetailsDialog(
            report = report,
            onDismiss = onDismissAudioDetails,
        )
    }
}

@Composable
private fun CloneSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Text(valueText, style = MaterialTheme.typography.labelMedium, color = CyanWave)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = EmeraldMeter,
                activeTrackColor = EmeraldMeter,
            ),
        )
    }
}
