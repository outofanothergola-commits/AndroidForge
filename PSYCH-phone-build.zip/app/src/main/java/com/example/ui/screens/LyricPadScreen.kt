package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.RapStyleEncyclopedia
import com.example.data.StudioLanguage
import com.example.lyrics.AnalyzedLine
import com.example.ui.components.LanguagePickerSheet
import com.example.ui.components.RhymeHelperSheet
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CyanWave
import com.example.ui.theme.EmeraldMeter
import com.example.ui.theme.RhymeColors
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioRack
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StudioUiState

@Composable
fun LyricPadScreen(
    uiState: StudioUiState,
    onLyricsChange: (String) -> Unit,
    onInsertSection: (String) -> Unit,
    onCopyLyrics: () -> Unit,
    onExportLyricsTxt: () -> Unit,
    onShareLyrics: () -> Unit,
    onRhymeQueryChange: (String) -> Unit,
    onSelectLanguage: (StudioLanguage) -> Unit,
    onToggleFlowVoicePreview: () -> Unit,
    onSelectTrackMinutes: (Int) -> Unit,
    onInsertMasterTemplate: () -> Unit,
    onPasteLyrics: () -> Unit,
    onImportLyricsTxt: () -> Unit,
    onClearLyrics: () -> Unit,
    onOpenBoothTab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var flowMapMode by remember { mutableStateOf(false) }
    var showRhymeSheet by remember { mutableStateOf(false) }
    var showLanguagePicker by remember { mutableStateOf(false) }

    val stats = uiState.lyricStats
    val project = uiState.activeProject
    val trackMinutes = project?.trackMinutes ?: 3
    val targetBars = when {
        trackMinutes >= 10 -> 160
        trackMinutes >= 5 -> 108
        else -> 72
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Header + Mode Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "LYRIC PAD • ${uiState.selectedLanguage.nativeLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberVu,
                    )
                    Text(
                        text = project?.title ?: "Session 01",
                        style = MaterialTheme.typography.headlineSmall,
                        color = TextPrimary,
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !flowMapMode,
                        onClick = { flowMapMode = false },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.EditNote,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                        },
                        label = { Text("Write") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                            selectedLabelColor = AmberVu,
                            selectedLeadingIconColor = AmberVu,
                        ),
                        modifier = Modifier.testTag("lyric_write_mode_chip"),
                    )
                    FilterChip(
                        selected = flowMapMode,
                        onClick = { flowMapMode = true },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                        },
                        label = { Text("Flow") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                            selectedLabelColor = CyanWave,
                            selectedLeadingIconColor = CyanWave,
                        ),
                        modifier = Modifier.testTag("lyric_flow_mode_chip"),
                    )
                }
            }

            // Live Metrics Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                LyricMetricPill(label = "BARS / $targetBars", value = "${stats.barCount}", modifier = Modifier.weight(1f))
                LyricMetricPill(label = "WORDS", value = "${stats.wordCount}", modifier = Modifier.weight(1f))
                LyricMetricPill(label = "AVG SYL", value = "${stats.avgSyllablesPerBar}", modifier = Modifier.weight(1f))
                LyricMetricPill(label = "RHYMES", value = "${stats.rhymeGroupsCount}", modifier = Modifier.weight(1f))
            }

            // Track Length Target & Progress
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(3, 5, 10).forEach { mins ->
                    FilterChip(
                        selected = trackMinutes == mins,
                        onClick = { onSelectTrackMinutes(mins) },
                        label = { Text("${mins}m") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                            selectedLabelColor = CyanWave,
                        ),
                        modifier = Modifier.testTag("lyric_duration_${mins}m_chip"),
                    )
                }
                LinearProgressIndicator(
                    progress = { (stats.barCount.toFloat() / targetBars.toFloat()).coerceIn(0f, 1f) },
                    color = EmeraldMeter,
                    trackColor = StudioModule,
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                )
            }

            // Language, Flow Preview, Rhyme Finder, Master Template & All 14 Song Structure Tags
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AssistChip(
                    onClick = { showLanguagePicker = true },
                    label = { Text(uiState.selectedLanguage.englishName.substringBefore(" ")) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Language,
                            contentDescription = null,
                            tint = EmeraldMeter,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = EmeraldMeter.copy(alpha = 0.14f),
                        labelColor = EmeraldMeter,
                    ),
                )

                AssistChip(
                    onClick = onToggleFlowVoicePreview,
                    label = { Text(if (uiState.isFlowVoiceSpeaking) "Stop Voice" else "Hear Flow") },
                    leadingIcon = {
                        Icon(
                            imageVector = if (uiState.isFlowVoiceSpeaking) Icons.Rounded.Stop else Icons.Rounded.RecordVoiceOver,
                            contentDescription = null,
                            tint = AmberVu,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = AmberVu.copy(alpha = 0.14f),
                        labelColor = AmberVu,
                    ),
                )

                AssistChip(
                    onClick = {
                        val lastWord = stats.lines.lastOrNull { it.endWord.isNotEmpty() }?.endWord.orEmpty()
                        if (lastWord.isNotEmpty()) {
                            onRhymeQueryChange(lastWord)
                        }
                        showRhymeSheet = true
                    },
                    label = { Text("Rhyme Finder") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = CyanWave,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = CyanWave.copy(alpha = 0.14f),
                        labelColor = CyanWave,
                    ),
                    border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.4f)),
                    modifier = Modifier.testTag("open_rhyme_finder_button"),
                )

                AssistChip(
                    onClick = {
                        flowMapMode = false
                        onPasteLyrics()
                    },
                    label = { Text("Paste") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.ContentPaste,
                            contentDescription = null,
                            tint = EmeraldMeter,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = EmeraldMeter.copy(alpha = 0.14f),
                        labelColor = EmeraldMeter,
                    ),
                    modifier = Modifier.testTag("paste_own_lyrics_chip"),
                )

                AssistChip(
                    onClick = {
                        flowMapMode = false
                        onImportLyricsTxt()
                    },
                    label = { Text("Import .TXT") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.UploadFile,
                            contentDescription = null,
                            tint = CyanWave,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = CyanWave.copy(alpha = 0.14f),
                        labelColor = CyanWave,
                    ),
                    modifier = Modifier.testTag("import_txt_lyrics_chip"),
                )

                AssistChip(
                    onClick = onOpenBoothTab,
                    label = { Text("Record in Booth") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = null,
                            tint = AmberVu,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = AmberVu.copy(alpha = 0.14f),
                        labelColor = AmberVu,
                    ),
                    modifier = Modifier.testTag("send_to_booth_chip"),
                )

                AssistChip(
                    onClick = {
                        flowMapMode = false
                        onInsertMasterTemplate()
                    },
                    label = { Text("Master Template") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Description,
                            contentDescription = null,
                            tint = AmberVu,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = AmberVu.copy(alpha = 0.14f),
                        labelColor = AmberVu,
                    ),
                    modifier = Modifier.testTag("insert_master_template_chip"),
                )

                if (uiState.lyricsDraft.isNotBlank()) {
                    AssistChip(
                        onClick = onClearLyrics,
                        label = { Text("Clear") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Clear,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp),
                            )
                        },
                    )
                }

                RapStyleEncyclopedia.songStructureBlocks.forEach { tag ->
                    AssistChip(
                        onClick = {
                            flowMapMode = false
                            onInsertSection(tag)
                        },
                        label = { Text(tag) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = StudioModule,
                            labelColor = TextSecondary,
                        ),
                    )
                }
            }

            // Main Editor OR Flow Analysis Map
            if (!flowMapMode) {
                OutlinedTextField(
                    value = uiState.lyricsDraft,
                    onValueChange = onLyricsChange,
                    placeholder = {
                        Text(
                            text = "Put your own lyrics here — type, tap Paste, or Import .TXT (${uiState.selectedLanguage.englishName} / ${uiState.selectedLanguage.nativeLabel})...\n\nTip: Tap Record in Booth above whenever you're ready to rap over your beat.",
                            color = TextMuted,
                        )
                    },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = StudioRack,
                        unfocusedContainerColor = StudioRack,
                        focusedBorderColor = AmberVu.copy(alpha = 0.7f),
                        unfocusedBorderColor = StudioStroke,
                        cursorColor = AmberVu,
                    ),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .heightIn(min = 220.dp)
                        .testTag("lyrics_editor_field"),
                )
            } else {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                ) {
                    if (stats.lines.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = "Write some bars first, then switch to Flow mode to inspect syllables and rhyme groups.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                            )
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            items(stats.lines, key = { "${it.lineNumber}_${it.text}" }) { line ->
                                FlowAnalysisRow(
                                    line = line,
                                    onTapEndWord = { word ->
                                        onRhymeQueryChange(word)
                                        showRhymeSheet = true
                                    },
                                )
                            }
                        }
                    }
                }
            }

            // Copy / Save .TXT / Share Action Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(
                    onClick = onCopyLyrics,
                    border = BorderStroke(1.dp, StudioStroke),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("copy_lyrics_button"),
                ) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.copy_lyrics))
                }

                Button(
                    onClick = onExportLyricsTxt,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberVu,
                        contentColor = StudioObsidian,
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("export_txt_button"),
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.export_txt), fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onShareLyrics,
                    border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("share_lyrics_button"),
                ) {
                    Icon(
                        Icons.Rounded.Share,
                        contentDescription = null,
                        tint = CyanWave,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.share_lyrics), color = CyanWave)
                }
            }
        }
    }

    if (showRhymeSheet) {
        RhymeHelperSheet(
            query = uiState.rhymeQuery,
            suggestions = uiState.rhymeSuggestions,
            onQueryChange = onRhymeQueryChange,
            onSelectRhyme = { chosen ->
                val current = uiState.lyricsDraft
                val sep = if (current.isEmpty() || current.endsWith(" ") || current.endsWith("\n")) "" else " "
                onLyricsChange("$current$sep$chosen")
                showRhymeSheet = false
            },
            onDismiss = { showRhymeSheet = false },
        )
    }

    if (showLanguagePicker) {
        LanguagePickerSheet(
            selected = uiState.selectedLanguage,
            onSelect = {
                onSelectLanguage(it)
                showLanguagePicker = false
            },
            onDismiss = { showLanguagePicker = false },
        )
    }
}

@Composable
private fun LyricMetricPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = StudioModule,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, StudioStroke.copy(alpha = 0.7f)),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
            )
        }
    }
}

@Composable
private fun FlowAnalysisRow(
    line: AnalyzedLine,
    onTapEndWord: (String) -> Unit,
) {
    if (line.text.isBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        return
    }

    if (line.isSectionHeader) {
        Text(
            text = line.text.trim(),
            style = MaterialTheme.typography.labelLarge,
            color = AmberVu,
            modifier = Modifier.padding(top = 4.dp),
        )
        return
    }

    val rhymeColor = line.rhymeGroupIndex?.let { idx ->
        RhymeColors[idx % RhymeColors.size]
    }

    Surface(
        color = StudioModule,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(
            width = 1.dp,
            color = rhymeColor?.copy(alpha = 0.45f) ?: StudioStroke.copy(alpha = 0.4f),
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = line.endWord.isNotEmpty()) {
                onTapEndWord(line.endWord)
            },
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = line.lineNumber.toString().padStart(2, '0'),
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
            )

            Text(
                text = line.text,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary,
                modifier = Modifier.weight(1f),
            )

            if (rhymeColor != null) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(rhymeColor),
                )
            }

            Surface(
                color = StudioModuleElevated,
                shape = RoundedCornerShape(8.dp),
            ) {
                Text(
                    text = "${line.syllableCount} syl",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldMeter,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
        }
    }
}
