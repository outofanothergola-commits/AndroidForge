package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioObsidian = Color(0xFF0B0E14)
val StudioRack = Color(0xFF141923)
val StudioModule = Color(0xFF1C2331)
val StudioModuleElevated = Color(0xFF252E40)
val StudioStroke = Color(0xFF2F3B52)

val AmberVu = Color(0xFFFF9F1C)
val AmberVuDark = Color(0xFF3A2300)
val AmberVuSoft = Color(0xFFFFBF69)

val CyanWave = Color(0xFF00E5FF)
val CyanWaveDark = Color(0xFF00323B)

val CrimsonRec = Color(0xFFFF3B5C)
val CrimsonRecDark = Color(0xFF470815)

val EmeraldMeter = Color(0xFF2CEAA3)

val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFF9BA7BE)
val TextMuted = Color(0xFF66738C)

val RhymeColors = listOf(
    Color(0xFFFF9F1C),
    Color(0xFF00E5FF),
    Color(0xFF2CEAA3),
    Color(0xFFFF5C8A),
    Color(0xFFA78BFA),
    Color(0xFFFACC15),
)
