package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiGeneratedSong
import com.example.ai.HipHopMasterTemplate
import com.example.ai.StudioAiService
import com.example.audio.AudioDetailReport
import com.example.audio.BeatEngine
import com.example.audio.FlowVoicePreviewer
import com.example.audio.MasteringProfile
import com.example.audio.StudioMixdownEngine
import com.example.audio.StudioPcmFormat
import com.example.audio.TakePlayerManager
import com.example.audio.VocalClarityMode
import com.example.audio.VocalRecorderManager
import com.example.audio.VoiceCloneEngine
import com.example.audio.VoiceCloneRealismMode
import com.example.audio.inspectAudioFileDetails
import com.example.data.ExportOutcome
import com.example.data.RapStudioRepository
import com.example.data.ScriptMode
import com.example.data.StudioLanguage
import com.example.data.local.BeatStyle
import com.example.data.local.RapProject
import com.example.data.local.RapStudioDatabase
import com.example.data.local.VocalPreset
import com.example.data.local.VocalTake
import com.example.data.local.VoiceProfile
import com.example.lyrics.LyricAnalyzer
import com.example.lyrics.LyricStats
import com.example.security.OwnerSecurityManager
import com.example.security.OwnerSecurityState
import com.example.video.GeneratedVideoResult
import com.example.video.LyricalVideoEngine
import com.example.video.LyricalVideoTheme
import com.example.video.VideoAspectRatio
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface StudioUiEvent {
    data class ShowMessage(val message: String) : StudioUiEvent
    data class LaunchDocumentCreator(
        val suggestedName: String,
        val mimeType: String,
    ) : StudioUiEvent

    data class ShareText(val title: String, val text: String) : StudioUiEvent
    data class ShareFile(val filePath: String, val mimeType: String, val title: String) : StudioUiEvent
}

sealed interface AiSongUiState {
    data object Idle : AiSongUiState
    data object Loading : AiSongUiState
    data class Success(val song: AiGeneratedSong) : AiSongUiState
    data class Error(val message: String) : AiSongUiState
}

sealed interface AiAssistUiState {
    data object Idle : AiAssistUiState
    data object Loading : AiAssistUiState
    data class Streaming(val text: String) : AiAssistUiState
    data class Success(val text: String) : AiAssistUiState
    data class Error(val message: String) : AiAssistUiState
}

sealed interface VideoRenderUiState {
    data object Idle : VideoRenderUiState
    data class Rendering(val progress: Float) : VideoRenderUiState
    data class Success(val result: GeneratedVideoResult) : VideoRenderUiState
    data class Error(val message: String) : VideoRenderUiState
}

data class StudioMixerState(
    val drumsGain: Float = 0.90f,
    val bassGain: Float = 0.85f,
    val melodyGain: Float = 0.72f,
    val roomReverbEnabled: Boolean = true,
)

data class StudioUiState(
    val projects: List<RapProject> = emptyList(),
    val takeCounts: Map<Long, Int> = emptyMap(),
    val activeProject: RapProject? = null,
    val activeTakes: List<VocalTake> = emptyList(),
    val voiceProfiles: List<VoiceProfile> = emptyList(),
    val selectedVoiceProfileId: Long? = null,
    val isRecordingVoiceSample: Boolean = false,
    val isProcessingVoiceClone: Boolean = false,
    val videoRenderState: VideoRenderUiState = VideoRenderUiState.Idle,
    val ownerSecurity: OwnerSecurityState = OwnerSecurityState(),
    val lyricsDraft: String = "",
    val lyricStats: LyricStats = LyricStats(0, 0, 0, 0, 0, emptyList()),
    val selectedLanguage: StudioLanguage = StudioLanguage.ENGLISH,
    val selectedScriptMode: ScriptMode = ScriptMode.NATIVE_SCRIPT,
    val isBeatPlaying: Boolean = false,
    val currentStep: Int = -1,
    val arrangementSection: String = "VERSE",
    val isRecording: Boolean = false,
    val recordElapsedMs: Long = 0L,
    val waveformBars: List<Float> = List(48) { 0.08f },
    val playingTakeId: Long? = null,
    val takePlaybackProgress: Float = 0f,
    val isFlowVoiceSpeaking: Boolean = false,
    val isMixingMaster: Boolean = false,
    val selectedPcmFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT,
    val selectedMasteringProfile: MasteringProfile = MasteringProfile.RADIO_SLAM,
    val selectedVocalClarityMode: VocalClarityMode = VocalClarityMode.CRYSTAL_STUDIO,
    val vocalClarityBoost: Float = 0.75f,
    val activeCaptureLabel: String = "48kHz • 32-Bit Float PCM",
    val inspectedAudioDetails: AudioDetailReport? = null,
    val mixer: StudioMixerState = StudioMixerState(),
    val rhymeQuery: String = "",
    val rhymeSuggestions: List<String> = emptyList(),
    val aiSongState: AiSongUiState = AiSongUiState.Idle,
    val aiAssistState: AiAssistUiState = AiAssistUiState.Idle,
)

@OptIn(ExperimentalCoroutinesApi::class)
class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val database = RapStudioDatabase.getInstance(application)
    private val repository = RapStudioRepository(application, database.rapStudioDao())

    private val beatEngine = BeatEngine(application)
    private val recorderManager = VocalRecorderManager(application)
    private val playerManager = TakePlayerManager(application)
    private val mixdownEngine = StudioMixdownEngine(application, beatEngine)
    private val voiceCloneEngine = VoiceCloneEngine(application, mixdownEngine)
    private val lyricalVideoEngine = LyricalVideoEngine(application, beatEngine)
    private val flowVoicePreviewer = FlowVoicePreviewer(application)
    private val aiService = StudioAiService()
    private val securityManager = OwnerSecurityManager(application)

    private val _activeProjectId = MutableStateFlow<Long?>(null)
    private val _lyricsDraft = MutableStateFlow("")
    private val _selectedLanguage = MutableStateFlow(StudioLanguage.ENGLISH)
    private val _selectedScriptMode = MutableStateFlow(ScriptMode.NATIVE_SCRIPT)
    private val _mixerState = MutableStateFlow(StudioMixerState())
    private val _selectedPcmFormat = MutableStateFlow(StudioPcmFormat.PCM_32_FLOAT)
    private val _selectedMasteringProfile = MutableStateFlow(MasteringProfile.RADIO_SLAM)
    private val _selectedVocalClarityMode = MutableStateFlow(VocalClarityMode.CRYSTAL_STUDIO)
    private val _vocalClarityBoost = MutableStateFlow(0.75f)
    private val _inspectedAudioDetails = MutableStateFlow<AudioDetailReport?>(null)
    private val _isMixingMaster = MutableStateFlow(false)
    private val _rhymeQuery = MutableStateFlow("")
    private val _rhymeSuggestions = MutableStateFlow<List<String>>(emptyList())
    private val _aiSongState = MutableStateFlow<AiSongUiState>(AiSongUiState.Idle)
    private val _aiAssistState = MutableStateFlow<AiAssistUiState>(AiAssistUiState.Idle)
    private val _selectedVoiceProfileId = MutableStateFlow<Long?>(null)
    private val _isRecordingVoiceSample = MutableStateFlow(false)
    private val _isProcessingVoiceClone = MutableStateFlow(false)
    private val _videoRenderState = MutableStateFlow<VideoRenderUiState>(VideoRenderUiState.Idle)

    private val _events = MutableSharedFlow<StudioUiEvent>(extraBufferCapacity = 10)
    val events: SharedFlow<StudioUiEvent> = _events.asSharedFlow()

    private var pendingSafBytes: ByteArray? = null
    private var pendingSafSourceFile: File? = null
    private var isRecordToggleBusy = false
    private var lyricsSaveJob: Job? = null

    private val activeProjectFlow = _activeProjectId
        .filterNotNull()
        .flatMapLatest { id -> repository.observeProject(id) }

    private val activeTakesFlow = _activeProjectId
        .filterNotNull()
        .flatMapLatest { id -> repository.observeTakesForProject(id) }

    private val projectBundleFlow = combine(
        repository.allProjects,
        repository.takeCounts,
        activeProjectFlow,
        activeTakesFlow,
    ) { projects, counts, active, takes ->
        ProjectBundle(
            projects = projects,
            takeCounts = counts.associate { it.projectId to it.takeCount },
            activeProject = active,
            activeTakes = takes,
        )
    }

    private val audioBundleFlow = combine(
        beatEngine.isPlaying,
        beatEngine.currentStep,
        recorderManager.isRecording,
        recorderManager.elapsedMs,
        recorderManager.waveformBars,
    ) { beatPlaying, step, recording, elapsed, bars ->
        AudioBundle(beatPlaying, step, recording, elapsed, bars)
    }

    private val playbackBundleFlow = combine(
        playerManager.playingTakeId,
        playerManager.progress,
        flowVoicePreviewer.isSpeaking,
        _isMixingMaster,
        _mixerState,
    ) { playingId, progress, speaking, mixing, mixer ->
        PlaybackControlBundle(playingId, progress, speaking, mixing, mixer)
    }

    private val lyricStatsFlow = _lyricsDraft
        .map { LyricAnalyzer.analyze(it) }
        .flowOn(Dispatchers.Default)

    private val lyricsLangBundleFlow = combine(
        _lyricsDraft,
        lyricStatsFlow,
        _selectedLanguage,
        _selectedScriptMode,
        _rhymeQuery,
        _rhymeSuggestions,
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val draft = values[0] as String
        val stats = values[1] as LyricStats
        val lang = values[2] as StudioLanguage
        val scriptMode = values[3] as ScriptMode
        val query = values[4] as String
        @Suppress("UNCHECKED_CAST")
        val suggestions = values[5] as List<String>
        LyricsLanguageBundle(draft, stats, lang, scriptMode, query, suggestions)
    }

    private val aiBundleFlow = combine(
        _aiSongState,
        _aiAssistState,
        _selectedPcmFormat,
        _selectedMasteringProfile,
        recorderManager.activeCaptureLabel,
        _selectedVocalClarityMode,
        _vocalClarityBoost,
    ) { values ->
        AiAndFormatBundle(
            songState = values[0] as AiSongUiState,
            assistState = values[1] as AiAssistUiState,
            pcmFormat = values[2] as StudioPcmFormat,
            masteringProfile = values[3] as MasteringProfile,
            captureLabel = values[4] as String,
            clarityMode = values[5] as VocalClarityMode,
            clarityBoost = values[6] as Float,
        )
    }

    private val voiceVideoSecurityBundleFlow = combine(
        repository.allVoiceProfiles,
        _selectedVoiceProfileId,
        _isRecordingVoiceSample,
        _isProcessingVoiceClone,
        _videoRenderState,
        securityManager.state,
        beatEngine.arrangementSection,
        _inspectedAudioDetails,
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val profiles = values[0] as List<VoiceProfile>
        val selectedId = values[1] as Long?
        val recordingSample = values[2] as Boolean
        val processingClone = values[3] as Boolean
        val videoState = values[4] as VideoRenderUiState
        val ownerSec = values[5] as OwnerSecurityState
        val arrSection = values[6] as String
        val audioDetails = values[7] as AudioDetailReport?
        VoiceVideoSecurityBundle(profiles, selectedId, recordingSample, processingClone, videoState, ownerSec, arrSection, audioDetails)
    }

    private val baseUiFlow = combine(
        projectBundleFlow,
        audioBundleFlow,
        playbackBundleFlow,
        lyricsLangBundleFlow,
        aiBundleFlow,
    ) { projectBundle, audioBundle, playbackBundle, lyricsLang, aiBundle ->
        BaseUiBundle(projectBundle, audioBundle, playbackBundle, lyricsLang, aiBundle)
    }

    val uiState: StateFlow<StudioUiState> = combine(
        baseUiFlow,
        voiceVideoSecurityBundleFlow,
    ) { base, vvs ->
        val projectBundle = base.projectBundle
        val audioBundle = base.audioBundle
        val playbackBundle = base.playbackBundle
        val lyricsLang = base.lyricsLang
        val aiBundle = base.aiBundle
        val resolvedProfileId = vvs.selectedVoiceProfileId
            ?.takeIf { id -> vvs.voiceProfiles.any { it.id == id } }
            ?: vvs.voiceProfiles.firstOrNull()?.id

        StudioUiState(
            projects = projectBundle.projects,
            takeCounts = projectBundle.takeCounts,
            activeProject = projectBundle.activeProject,
            activeTakes = projectBundle.activeTakes,
            voiceProfiles = vvs.voiceProfiles,
            selectedVoiceProfileId = resolvedProfileId,
            isRecordingVoiceSample = vvs.isRecordingVoiceSample,
            isProcessingVoiceClone = vvs.isProcessingVoiceClone,
            videoRenderState = vvs.videoRenderState,
            ownerSecurity = vvs.ownerSecurity,
            lyricsDraft = lyricsLang.lyricsDraft,
            lyricStats = lyricsLang.lyricStats,
            selectedLanguage = lyricsLang.language,
            selectedScriptMode = lyricsLang.scriptMode,
            isBeatPlaying = audioBundle.isBeatPlaying,
            currentStep = audioBundle.currentStep,
            arrangementSection = vvs.arrangementSection,
            isRecording = audioBundle.isRecording,
            recordElapsedMs = audioBundle.recordElapsedMs,
            waveformBars = audioBundle.waveformBars,
            playingTakeId = playbackBundle.playingTakeId,
            takePlaybackProgress = playbackBundle.progress,
            isFlowVoiceSpeaking = playbackBundle.isSpeaking,
            isMixingMaster = playbackBundle.isMixingMaster,
            selectedPcmFormat = aiBundle.pcmFormat,
            selectedMasteringProfile = aiBundle.masteringProfile,
            selectedVocalClarityMode = aiBundle.clarityMode,
            vocalClarityBoost = aiBundle.clarityBoost,
            activeCaptureLabel = aiBundle.captureLabel,
            inspectedAudioDetails = vvs.inspectedAudioDetails,
            mixer = playbackBundle.mixer,
            rhymeQuery = lyricsLang.rhymeQuery,
            rhymeSuggestions = lyricsLang.rhymeSuggestions,
            aiSongState = aiBundle.songState,
            aiAssistState = aiBundle.assistState,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = StudioUiState(),
    )

    init {
        viewModelScope.launch {
            repository.ensureInitialVoiceProfiles()
            val initialId = repository.ensureInitialProject()
            selectProject(initialId)
        }
    }

    fun selectProject(projectId: Long) {
        viewModelScope.launch {
            flushLyricsSync()
            beatEngine.stop()
            playerManager.stop()
            flowVoicePreviewer.stop()
            _activeProjectId.value = projectId
            val loaded = database.rapStudioDao().getProjectById(projectId)
            _lyricsDraft.value = loaded?.lyrics.orEmpty()
            if (loaded != null) {
                _selectedLanguage.value = StudioLanguage.fromCode(loaded.languageCode)
                playerManager.setPreset(VocalPreset.fromName(loaded.vocalPreset))
            }
        }
    }

    fun createProject(title: String, bpm: Int, style: BeatStyle) {
        viewModelScope.launch {
            flushLyricsSync()
            val newId = repository.createProject(
                title = title,
                bpm = bpm,
                beatStyle = style,
                languageCode = _selectedLanguage.value.code,
            )
            selectProject(newId)
            _events.tryEmit(StudioUiEvent.ShowMessage("Created track \"$title\""))
        }
    }

    fun renameActiveProject(newTitle: String) {
        val current = uiState.value.activeProject ?: return
        val trimmed = newTitle.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            repository.updateProject(current.copy(title = trimmed))
            _events.tryEmit(StudioUiEvent.ShowMessage("Renamed to \"$trimmed\""))
        }
    }

    fun renameProject(project: RapProject, newTitle: String) {
        val trimmed = newTitle.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            repository.updateProject(project.copy(title = trimmed))
        }
    }

    fun duplicateProject(project: RapProject) {
        viewModelScope.launch {
            val newId = repository.duplicateProject(project)
            selectProject(newId)
            _events.tryEmit(StudioUiEvent.ShowMessage("Duplicated \"${project.title}\""))
        }
    }

    fun deleteProject(project: RapProject) {
        viewModelScope.launch {
            val remaining = uiState.value.projects.filter { it.id != project.id }
            repository.deleteProject(project.id)
            if (uiState.value.activeProject?.id == project.id) {
                val nextId = remaining.firstOrNull()?.id ?: repository.ensureInitialProject()
                selectProject(nextId)
            }
            _events.tryEmit(StudioUiEvent.ShowMessage("Deleted \"${project.title}\""))
        }
    }

    fun setLanguage(language: StudioLanguage) {
        _selectedLanguage.value = language
        val current = uiState.value.activeProject ?: return
        viewModelScope.launch {
            repository.updateProject(current.copy(languageCode = language.code))
        }
    }

    fun setScriptMode(mode: ScriptMode) {
        _selectedScriptMode.value = mode
    }

    fun updateTrackMinutes(minutes: Int) {
        val current = uiState.value.activeProject ?: return
        val valid = if (minutes in listOf(3, 5, 10)) minutes else 3
        viewModelScope.launch {
            repository.updateProject(current.copy(trackMinutes = valid))
            _events.tryEmit(StudioUiEvent.ShowMessage("Track length set to $valid Minutes"))
        }
    }

    fun updateVocalStyle(style: String) {
        val current = uiState.value.activeProject ?: return
        viewModelScope.launch {
            repository.updateProject(current.copy(vocalStyle = style))
        }
    }

    fun updateBpm(bpm: Int) {
        val current = uiState.value.activeProject ?: return
        val clamped = bpm.coerceIn(60, 180)
        val style = BeatStyle.fromName(current.beatStyle)
        beatEngine.updateSettings(clamped, style, current.customBeatUri)
        viewModelScope.launch {
            repository.updateProject(current.copy(bpm = clamped))
        }
    }

    fun selectBeatStyle(style: BeatStyle) {
        val current = uiState.value.activeProject ?: return
        if (style == BeatStyle.CUSTOM && current.customBeatUri.isNullOrBlank()) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Import an audio file first to use Custom mode."))
            return
        }
        val nextBpm = if (style != BeatStyle.CUSTOM && style != BeatStyle.METRONOME) {
            style.defaultBpm
        } else {
            current.bpm
        }
        beatEngine.updateSettings(nextBpm, style, current.customBeatUri)
        viewModelScope.launch {
            repository.updateProject(current.copy(beatStyle = style.name, bpm = nextBpm))
        }
    }

    fun selectVocalPreset(preset: VocalPreset) {
        playerManager.setPreset(preset)
        val current = uiState.value.activeProject ?: return
        viewModelScope.launch {
            repository.updateProject(current.copy(vocalPreset = preset.name))
        }
    }

    fun selectPcmFormat(format: StudioPcmFormat) {
        _selectedPcmFormat.value = format
        _events.tryEmit(StudioUiEvent.ShowMessage("Studio Audio Engine: ${format.displayName}"))
    }

    fun selectMasteringProfile(profile: MasteringProfile) {
        _selectedMasteringProfile.value = profile
        _events.tryEmit(StudioUiEvent.ShowMessage("Mastering Chain: ${profile.displayName}"))
    }

    fun selectVocalClarityMode(mode: VocalClarityMode) {
        _selectedVocalClarityMode.value = mode
        _events.tryEmit(StudioUiEvent.ShowMessage("Vocal Clarity: ${mode.displayName}"))
    }

    fun updateVocalClarityBoost(boost: Float) {
        _vocalClarityBoost.value = boost.coerceIn(0f, 1f)
    }

    fun inspectTakeAudioDetails(take: VocalTake) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val report = inspectAudioFileDetails(
                context = getApplication(),
                title = take.title,
                filePath = take.filePath,
                durationMs = take.durationMs,
            )
            _inspectedAudioDetails.value = report
        }
    }

    fun dismissAudioDetails() {
        _inspectedAudioDetails.value = null
    }

    fun updateMixer(
        drumsGain: Float = _mixerState.value.drumsGain,
        bassGain: Float = _mixerState.value.bassGain,
        melodyGain: Float = _mixerState.value.melodyGain,
        roomReverbEnabled: Boolean = _mixerState.value.roomReverbEnabled,
    ) {
        val updated = StudioMixerState(drumsGain, bassGain, melodyGain, roomReverbEnabled)
        _mixerState.value = updated
        beatEngine.updateMix(drumsGain, bassGain, melodyGain, roomReverbEnabled)
    }

    fun attachCustomBeatUri(uri: Uri) {
        val current = uiState.value.activeProject ?: return
        runCatching {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        }
        val name = repository.resolveDisplayName(uri) ?: "Custom Beat"
        val updated = current.copy(
            beatStyle = BeatStyle.CUSTOM.name,
            customBeatUri = uri.toString(),
            customBeatName = name,
        )
        beatEngine.updateSettings(updated.bpm, BeatStyle.CUSTOM, updated.customBeatUri)
        viewModelScope.launch {
            repository.updateProject(updated)
            _events.tryEmit(StudioUiEvent.ShowMessage("Loaded beat: $name"))
        }
    }

    fun toggleBeatPlayback() {
        val current = uiState.value.activeProject ?: return
        val style = BeatStyle.fromName(current.beatStyle)
        val ok = beatEngine.toggle(current.bpm, style, current.customBeatUri)
        if (!beatEngine.isPlaying.value && ok) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Could not play selected beat."))
        } else if (style == BeatStyle.CUSTOM && current.customBeatUri == null) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Import an audio beat file first."))
        }
    }

    fun toggleRecording(withBeat: Boolean = true) {
        val current = uiState.value.activeProject ?: return
        if (isRecordToggleBusy) return
        val pcmFormat = _selectedPcmFormat.value
        isRecordToggleBusy = true
        if (recorderManager.isRecording.value) {
            viewModelScope.launch {
                try {
                    val result = recorderManager.stopRecording()
                    if (result != null) {
                        repository.addTake(current.id, result.filePath, result.durationMs, prefix = "Take")
                        _events.tryEmit(StudioUiEvent.ShowMessage("Saved ${pcmFormat.shortBadge} studio take"))
                    } else {
                        _events.tryEmit(StudioUiEvent.ShowMessage("Recording was too short or failed."))
                    }
                } finally {
                    isRecordToggleBusy = false
                }
            }
        } else {
            playerManager.stop()
            flowVoicePreviewer.stop()
            viewModelScope.launch {
                try {
                    val started = withContext(Dispatchers.IO) {
                        recorderManager.startRecording(pcmFormat)
                    }
                    if (started) {
                        if (withBeat && !beatEngine.isPlaying.value) {
                            val style = BeatStyle.fromName(current.beatStyle)
                            if (style != BeatStyle.CUSTOM || !current.customBeatUri.isNullOrBlank()) {
                                beatEngine.start(current.bpm, style, current.customBeatUri)
                            }
                        }
                    } else {
                        _events.tryEmit(StudioUiEvent.ShowMessage("Could not start microphone recorder."))
                    }
                } finally {
                    isRecordToggleBusy = false
                }
            }
        }
    }

    fun toggleTakePlayback(take: VocalTake) {
        val preset = VocalPreset.fromName(uiState.value.activeProject?.vocalPreset ?: VocalPreset.WARM_BOOTH.name)
        playerManager.togglePlay(take, preset)
    }

    fun mixTakeWithBeat(take: VocalTake) {
        val current = uiState.value.activeProject ?: return
        if (_isMixingMaster.value) return
        val style = BeatStyle.fromName(current.beatStyle)
        val preset = VocalPreset.fromName(current.vocalPreset)
        val pcmFormat = _selectedPcmFormat.value
        if (style == BeatStyle.CUSTOM || style == BeatStyle.METRONOME) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Select a studio beat style (Trap, Boom Bap, Desi Trap, etc.) to render a full mixdown."))
            return
        }

        viewModelScope.launch {
            _isMixingMaster.value = true
            mixdownEngine.mixTakeWithBeat(
                take = take,
                beatStyle = style,
                bpm = current.bpm,
                vocalPreset = preset,
                pcmFormat = pcmFormat,
                masteringProfile = _selectedMasteringProfile.value,
                clarityMode = _selectedVocalClarityMode.value,
                clarityBoost = _vocalClarityBoost.value,
            ).onSuccess { master ->
                repository.addTake(current.id, master.filePath, master.durationMs, prefix = "Master")
                _events.tryEmit(StudioUiEvent.ShowMessage("${pcmFormat.shortBadge} Master (${_selectedVocalClarityMode.value.displayName}) created!"))
            }.onFailure { err ->
                _events.tryEmit(StudioUiEvent.ShowMessage(err.localizedMessage ?: "Mixdown failed."))
            }
            _isMixingMaster.value = false
        }
    }

    fun bounceInstrumentalForDuration() {
        val current = uiState.value.activeProject ?: return
        if (_isMixingMaster.value) return
        val style = BeatStyle.fromName(current.beatStyle)
        val pcmFormat = _selectedPcmFormat.value
        if (style == BeatStyle.CUSTOM || style == BeatStyle.METRONOME) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Select a studio beat style (Trap, Drill, Boom Bap, etc.) to render an instrumental."))
            return
        }
        viewModelScope.launch {
            _isMixingMaster.value = true
            mixdownEngine.renderInstrumentalMasterWav(
                beatStyle = style,
                bpm = current.bpm,
                minutes = current.trackMinutes,
                pcmFormat = pcmFormat,
                masteringProfile = _selectedMasteringProfile.value,
            ).onSuccess { rendered ->
                repository.addTake(
                    current.id,
                    rendered.filePath,
                    rendered.durationMs,
                    prefix = "${current.trackMinutes}m Beat",
                )
                _events.tryEmit(StudioUiEvent.ShowMessage("Rendered ${current.trackMinutes}m ${pcmFormat.shortBadge} instrumental!"))
            }.onFailure { err ->
                _events.tryEmit(StudioUiEvent.ShowMessage(err.localizedMessage ?: "Instrumental render failed."))
            }
            _isMixingMaster.value = false
        }
    }

    fun deleteTake(take: VocalTake) {
        if (playerManager.playingTakeId.value == take.id) {
            playerManager.stop()
        }
        viewModelScope.launch {
            repository.deleteTake(take)
            _events.tryEmit(StudioUiEvent.ShowMessage("Deleted ${take.title}"))
        }
    }

    private fun blockIfStrictPrivateVault(): Boolean {
        if (securityManager.state.value.strictPrivateVault) {
            _events.tryEmit(
                StudioUiEvent.ShowMessage(
                    "Owner Private Mode ON: External exports & 3rd-party shares are locked. Toggle off in Security Vault if you want to export.",
                ),
            )
            return true
        }
        return false
    }

    fun exportTakeAudio(take: VocalTake) {
        if (blockIfStrictPrivateVault()) return
        val title = uiState.value.activeProject?.title ?: "PSYCH"
        viewModelScope.launch {
            when (val outcome = repository.exportAudioTake(take, title)) {
                is ExportOutcome.SavedToDevice ->
                    _events.tryEmit(StudioUiEvent.ShowMessage("Saved to ${outcome.locationLabel}"))
                is ExportOutcome.NeedsDocumentPicker -> {
                    pendingSafBytes = outcome.contentBytes
                    pendingSafSourceFile = outcome.sourceFile
                    _events.tryEmit(
                        StudioUiEvent.LaunchDocumentCreator(
                            suggestedName = outcome.suggestedName,
                            mimeType = outcome.mimeType,
                        ),
                    )
                }
                is ExportOutcome.Failure ->
                    _events.tryEmit(StudioUiEvent.ShowMessage(outcome.reason))
            }
        }
    }

    fun toggleFlowVoicePreview() {
        val lyrics = _lyricsDraft.value
        if (lyrics.isBlank()) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Write or generate lyrics first to preview vocal flow."))
            return
        }
        val bpm = uiState.value.activeProject?.bpm ?: 92
        flowVoicePreviewer.toggleSpeak(lyrics, _selectedLanguage.value, bpm)
    }

    // --- Firebase AI Logic Hip-Hop Master Template Composer ---

    fun generateAiSong(
        songTitleInput: String,
        promptOrSeedLyrics: String,
        genre: String,
        mood: String,
        vocalStyle: String,
        flowTechnique: String,
        lyricTechnique: String,
        productionStyle: String,
        requestedBpm: Int?,
        trackMinutes: Int,
    ) {
        val effectivePrompt = promptOrSeedLyrics.ifBlank {
            "Original $mood $genre track titled ${songTitleInput.ifBlank { "Studio Anthem" }}"
        }
        viewModelScope.launch {
            _aiSongState.value = AiSongUiState.Loading
            try {
                val song = aiService.generateCompleteSong(
                    songTitleInput = songTitleInput,
                    promptOrSeedLyrics = effectivePrompt,
                    language = _selectedLanguage.value,
                    scriptMode = _selectedScriptMode.value,
                    genre = genre,
                    mood = mood,
                    vocalStyle = vocalStyle,
                    flowTechnique = flowTechnique,
                    lyricTechnique = lyricTechnique,
                    productionStyle = productionStyle,
                    requestedBpm = requestedBpm,
                    trackMinutes = trackMinutes,
                )
                _aiSongState.value = AiSongUiState.Success(song)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiSongState.value = AiSongUiState.Error(e.localizedMessage ?: "AI song generation failed.")
            }
        }
    }

    fun loadGeneratedSongIntoStudio(song: AiGeneratedSong, startBeat: Boolean = true) {
        viewModelScope.launch {
            flushLyricsSync()
            val newId = repository.createProject(
                title = song.title,
                bpm = song.recommendedBpm,
                beatStyle = song.recommendedBeatStyle,
                lyrics = song.lyrics,
                languageCode = song.language.code,
                chordProgression = song.chordProgression,
                vocalStyle = song.vocalStyle,
                trackMinutes = song.trackMinutes,
            )
            selectProject(newId)
            if (startBeat) {
                beatEngine.start(song.recommendedBpm, song.recommendedBeatStyle, null)
            }
            _events.tryEmit(
                StudioUiEvent.ShowMessage("Loaded \"${song.title}\" (${song.trackMinutes} Min) into Booth!"),
            )
        }
    }

    fun produceCompleteSongWithClonedVoice(song: AiGeneratedSong) {
        if (_isProcessingVoiceClone.value) return
        val currentState = uiState.value
        val profile = currentState.voiceProfiles.firstOrNull { it.id == currentState.selectedVoiceProfileId }
            ?: currentState.voiceProfiles.firstOrNull()
        if (profile == null) {
            _events.tryEmit(StudioUiEvent.ShowMessage("No voice profile ready yet — open Clone tab first."))
            return
        }
        val pcmFormat = _selectedPcmFormat.value
        val clarityMode = _selectedVocalClarityMode.value
        val clarityBoost = _vocalClarityBoost.value
        val masteringProfile = _selectedMasteringProfile.value

        viewModelScope.launch {
            _isProcessingVoiceClone.value = true
            flushLyricsSync()
            val newId = repository.createProject(
                title = song.title,
                bpm = song.recommendedBpm,
                beatStyle = song.recommendedBeatStyle,
                lyrics = song.lyrics,
                languageCode = song.language.code,
                chordProgression = song.chordProgression,
                vocalStyle = song.vocalStyle,
                trackMinutes = song.trackMinutes,
            )
            _activeProjectId.value = newId
            _lyricsDraft.value = song.lyrics
            _selectedLanguage.value = song.language

            voiceCloneEngine.generateClonedVoiceFromLyrics(
                lyrics = song.lyrics,
                language = song.language,
                profile = profile,
                bpm = song.recommendedBpm,
                beatStyle = song.recommendedBeatStyle,
                vocalPreset = VocalPreset.CRISPY_TRAP,
                mixWithBeat = true,
                pitchOffsetSemitones = 0f,
                formantOffset = 1.0f,
                gritBoost = 0.05f,
                realismMode = VoiceCloneRealismMode.STUDIO_NATURAL,
                clarityMode = clarityMode,
                clarityBoost = clarityBoost,
                stereoDoubleLayer = true,
                pcmFormat = pcmFormat,
                masteringProfile = masteringProfile,
            ).onSuccess { rendered ->
                val takeId = repository.addTake(newId, rendered.filePath, rendered.durationMs, prefix = "AI Master")
                _events.tryEmit(
                    StudioUiEvent.ShowMessage("Full ${pcmFormat.shortBadge} track produced with ${profile.name}! Playing now..."),
                )
                val savedTake = database.rapStudioDao().getTakesForProjectSync(newId).firstOrNull { it.id == takeId }
                if (savedTake != null) {
                    playerManager.togglePlay(savedTake, VocalPreset.CRISPY_TRAP)
                }
            }.onFailure { err ->
                _events.tryEmit(StudioUiEvent.ShowMessage(err.localizedMessage ?: "Failed to produce full cloned track."))
            }
            _isProcessingVoiceClone.value = false
        }
    }

    fun loadCustomLyricsIntoStudio(
        title: String,
        ownLyrics: String,
        genre: String,
        requestedBpm: Int?,
        vocalStyle: String,
        trackMinutes: Int,
        startBeat: Boolean = true,
    ): Boolean {
        val cleanedLyrics = ownLyrics.trim()
        if (cleanedLyrics.isEmpty()) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Write or paste your own lyrics first."))
            return false
        }
        val beatStyle = inferBeatStyle(genre)
        val bpm = (requestedBpm ?: beatStyle.defaultBpm).coerceIn(60, 180)
        val resolvedTitle = title.trim().ifBlank { "My Track ${(10..99).random()}" }

        viewModelScope.launch {
            flushLyricsSync()
            val newId = repository.createProject(
                title = resolvedTitle,
                bpm = bpm,
                beatStyle = beatStyle,
                lyrics = cleanedLyrics,
                languageCode = _selectedLanguage.value.code,
                chordProgression = genre.ifBlank { beatStyle.tag },
                vocalStyle = vocalStyle,
                trackMinutes = trackMinutes,
            )
            selectProject(newId)
            if (startBeat) {
                beatEngine.start(bpm, beatStyle, null)
            }
            _events.tryEmit(
                StudioUiEvent.ShowMessage("Loaded your own lyrics \"$resolvedTitle\" into Studio!"),
            )
        }
        return true
    }

    private fun inferBeatStyle(genre: String): BeatStyle {
        val g = genre.lowercase()
        return when {
            "orchestral" in g || "cinematic" in g || "classical" in g -> BeatStyle.ORCHESTRAL_CINEMATIC
            "phonk" in g || "memphis" in g -> BeatStyle.PHONK_MEMPHIS
            "drill" in g -> BeatStyle.DRILL
            "boom bap" in g || "old school" in g || "golden age" in g || "underground" in g || "jazz" in g -> BeatStyle.BOOM_BAP
            "desi" in g || "hindi" in g || "punjabi" in g || "bhangra" in g -> BeatStyle.DESI_TRAP
            "bihu" in g || "assam" in g || "bodo" in g || "adivasi" in g || "folk" in g -> BeatStyle.BIHU_FOLK_FUSION
            "lo-fi" in g || "lofi" in g || "melodic" in g || "emo" in g || "sad" in g || "soul" in g -> BeatStyle.LO_FI_SOUL
            "afro" in g || "bounce" in g || "dancehall" in g -> BeatStyle.AFRO_BOUNCE
            else -> BeatStyle.TRAP_808
        }
    }

    fun loadMasterTemplateScaffold(
        title: String,
        genre: String,
        mood: String,
        bpm: Int,
        vocalStyle: String,
        trackMinutes: Int,
    ) {
        val scaffold = HipHopMasterTemplate.buildScaffold(
            title = title,
            genre = genre,
            mood = mood,
            bpm = bpm,
            vocalStyle = vocalStyle,
            trackMinutes = trackMinutes,
        )
        val current = _lyricsDraft.value
        val next = if (current.isBlank()) scaffold else "$current\n\n$scaffold"
        updateLyrics(next)
        viewModelScope.launch {
            uiState.value.activeProject?.let { proj ->
                repository.updateProject(
                    proj.copy(
                        title = title.ifBlank { proj.title },
                        bpm = bpm.coerceIn(60, 180),
                        vocalStyle = vocalStyle,
                        trackMinutes = trackMinutes,
                    ),
                )
            }
            _events.tryEmit(StudioUiEvent.ShowMessage("Loaded $trackMinutes-Min Hip-Hop Master Template into Lyric Pad"))
        }
    }

    fun runAiCoWriter(
        instruction: String,
        replaceWholeLyrics: Boolean = false,
    ) {
        val bpm = uiState.value.activeProject?.bpm ?: 92
        val currentLyrics = _lyricsDraft.value
        viewModelScope.launch {
            _aiAssistState.value = AiAssistUiState.Loading
            val acc = StringBuilder()
            try {
                aiService.streamLyricAssist(
                    modePrompt = instruction,
                    existingLyrics = currentLyrics,
                    language = _selectedLanguage.value,
                    scriptMode = _selectedScriptMode.value,
                    bpm = bpm,
                ).collect { chunk ->
                    acc.append(chunk)
                    _aiAssistState.value = AiAssistUiState.Streaming(acc.toString())
                }
                val result = acc.toString().trim()
                if (result.isNotEmpty()) {
                    _aiAssistState.value = AiAssistUiState.Success(result)
                    if (replaceWholeLyrics) {
                        updateLyrics(result)
                        _events.tryEmit(StudioUiEvent.ShowMessage("Updated lyrics in ${_selectedLanguage.value.englishName}"))
                    }
                } else {
                    _aiAssistState.value = AiAssistUiState.Error("AI returned an empty response.")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiAssistState.value = AiAssistUiState.Error(e.localizedMessage ?: "AI co-writer failed.")
            }
        }
    }

    fun appendAiAssistToLyrics() {
        val text = when (val st = _aiAssistState.value) {
            is AiAssistUiState.Success -> st.text
            is AiAssistUiState.Streaming -> st.text
            else -> return
        }
        val current = _lyricsDraft.value
        val sep = if (current.isBlank()) "" else "\n\n"
        updateLyrics("$current$sep$text")
        _events.tryEmit(StudioUiEvent.ShowMessage("Added AI bars to Lyric Pad"))
    }

    fun replaceLyricsWithAiAssist() {
        val text = when (val st = _aiAssistState.value) {
            is AiAssistUiState.Success -> st.text
            else -> return
        }
        updateLyrics(text)
        _events.tryEmit(StudioUiEvent.ShowMessage("Replaced Lyric Pad with AI lyrics"))
    }

    fun updateLyrics(newLyrics: String) {
        _lyricsDraft.value = newLyrics
        val activeId = _activeProjectId.value ?: return
        lyricsSaveJob?.cancel()
        lyricsSaveJob = viewModelScope.launch {
            delay(350L)
            val current = database.rapStudioDao().getProjectById(activeId) ?: return@launch
            if (current.lyrics != newLyrics) {
                repository.updateProject(current.copy(lyrics = newLyrics))
            }
        }
    }

    fun pasteLyricsToPad() {
        val clip = repository.readTextFromClipboard()
        if (clip.isNullOrBlank()) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Clipboard is empty — copy your lyrics first."))
            return
        }
        val current = _lyricsDraft.value
        val next = if (current.isBlank()) clip else "$current\n\n$clip"
        updateLyrics(next)
        _events.tryEmit(StudioUiEvent.ShowMessage("Pasted your lyrics into Lyric Pad"))
    }

    fun importLyricsFromUri(uri: Uri) {
        viewModelScope.launch {
            repository.readLyricsTextFromUri(uri)
                .onSuccess { text ->
                    if (text.isBlank()) {
                        _events.tryEmit(StudioUiEvent.ShowMessage("Selected text file is empty."))
                    } else {
                        updateLyrics(text)
                        _events.tryEmit(StudioUiEvent.ShowMessage("Imported your lyrics into Lyric Pad"))
                    }
                }
                .onFailure { err ->
                    _events.tryEmit(StudioUiEvent.ShowMessage(err.localizedMessage ?: "Could not import lyrics file."))
                }
        }
    }

    fun clearLyricsPad() {
        updateLyrics("")
        _events.tryEmit(StudioUiEvent.ShowMessage("Cleared Lyric Pad"))
    }

    fun insertSectionTag(tag: String) {
        val current = _lyricsDraft.value
        val prefix = when {
            current.isEmpty() -> ""
            current.endsWith("\n\n") -> ""
            current.endsWith("\n") -> "\n"
            else -> "\n\n"
        }
        updateLyrics("$current$prefix$tag\n")
    }

    fun copyLyricsToClipboard() {
        val text = _lyricsDraft.value
        if (text.isBlank()) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Write or generate some bars before copying."))
            return
        }
        repository.copyTextToClipboard(text)
        _events.tryEmit(StudioUiEvent.ShowMessage("Lyrics copied to clipboard"))
    }

    fun exportLyricsTxt() {
        if (blockIfStrictPrivateVault()) return
        val project = uiState.value.activeProject ?: return
        val text = _lyricsDraft.value
        if (text.isBlank()) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Nothing to export — write some lyrics first."))
            return
        }
        viewModelScope.launch {
            val content = "${project.title} (${project.bpm} BPM • ${project.trackMinutes} Min • ${project.vocalStyle} • ${_selectedLanguage.value.englishName})\nCreated in PSYCH☯⚡ • Created by psycho\n\n$text"
            when (val outcome = repository.exportDocumentText("${project.title}_lyrics.txt", "text/plain", content)) {
                is ExportOutcome.SavedToDevice ->
                    _events.tryEmit(StudioUiEvent.ShowMessage("Exported to ${outcome.locationLabel}"))
                is ExportOutcome.NeedsDocumentPicker -> {
                    pendingSafBytes = outcome.contentBytes
                    pendingSafSourceFile = outcome.sourceFile
                    _events.tryEmit(
                        StudioUiEvent.LaunchDocumentCreator(
                            suggestedName = outcome.suggestedName,
                            mimeType = outcome.mimeType,
                        ),
                    )
                }
                is ExportOutcome.Failure ->
                    _events.tryEmit(StudioUiEvent.ShowMessage(outcome.reason))
            }
        }
    }

    fun shareLyrics() {
        if (blockIfStrictPrivateVault()) return
        val project = uiState.value.activeProject ?: return
        val text = _lyricsDraft.value
        if (text.isBlank()) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Write some lyrics before sharing."))
            return
        }
        _events.tryEmit(StudioUiEvent.ShareText(project.title, text))
    }

    fun exportProjectJson(project: RapProject) {
        if (blockIfStrictPrivateVault()) return
        viewModelScope.launch {
            val latest = if (project.id == uiState.value.activeProject?.id) {
                project.copy(lyrics = _lyricsDraft.value)
            } else {
                project
            }
            val json = repository.serializeProjectToJson(latest)
            when (val outcome = repository.exportDocumentText("${latest.title}.json", "application/json", json)) {
                is ExportOutcome.SavedToDevice ->
                    _events.tryEmit(StudioUiEvent.ShowMessage("Exported to ${outcome.locationLabel}"))
                is ExportOutcome.NeedsDocumentPicker -> {
                    pendingSafBytes = outcome.contentBytes
                    pendingSafSourceFile = outcome.sourceFile
                    _events.tryEmit(
                        StudioUiEvent.LaunchDocumentCreator(
                            suggestedName = outcome.suggestedName,
                            mimeType = outcome.mimeType,
                        ),
                    )
                }
                is ExportOutcome.Failure ->
                    _events.tryEmit(StudioUiEvent.ShowMessage(outcome.reason))
            }
        }
    }

    fun importProjectJson(uri: Uri) {
        viewModelScope.launch {
            repository.importProjectFromUri(uri)
                .onSuccess { newId ->
                    selectProject(newId)
                    _events.tryEmit(StudioUiEvent.ShowMessage("Imported project into Vault"))
                }
                .onFailure {
                    _events.tryEmit(StudioUiEvent.ShowMessage("Invalid PSYCH☯⚡ JSON project file"))
                }
        }
    }

    fun completePendingSafExport(uri: Uri) {
        val sourceFile = pendingSafSourceFile
        val bytes = pendingSafBytes
        pendingSafSourceFile = null
        pendingSafBytes = null
        if (sourceFile == null && bytes == null) return
        viewModelScope.launch {
            val result = if (sourceFile != null) {
                repository.writeFileToUri(uri, sourceFile)
            } else {
                repository.writeBytesToUri(uri, bytes!!)
            }
            result
                .onSuccess { _events.tryEmit(StudioUiEvent.ShowMessage("File saved")) }
                .onFailure { _events.tryEmit(StudioUiEvent.ShowMessage("Failed to write file")) }
        }
    }

    fun updateRhymeQuery(word: String) {
        _rhymeQuery.value = word
        _rhymeSuggestions.value = LyricAnalyzer.findRhymesFor(word)
    }

    // --- Realistic Voice Clone Generator ---

    fun selectVoiceProfile(profileId: Long) {
        _selectedVoiceProfileId.value = profileId
    }

    fun toggleRecordVoiceSample(profileName: String) {
        if (_isProcessingVoiceClone.value || isRecordToggleBusy) return
        val pcmFormat = _selectedPcmFormat.value
        isRecordToggleBusy = true
        if (_isRecordingVoiceSample.value) {
            _isRecordingVoiceSample.value = false
            viewModelScope.launch {
                try {
                    val result = recorderManager.stopRecording()
                    if (result == null) {
                        _events.tryEmit(StudioUiEvent.ShowMessage("Voice sample too short — hold at least 2 seconds."))
                        return@launch
                    }
                    val resolvedName = profileName.trim().ifBlank { "My Voice Clone ${(10..99).random()}" }
                    analyzeAndSaveVoiceProfile(result.filePath, resolvedName)
                } finally {
                    isRecordToggleBusy = false
                }
            }
        } else {
            playerManager.stop()
            beatEngine.stop()
            flowVoicePreviewer.stop()
            viewModelScope.launch {
                try {
                    val started = withContext(Dispatchers.IO) {
                        recorderManager.startRecording(pcmFormat)
                    }
                    if (started) {
                        _isRecordingVoiceSample.value = true
                    } else {
                        _events.tryEmit(StudioUiEvent.ShowMessage("Grant microphone permission to capture your voice sample."))
                    }
                } finally {
                    isRecordToggleBusy = false
                }
            }
        }
    }

    fun importVoiceSampleUri(uri: Uri, profileName: String) {
        if (_isProcessingVoiceClone.value) return
        viewModelScope.launch {
            _isProcessingVoiceClone.value = true
            repository.copyAudioSampleFromUri(uri)
                .onSuccess { copied ->
                    val fallbackName = repository.resolveDisplayName(uri)?.substringBeforeLast('.') ?: "Imported Voice"
                    val resolvedName = profileName.trim().ifBlank { fallbackName }
                    _isProcessingVoiceClone.value = false
                    analyzeAndSaveVoiceProfile(copied.absolutePath, resolvedName)
                }
                .onFailure { err ->
                    _isProcessingVoiceClone.value = false
                    _events.tryEmit(StudioUiEvent.ShowMessage(err.localizedMessage ?: "Failed to import voice sample."))
                }
        }
    }

    fun cloneProfileFromTake(take: VocalTake, profileName: String) {
        val resolved = profileName.trim().ifBlank { "${take.title} Voice" }
        analyzeAndSaveVoiceProfile(take.filePath, resolved)
    }

    private fun analyzeAndSaveVoiceProfile(samplePath: String, name: String) {
        viewModelScope.launch {
            _isProcessingVoiceClone.value = true
            voiceCloneEngine.analyzeVoiceSample(samplePath)
                .onSuccess { dna ->
                    val lang = _selectedLanguage.value
                    val aiNotes = aiService.analyzeVoiceClonePersona(
                        timbreSummary = dna.timbreSummary,
                        pitchHz = dna.pitchHz,
                        spectralCentroidHz = dna.spectralCentroidHz,
                        gritAmount = dna.gritAmount,
                        language = lang,
                    )
                    val newId = repository.insertVoiceProfile(
                        VoiceProfile(
                            name = name,
                            sampleFilePath = samplePath,
                            pitchHz = dna.pitchHz,
                            spectralCentroidHz = dna.spectralCentroidHz,
                            warmthDb = dna.warmthDb,
                            presenceDb = dna.presenceDb,
                            airDb = dna.airDb,
                            gritAmount = dna.gritAmount,
                            formantShift = dna.formantShift,
                            breathiness = dna.breathiness,
                            timbreSummary = dna.timbreSummary,
                            aiPersonaNotes = aiNotes,
                            languageCode = lang.code,
                            spectralEnvelopeCsv = dna.spectralEnvelopeCsv,
                            pitchVarianceHz = dna.pitchVarianceHz,
                            isPreset = false,
                        ),
                    )
                    _selectedVoiceProfileId.value = newId
                    _events.tryEmit(StudioUiEvent.ShowMessage("Cloned voice profile \"$name\" (${dna.pitchHz.toInt()} Hz)!"))
                }
                .onFailure { err ->
                    _events.tryEmit(StudioUiEvent.ShowMessage(err.localizedMessage ?: "Voiceprint extraction failed."))
                }
            _isProcessingVoiceClone.value = false
        }
    }

    fun deleteVoiceProfile(profile: VoiceProfile) {
        if (profile.isPreset) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Built-in studio archetypes cannot be deleted."))
            return
        }
        viewModelScope.launch {
            repository.deleteVoiceProfile(profile)
            _events.tryEmit(StudioUiEvent.ShowMessage("Deleted voice profile \"${profile.name}\""))
        }
    }

    fun generateClonedVoiceTrack(
        customLyrics: String?,
        pitchOffsetSemitones: Float,
        formantOffset: Float,
        gritBoost: Float,
        mixWithBeat: Boolean,
        realismMode: VoiceCloneRealismMode = VoiceCloneRealismMode.CRYSTAL_RAP_HD,
        clarityBoost: Float = _vocalClarityBoost.value,
        stereoDoubleLayer: Boolean = true,
    ) {
        val current = uiState.value.activeProject ?: return
        val profileId = uiState.value.selectedVoiceProfileId
        val profile = uiState.value.voiceProfiles.firstOrNull { it.id == profileId }
        if (profile == null) {
            _events.tryEmit(StudioUiEvent.ShowMessage("Select or create a Voice Clone Profile first."))
            return
        }
        if (_isProcessingVoiceClone.value) return

        val effectiveLyrics = customLyrics?.takeIf { it.isNotBlank() } ?: _lyricsDraft.value
        val beatStyle = BeatStyle.fromName(current.beatStyle)
        val preset = VocalPreset.fromName(current.vocalPreset)
        val pcmFormat = _selectedPcmFormat.value
        val clarityMode = _selectedVocalClarityMode.value

        viewModelScope.launch {
            _isProcessingVoiceClone.value = true
            voiceCloneEngine.generateClonedVoiceFromLyrics(
                lyrics = effectiveLyrics,
                language = _selectedLanguage.value,
                profile = profile,
                bpm = current.bpm,
                beatStyle = beatStyle,
                vocalPreset = preset,
                mixWithBeat = mixWithBeat,
                pitchOffsetSemitones = pitchOffsetSemitones,
                formantOffset = formantOffset,
                gritBoost = gritBoost,
                realismMode = realismMode,
                clarityMode = clarityMode,
                clarityBoost = clarityBoost,
                stereoDoubleLayer = stereoDoubleLayer,
                pcmFormat = pcmFormat,
                masteringProfile = _selectedMasteringProfile.value,
            ).onSuccess { result ->
                val tag = if (mixWithBeat) "CloneMix" else "CloneVox"
                repository.addTake(current.id, result.filePath, result.durationMs, prefix = tag)
                _events.tryEmit(StudioUiEvent.ShowMessage("${pcmFormat.shortBadge} cloned voice (${realismMode.displayName}) ready!"))
            }.onFailure { err ->
                _events.tryEmit(StudioUiEvent.ShowMessage(err.localizedMessage ?: "Voice clone synthesis failed."))
            }
            _isProcessingVoiceClone.value = false
        }
    }

    fun morphTakeIntoClonedVoice(
        take: VocalTake,
        pitchOffsetSemitones: Float,
        formantOffset: Float,
        gritBoost: Float,
        mixWithBeat: Boolean,
        realismMode: VoiceCloneRealismMode = VoiceCloneRealismMode.CRYSTAL_RAP_HD,
        clarityBoost: Float = _vocalClarityBoost.value,
        stereoDoubleLayer: Boolean = true,
    ) {
        val current = uiState.value.activeProject ?: return
        val profileId = uiState.value.selectedVoiceProfileId
        val profile = uiState.value.voiceProfiles.firstOrNull { it.id == profileId } ?: return
        if (_isProcessingVoiceClone.value) return

        val beatStyle = BeatStyle.fromName(current.beatStyle)
        val preset = VocalPreset.fromName(current.vocalPreset)
        val pcmFormat = _selectedPcmFormat.value
        val clarityMode = _selectedVocalClarityMode.value

        viewModelScope.launch {
            _isProcessingVoiceClone.value = true
            voiceCloneEngine.morphTakeWithVoiceProfile(
                sourceFilePath = take.filePath,
                profile = profile,
                bpm = current.bpm,
                beatStyle = beatStyle,
                vocalPreset = preset,
                mixWithBeat = mixWithBeat,
                pitchOffsetSemitones = pitchOffsetSemitones,
                formantOffset = formantOffset,
                gritBoost = gritBoost,
                realismMode = realismMode,
                clarityMode = clarityMode,
                clarityBoost = clarityBoost,
                stereoDoubleLayer = stereoDoubleLayer,
                pcmFormat = pcmFormat,
                masteringProfile = _selectedMasteringProfile.value,
            ).onSuccess { result ->
                val tag = if (mixWithBeat) "MorphMix" else "MorphVox"
                repository.addTake(current.id, result.filePath, result.durationMs, prefix = tag)
                _events.tryEmit(StudioUiEvent.ShowMessage("Morphed ${take.title} (${realismMode.displayName})!"))
            }.onFailure { err ->
                _events.tryEmit(StudioUiEvent.ShowMessage(err.localizedMessage ?: "Voice morph failed."))
            }
            _isProcessingVoiceClone.value = false
        }
    }

    // --- H.264 + AAC MP4 Lyrical Video Generator ---

    fun renderLyricalVideo(
        selectedTake: VocalTake?,
        theme: LyricalVideoTheme,
        aspectRatio: VideoAspectRatio,
        artistName: String,
        coverImageUri: Uri?,
        fallbackDurationSec: Int,
    ) {
        val project = uiState.value.activeProject ?: return
        if (_videoRenderState.value is VideoRenderUiState.Rendering) return

        val beatStyle = BeatStyle.fromName(project.beatStyle)
        val lang = _selectedLanguage.value
        val metaLine = "${project.bpm} BPM • ${lang.englishName}"

        viewModelScope.launch {
            _videoRenderState.value = VideoRenderUiState.Rendering(0.02f)
            lyricalVideoEngine.renderLyricalVideoMp4(
                songTitle = project.title,
                artistName = artistName.trim().ifBlank { "psycho" },
                metaLine = metaLine,
                lyrics = _lyricsDraft.value,
                sourceAudioPath = selectedTake?.filePath,
                beatStyle = beatStyle,
                bpm = project.bpm,
                fallbackDurationSec = fallbackDurationSec,
                theme = theme,
                aspectRatio = aspectRatio,
                coverImageUri = coverImageUri,
                onProgress = { pct ->
                    _videoRenderState.value = VideoRenderUiState.Rendering(pct)
                },
            ).onSuccess { result ->
                _videoRenderState.value = VideoRenderUiState.Success(result)
                _events.tryEmit(StudioUiEvent.ShowMessage("MP4 Lyrical Video Ready (${result.width}x${result.height})!"))
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Failed to render MP4 lyrical video."
                _videoRenderState.value = VideoRenderUiState.Error(msg)
                _events.tryEmit(StudioUiEvent.ShowMessage(msg))
            }
        }
    }

    fun exportGeneratedVideoMp4(result: GeneratedVideoResult) {
        if (blockIfStrictPrivateVault()) return
        val title = uiState.value.activeProject?.title ?: "PSYCH"
        viewModelScope.launch {
            when (val outcome = repository.exportVideoMp4(File(result.filePath), title)) {
                is ExportOutcome.SavedToDevice ->
                    _events.tryEmit(StudioUiEvent.ShowMessage("Saved video to ${outcome.locationLabel}"))
                is ExportOutcome.NeedsDocumentPicker -> {
                    pendingSafBytes = outcome.contentBytes
                    pendingSafSourceFile = outcome.sourceFile
                    _events.tryEmit(
                        StudioUiEvent.LaunchDocumentCreator(
                            suggestedName = outcome.suggestedName,
                            mimeType = outcome.mimeType,
                        ),
                    )
                }
                is ExportOutcome.Failure ->
                    _events.tryEmit(StudioUiEvent.ShowMessage(outcome.reason))
            }
        }
    }

    fun shareGeneratedVideoMp4(result: GeneratedVideoResult) {
        if (blockIfStrictPrivateVault()) return
        val title = uiState.value.activeProject?.title ?: "PSYCH☯⚡"
        _events.tryEmit(StudioUiEvent.ShareFile(result.filePath, "video/mp4", "$title — Lyrical Video"))
    }

    // --- Single-Owner Exclusive Security Controls ---

    fun claimOwnerPasscode(passcode: String, ownerLabel: String): Result<Unit> =
        securityManager.claimOwnerPasscode(passcode, ownerLabel)

    fun unlockWithPasscode(passcode: String): Result<Unit> =
        securityManager.verifyPasscode(passcode)

    fun createDeviceCredentialUnlockIntent(): Intent? =
        securityManager.createDeviceCredentialUnlockIntent()

    fun onDeviceCredentialVerified() = securityManager.onDeviceCredentialVerified()

    fun lockStudioNow() = securityManager.lockNow()

    fun suppressNextAutoLockForSystemPicker() = securityManager.suppressNextAutoLockForSystemPicker()

    fun onAppBackgrounded() = securityManager.onAppBackgrounded()

    fun onAppForegrounded() = securityManager.onAppForegrounded()

    fun setScreenPrivacyShield(enabled: Boolean) = securityManager.setScreenPrivacyShield(enabled)

    fun setStrictPrivateVault(enabled: Boolean) = securityManager.setStrictPrivateVault(enabled)

    fun setBiometricUnlockEnabled(enabled: Boolean) = securityManager.setBiometricUnlockEnabled(enabled)

    fun setAutoLockBackground(enabled: Boolean) = securityManager.setAutoLockBackground(enabled)

    fun updateOwnerLabel(label: String) = securityManager.updateOwnerLabel(label)

    fun updateOwnerPasscode(currentPasscode: String, newPasscode: String): Result<Unit> =
        securityManager.updatePasscode(currentPasscode, newPasscode)

    private suspend fun flushLyricsSync() {
        lyricsSaveJob?.cancel()
        val activeId = _activeProjectId.value ?: return
        val draft = _lyricsDraft.value
        val existing = database.rapStudioDao().getProjectById(activeId) ?: return
        if (existing.lyrics != draft) {
            repository.updateProject(existing.copy(lyrics = draft))
        }
    }

    override fun onCleared() {
        super.onCleared()
        beatEngine.release()
        recorderManager.release()
        playerManager.release()
        flowVoicePreviewer.release()
    }

    private data class ProjectBundle(
        val projects: List<RapProject>,
        val takeCounts: Map<Long, Int>,
        val activeProject: RapProject?,
        val activeTakes: List<VocalTake>,
    )

    private data class AudioBundle(
        val isBeatPlaying: Boolean,
        val currentStep: Int,
        val isRecording: Boolean,
        val recordElapsedMs: Long,
        val waveformBars: List<Float>,
    )

    private data class PlaybackControlBundle(
        val playingTakeId: Long?,
        val progress: Float,
        val isSpeaking: Boolean,
        val isMixingMaster: Boolean,
        val mixer: StudioMixerState,
    )

    private data class LyricsLanguageBundle(
        val lyricsDraft: String,
        val lyricStats: LyricStats,
        val language: StudioLanguage,
        val scriptMode: ScriptMode,
        val rhymeQuery: String,
        val rhymeSuggestions: List<String>,
    )

    private data class VoiceVideoSecurityBundle(
        val voiceProfiles: List<VoiceProfile>,
        val selectedVoiceProfileId: Long?,
        val isRecordingVoiceSample: Boolean,
        val isProcessingVoiceClone: Boolean,
        val videoRenderState: VideoRenderUiState,
        val ownerSecurity: OwnerSecurityState,
        val arrangementSection: String,
        val inspectedAudioDetails: AudioDetailReport?,
    )

    private data class AiAndFormatBundle(
        val songState: AiSongUiState,
        val assistState: AiAssistUiState,
        val pcmFormat: StudioPcmFormat,
        val masteringProfile: MasteringProfile,
        val captureLabel: String,
        val clarityMode: VocalClarityMode,
        val clarityBoost: Float,
    )

    private data class BaseUiBundle(
        val projectBundle: ProjectBundle,
        val audioBundle: AudioBundle,
        val playbackBundle: PlaybackControlBundle,
        val lyricsLang: LyricsLanguageBundle,
        val aiBundle: AiAndFormatBundle,
    )
}
