package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.security.OwnerSecurityState
import com.example.ui.components.StudioBadge
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CrimsonRec
import com.example.ui.theme.CyanWave
import com.example.ui.theme.EmeraldMeter
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioRack
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun OwnerLockScreen(
    securityState: OwnerSecurityState,
    onClaimOwnerPasscode: (passcode: String, ownerLabel: String) -> Result<Unit>,
    onVerifyPasscode: (passcode: String) -> Result<Unit>,
    onTriggerDeviceUnlock: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var ownerName by remember(securityState.ownerLabel) { mutableStateOf(securityState.ownerLabel) }
    var passcode by remember { mutableStateOf("") }
    var confirmPasscode by remember { mutableStateOf("") }
    var showPasscode by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(StudioObsidian, StudioRack, StudioObsidian),
                ),
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            shape = MaterialTheme.shapes.extraLarge,
            border = BorderStroke(1.dp, AmberVu.copy(alpha = 0.45f)),
            colors = CardDefaults.cardColors(containerColor = StudioRack),
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 480.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Surface(
                    color = AmberVu.copy(alpha = 0.16f),
                    shape = CircleShape,
                    border = BorderStroke(1.5.dp, AmberVu.copy(alpha = 0.5f)),
                    modifier = Modifier.size(68.dp),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (securityState.isOwnerClaimed) Icons.Rounded.Lock else Icons.Rounded.Shield,
                            contentDescription = "Owner exclusive lock",
                            tint = AmberVu,
                            modifier = Modifier.size(34.dp),
                        )
                    }
                }

                Text(
                    text = "PSYCH☯⚡",
                    style = MaterialTheme.typography.headlineLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.ExtraBold,
                )

                StudioBadge(
                    label = if (securityState.isOwnerClaimed) "PRIVATE OWNER VAULT LOCKED" else "CLAIM EXCLUSIVE OWNER ACCESS",
                    accentColor = if (securityState.isOwnerClaimed) CrimsonRec else EmeraldMeter,
                )

                Text(
                    text = if (securityState.isOwnerClaimed) {
                        "Locked for ${securityState.ownerLabel}. Zero third-party access, backups disabled, and screen shield active."
                    } else {
                        "This is your private studio. Set your personal Master PIN below so only you can access your beats, lyrics, voice clones, and videos."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                )

                if (!securityState.isOwnerClaimed) {
                    OutlinedTextField(
                        value = ownerName,
                        onValueChange = { ownerName = it },
                        label = { Text("Owner Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = StudioObsidian,
                            unfocusedContainerColor = StudioObsidian,
                            focusedBorderColor = CyanWave,
                            unfocusedBorderColor = StudioStroke,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owner_claim_name_input"),
                    )
                }

                OutlinedTextField(
                    value = passcode,
                    onValueChange = {
                        passcode = it
                        errorMessage = null
                    },
                    label = { Text(if (securityState.isOwnerClaimed) "Enter Owner Master PIN" else "Create Master PIN (4+ chars)") },
                    singleLine = true,
                    visualTransformation = if (showPasscode) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    trailingIcon = {
                        IconButton(onClick = { showPasscode = !showPasscode }) {
                            Icon(
                                imageVector = if (showPasscode) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = if (showPasscode) "Hide PIN" else "Show PIN",
                                tint = TextSecondary,
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = StudioObsidian,
                        unfocusedContainerColor = StudioObsidian,
                        focusedBorderColor = AmberVu,
                        unfocusedBorderColor = StudioStroke,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("owner_passcode_input"),
                )

                if (!securityState.isOwnerClaimed) {
                    OutlinedTextField(
                        value = confirmPasscode,
                        onValueChange = {
                            confirmPasscode = it
                            errorMessage = null
                        },
                        label = { Text("Confirm Master PIN") },
                        singleLine = true,
                        visualTransformation = if (showPasscode) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = StudioObsidian,
                            unfocusedContainerColor = StudioObsidian,
                            focusedBorderColor = EmeraldMeter,
                            unfocusedBorderColor = StudioStroke,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owner_confirm_passcode_input"),
                    )
                }

                if (errorMessage != null) {
                    Surface(
                        color = CrimsonRec.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CrimsonRec.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonRec,
                            modifier = Modifier.padding(10.dp),
                        )
                    }
                }

                Button(
                    onClick = {
                        if (!securityState.isOwnerClaimed) {
                            if (passcode.trim() != confirmPasscode.trim()) {
                                errorMessage = "PINs do not match."
                                return@Button
                            }
                            onClaimOwnerPasscode(passcode, ownerName)
                                .onFailure { errorMessage = it.localizedMessage ?: "Invalid PIN." }
                        } else {
                            onVerifyPasscode(passcode)
                                .onFailure { errorMessage = it.localizedMessage ?: "Wrong PIN." }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberVu,
                        contentColor = StudioObsidian,
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("owner_unlock_button"),
                ) {
                    Icon(Icons.Rounded.LockOpen, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (securityState.isOwnerClaimed) "Unlock PSYCH☯⚡ Studio" else "Lock App Exclusively To Me",
                        fontWeight = FontWeight.Bold,
                    )
                }

                if (securityState.isOwnerClaimed &&
                    securityState.biometricUnlockEnabled &&
                    securityState.isDeviceSecureAvailable
                ) {
                    OutlinedButton(
                        onClick = onTriggerDeviceUnlock,
                        border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.65f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("owner_biometric_unlock_button"),
                    ) {
                        Icon(Icons.Rounded.Fingerprint, contentDescription = null, tint = CyanWave)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Unlock with Fingerprint / Device Lock", color = CyanWave)
                    }
                }

                Text(
                    text = "Offline PBKDF2-SHA256 Hash • Zero Third-Party Access • Owner Encrypted",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwnerSecuritySheet(
    securityState: OwnerSecurityState,
    onDismiss: () -> Unit,
    onLockNow: () -> Unit,
    onSetScreenShield: (Boolean) -> Unit,
    onSetStrictPrivateVault: (Boolean) -> Unit,
    onSetBiometricUnlock: (Boolean) -> Unit,
    onSetAutoLock: (Boolean) -> Unit,
    onUpdateOwnerLabel: (String) -> Unit,
    onChangePasscode: (currentPin: String, newPin: String) -> Result<Unit>,
) {
    var ownerLabel by remember(securityState.ownerLabel) { mutableStateOf(securityState.ownerLabel) }
    var currentPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var pinFeedback by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StudioModule,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Rounded.Shield, contentDescription = null, tint = AmberVu)
                    Text("Owner Exclusive Vault Security", style = MaterialTheme.typography.titleLarge)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close security panel")
                }
            }

            Button(
                onClick = {
                    onDismiss()
                    onLockNow()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = CrimsonRec,
                    contentColor = TextPrimary,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("lock_studio_now_button"),
            ) {
                Icon(Icons.Rounded.Lock, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Lock PSYCH☯⚡ Immediately", fontWeight = FontWeight.Bold)
            }

            SecurityToggleRow(
                title = "Strict Private Mode (No 3rd-Party Access)",
                subtitle = "Blocks external Share sheets and public device exports so files stay inside your private vault.",
                checked = securityState.strictPrivateVault,
                onCheckedChange = onSetStrictPrivateVault,
            )

            SecurityToggleRow(
                title = "Anti-Screenshot & Screen Record Shield",
                subtitle = "Enables Android FLAG_SECURE on your phone (blacks out screenshots & remote previews when ON).",
                checked = securityState.screenPrivacyShield,
                onCheckedChange = onSetScreenShield,
            )

            SecurityToggleRow(
                title = "Fingerprint / Device Screen Lock Unlock",
                subtitle = "Allow device biometrics or screen lock as fast owner verification.",
                checked = securityState.biometricUnlockEnabled,
                onCheckedChange = onSetBiometricUnlock,
            )

            SecurityToggleRow(
                title = "Auto-Lock When Leaving App",
                subtitle = "Automatically locks PSYCH☯⚡ 15s after moving to background.",
                checked = securityState.autoLockBackground,
                onCheckedChange = onSetAutoLock,
            )

            HorizontalDivider(color = StudioStroke)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = ownerLabel,
                    onValueChange = { ownerLabel = it },
                    label = { Text("Owner Identity Label") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Button(
                    onClick = { onUpdateOwnerLabel(ownerLabel) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanWave, contentColor = StudioObsidian),
                ) {
                    Text("Save")
                }
            }

            Text("Change Owner Master PIN", style = MaterialTheme.typography.titleSmall, color = AmberVu)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = currentPin,
                    onValueChange = { currentPin = it },
                    label = { Text("Current PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { newPin = it },
                    label = { Text("New PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.weight(1f),
                )
            }
            if (pinFeedback != null) {
                Text(
                    text = pinFeedback.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = EmeraldMeter,
                )
            }
            OutlinedButton(
                onClick = {
                    onChangePasscode(currentPin, newPin)
                        .onSuccess {
                            currentPin = ""
                            newPin = ""
                            pinFeedback = "Owner Master PIN updated."
                        }
                        .onFailure {
                            pinFeedback = it.localizedMessage ?: "Failed to update PIN."
                        }
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Update Owner PIN")
            }
        }
    }
}

@Composable
private fun SecurityToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Surface(
        color = StudioModuleElevated,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, StudioStroke.copy(alpha = 0.5f)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = StudioObsidian,
                    checkedTrackColor = EmeraldMeter,
                ),
            )
        }
    }
}
