package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Search
import com.example.data.RapStyleEncyclopedia
import com.example.data.StudioLanguage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.BeatStyle
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CrimsonRec
import com.example.ui.theme.CyanWave
import com.example.ui.theme.EmeraldMeter
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun LiveWaveformCanvas(
    amplitudes: List<Float>,
    isRecording: Boolean,
    isBeatPlaying: Boolean,
    modifier: Modifier = Modifier,
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(86.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(StudioObsidian)
            .border(1.dp, StudioStroke.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 12.dp),
    ) {
        val count = amplitudes.size.coerceAtLeast(1)
        val totalWidth = size.width
        val centerY = size.height / 2f
        val stepWidth = totalWidth / count
        val barWidth = (stepWidth * 0.56f).coerceAtLeast(2.dp.toPx())

        // Center baseline rule
        drawLine(
            color = StudioStroke.copy(alpha = 0.4f),
            start = Offset(0f, centerY),
            end = Offset(totalWidth, centerY),
            strokeWidth = 1.dp.toPx(),
        )

        amplitudes.forEachIndexed { index, rawAmp ->
            val amp = rawAmp.coerceIn(0.06f, 1f)
            val barHeight = (size.height * 0.92f) * amp
            val x = index * stepWidth + (stepWidth - barWidth) / 2f
            val top = centerY - barHeight / 2f

            val barColor = when {
                isRecording && amp > 0.75f -> CrimsonRec
                isRecording -> AmberVu
                isBeatPlaying -> CyanWave.copy(alpha = 0.75f)
                else -> TextMuted.copy(alpha = 0.45f)
            }

            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(barColor, barColor.copy(alpha = 0.45f)),
                    startY = top,
                    endY = top + barHeight,
                ),
                topLeft = Offset(x, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
            )
        }
    }
}

@Composable
fun BeatStepLedStrip(
    currentStep: Int,
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (step in 0 until 16) {
            val isDownbeat = step % 4 == 0
            val isActive = isPlaying && step == currentStep
            val targetColor by animateColorAsState(
                targetValue = when {
                    isActive && isDownbeat -> AmberVu
                    isActive -> CyanWave
                    isDownbeat -> StudioModuleElevated
                    else -> StudioModule
                },
                animationSpec = spring(stiffness = Spring.StiffnessHigh),
                label = "stepLed",
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(if (isDownbeat) 10.dp else 7.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(targetColor)
                    .border(
                        width = if (isActive) 1.dp else 0.5.dp,
                        color = if (isActive) Color.White.copy(alpha = 0.5f) else StudioStroke.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(3.dp),
                    ),
            )
        }
    }
}

@Composable
fun StudioBadge(
    label: String,
    accentColor: Color = EmeraldMeter,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = accentColor.copy(alpha = 0.14f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(accentColor),
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (title: String, bpm: Int, style: BeatStyle) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var selectedStyle by remember { mutableStateOf(BeatStyle.TRAP_808) }
    var bpm by remember { mutableFloatStateOf(BeatStyle.TRAP_808.defaultBpm.toFloat()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioModule,
        title = {
            Text(
                text = "New Studio Track",
                style = MaterialTheme.typography.headlineSmall,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Track Title") },
                    placeholder = { Text("Midnight Cipher") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_project_title_input"),
                )

                Text(
                    text = "Beat Style",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondary,
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    BeatStyle.entries.filter { it != BeatStyle.CUSTOM }.forEach { style ->
                        FilterChip(
                            selected = selectedStyle == style,
                            onClick = {
                                selectedStyle = style
                                bpm = style.defaultBpm.toFloat()
                            },
                            label = { Text(style.displayName) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                selectedLabelColor = AmberVu,
                            ),
                        )
                    }
                }

                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = "Tempo",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextSecondary,
                        )
                        Text(
                            text = "${bpm.toInt()} BPM",
                            style = MaterialTheme.typography.labelMedium,
                            color = AmberVu,
                        )
                    }
                    Slider(
                        value = bpm,
                        onValueChange = { bpm = it },
                        valueRange = 60f..180f,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onCreate(
                        title.ifBlank { "Track ${(10..99).random()}" },
                        bpm.toInt(),
                        selectedStyle,
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = AmberVu, contentColor = StudioObsidian),
                modifier = Modifier.testTag("confirm_create_project_button"),
            ) {
                Text("Create", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun RenameProjectDialog(
    initialTitle: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var title by remember(initialTitle) { mutableStateOf(initialTitle) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioModule,
        title = { Text("Rename Track") },
        text = {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Track Title") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rename_project_input"),
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title) },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = AmberVu, contentColor = StudioObsidian),
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RhymeHelperSheet(
    query: String,
    suggestions: List<String>,
    onQueryChange: (String) -> Unit,
    onSelectRhyme: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StudioModule,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = null,
                        tint = CyanWave,
                    )
                    Text(
                        text = "Rhyme & Cadence Finder",
                        style = MaterialTheme.typography.titleLarge,
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close rhyme helper")
                }
            }

            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                label = { Text("End word (e.g. flow, night, grind, mic)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rhyme_query_input"),
            )

            val quickSeeds = listOf("flow", "night", "grind", "fire", "beat", "zone")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                quickSeeds.forEach { seed ->
                    FilterChip(
                        selected = query.equals(seed, ignoreCase = true),
                        onClick = { onQueryChange(seed) },
                        label = { Text(seed) },
                    )
                }
            }

            if (suggestions.isEmpty()) {
                Text(
                    text = if (query.isBlank()) {
                        "Type or tap a seed word above to browse matching end-rhymes."
                    } else {
                        "No built-in bank rhymes for \"$query\". Try another sound like \"flow\", \"night\", or \"beat\"."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )
            } else {
                Text(
                    text = "Tap a word to append it to your bars:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    suggestions.forEach { rhyme ->
                        Surface(
                            color = StudioModuleElevated,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .clickable { onSelectRhyme(rhyme) },
                        ) {
                            Text(
                                text = rhyme,
                                style = MaterialTheme.typography.labelLarge,
                                color = CyanWave,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguagePickerSheet(
    selected: StudioLanguage,
    onSelect: (StudioLanguage) -> Unit,
    onDismiss: () -> Unit,
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            StudioLanguage.entries
        } else {
            StudioLanguage.entries.filter { lang ->
                lang.englishName.contains(searchQuery, ignoreCase = true) ||
                    lang.nativeLabel.contains(searchQuery, ignoreCase = true) ||
                    lang.culturalStyleHint.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StudioModule,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Language,
                        contentDescription = null,
                        tint = CyanWave,
                    )
                    Text(
                        text = "Select Studio Language (${StudioLanguage.entries.size})",
                        style = MaterialTheme.typography.titleLarge,
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close language picker")
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                placeholder = { Text("Search Hindi, Assamese, Bodo/Boro, Aadivasi, Sanskrit...") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("language_search_input"),
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp),
                contentPadding = PaddingValues(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(filtered, key = { it.code }) { lang ->
                    val isSelected = lang == selected
                    Surface(
                        color = if (isSelected) CyanWave.copy(alpha = 0.16f) else StudioModuleElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (isSelected) CyanWave else StudioStroke.copy(alpha = 0.5f),
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(lang) }
                            .testTag("language_option_${lang.code}"),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${lang.englishName}  •  ${lang.nativeLabel}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (isSelected) CyanWave else MaterialTheme.colorScheme.onSurface,
                                )
                                Text(
                                    text = lang.culturalStyleHint,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = CyanWave,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RapMasterDraftPickerSheet(
    initialTab: Int,
    selectedGenre: String,
    selectedFlow: String,
    selectedLyricTechnique: String,
    selectedProduction: String,
    onSelectGenre: (String) -> Unit,
    onSelectFlow: (String) -> Unit,
    onSelectLyricTechnique: (String) -> Unit,
    onSelectProduction: (String) -> Unit,
    onSelectCombination: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var activeTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 4)) }
    var searchQuery by remember { mutableStateOf("") }

    val tabTitles = listOf(
        "Subgenres (${RapStyleEncyclopedia.allSubgenresFlat.size})",
        "Combos (${RapStyleEncyclopedia.ultimateCombinations.size})",
        "Flows (${RapStyleEncyclopedia.flowDeliveryTechniques.size})",
        "Lyric Craft (${RapStyleEncyclopedia.lyricWritingTechniques.size})",
        "Production (${RapStyleEncyclopedia.productionStyles.size})",
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StudioModule,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = AmberVu,
                    )
                    Text(
                        text = "Rap Style Master Draft",
                        style = MaterialTheme.typography.titleLarge,
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close rap master draft picker")
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                placeholder = { Text("Search Drill, Boom Bap, Chopper, Multisyllabic, 808...") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("master_draft_search_input"),
            )

            ScrollableTabRow(
                selectedTabIndex = activeTab,
                containerColor = StudioModule,
                contentColor = AmberVu,
                edgePadding = 0.dp,
                indicator = { tabPositions ->
                    if (activeTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                            color = AmberVu,
                        )
                    }
                },
            ) {
                tabTitles.forEachIndexed { idx, label ->
                    Tab(
                        selected = activeTab == idx,
                        onClick = { activeTab = idx },
                        text = {
                            Text(
                                text = label,
                                color = if (activeTab == idx) AmberVu else TextSecondary,
                            )
                        },
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp),
                contentPadding = PaddingValues(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                when (activeTab) {
                    0 -> {
                        val filteredCats = RapStyleEncyclopedia.subgenreCategories.mapNotNull { cat ->
                            val matches = if (searchQuery.isBlank()) {
                                cat.items
                            } else {
                                cat.items.filter { it.contains(searchQuery, ignoreCase = true) }
                            }
                            if (matches.isEmpty()) null else cat.copy(items = matches)
                        }
                        items(filteredCats, key = { it.id }) { cat ->
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = cat.title,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = CyanWave,
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    cat.items.forEach { styleName ->
                                        FilterChip(
                                            selected = selectedGenre.equals(styleName, ignoreCase = true),
                                            onClick = { onSelectGenre(styleName) },
                                            label = { Text(styleName) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                                selectedLabelColor = AmberVu,
                                            ),
                                        )
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        val combos = RapStyleEncyclopedia.ultimateCombinations.filter {
                            searchQuery.isBlank() || it.contains(searchQuery, ignoreCase = true)
                        }
                        items(combos, key = { it }) { combo ->
                            val isSelected = selectedGenre.equals(combo, ignoreCase = true)
                            Surface(
                                color = if (isSelected) AmberVu.copy(alpha = 0.16f) else StudioModuleElevated,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, if (isSelected) AmberVu else StudioStroke.copy(alpha = 0.5f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectCombination(combo) },
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = combo,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = if (isSelected) AmberVu else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.weight(1f),
                                    )
                                    if (isSelected) {
                                        Icon(Icons.Rounded.CheckCircle, contentDescription = "Selected", tint = AmberVu)
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        val sourceList = when (activeTab) {
                            2 -> RapStyleEncyclopedia.flowDeliveryTechniques
                            3 -> RapStyleEncyclopedia.lyricWritingTechniques
                            else -> RapStyleEncyclopedia.productionStyles
                        }
                        val selectedValue = when (activeTab) {
                            2 -> selectedFlow
                            3 -> selectedLyricTechnique
                            else -> selectedProduction
                        }
                        val filtered = sourceList.filter {
                            searchQuery.isBlank() || it.contains(searchQuery, ignoreCase = true)
                        }
                        item {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                filtered.forEach { itemName ->
                                    FilterChip(
                                        selected = selectedValue.equals(itemName, ignoreCase = true),
                                        onClick = {
                                            when (activeTab) {
                                                2 -> onSelectFlow(itemName)
                                                3 -> onSelectLyricTechnique(itemName)
                                                else -> onSelectProduction(itemName)
                                            }
                                        },
                                        label = { Text(itemName) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                                            selectedLabelColor = CyanWave,
                                        ),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


