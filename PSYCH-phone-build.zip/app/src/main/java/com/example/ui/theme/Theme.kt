package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val StudioDarkColorScheme = darkColorScheme(
    primary = AmberVu,
    onPrimary = StudioObsidian,
    primaryContainer = AmberVuDark,
    onPrimaryContainer = AmberVuSoft,
    secondary = CyanWave,
    onSecondary = StudioObsidian,
    secondaryContainer = CyanWaveDark,
    onSecondaryContainer = CyanWave,
    tertiary = CrimsonRec,
    onTertiary = TextPrimary,
    tertiaryContainer = CrimsonRecDark,
    onTertiaryContainer = CrimsonRec,
    background = StudioObsidian,
    onBackground = TextPrimary,
    surface = StudioRack,
    onSurface = TextPrimary,
    surfaceVariant = StudioModule,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = StudioObsidian,
    surfaceContainerLow = StudioRack,
    surfaceContainer = StudioModule,
    surfaceContainerHigh = StudioModuleElevated,
    outline = StudioStroke,
    outlineVariant = StudioStroke.copy(alpha = 0.5f),
    error = CrimsonRec,
    onError = TextPrimary,
)

private val StudioShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun IRapStudioTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = StudioDarkColorScheme,
        typography = StudioTypography,
        shapes = StudioShapes,
        content = content,
    )
}
