package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.VocalTake
import com.example.ui.components.StudioBadge
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CrimsonRec
import com.example.ui.theme.CyanWave
import com.example.ui.theme.EmeraldMeter
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioRack
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.VideoRenderUiState
import com.example.video.GeneratedVideoResult
import com.example.video.LyricalVideoFrameRenderer
import com.example.video.LyricalVideoTheme
import com.example.video.VideoAspectRatio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoStudioScreen(
    uiState: StudioUiState,
    coverImageUri: Uri?,
    onPickCoverArt: () -> Unit,
    onClearCoverArt: () -> Unit,
    onToggleTakePlay: (VocalTake) -> Unit,
    onToggleBeat: () -> Unit,
    onRenderVideo: (
        selectedTake: VocalTake?,
        theme: LyricalVideoTheme,
        aspectRatio: VideoAspectRatio,
        artistName: String,
        coverImageUri: Uri?,
        fallbackDurationSec: Int,
    ) -> Unit,
    onExportVideoMp4: (GeneratedVideoResult) -> Unit,
    onShareVideoMp4: (GeneratedVideoResult) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val project = uiState.activeProject

    var selectedTheme by remember { mutableStateOf(LyricalVideoTheme.CYBER_GOLD) }
    var selectedAspect by remember { mutableStateOf(VideoAspectRatio.REELS_9_16) }
    var selectedTakeId by remember { mutableStateOf<Long?>(null) }
    var artistCredit by remember(uiState.ownerSecurity.ownerLabel) {
        mutableStateOf("${uiState.ownerSecurity.ownerLabel} • 100% Owner Rights")
    }
    var clipSeconds by remember { mutableIntStateOf(30) }
    var isPreviewPlaying by remember { mutableStateOf(true) }
    var previewClockMs by remember { mutableLongStateOf(0L) }

    val activeTake = remember(uiState.activeTakes, selectedTakeId) {
        if (selectedTakeId == -1L) {
            null
        } else {
            uiState.activeTakes.firstOrNull { it.id == selectedTakeId } ?: uiState.activeTakes.firstOrNull()
        }
    }
    val previewTotalMs = remember(activeTake, clipSeconds) {
        (activeTake?.durationMs ?: (clipSeconds * 1000L)).coerceAtLeast(6000L)
    }

    val coverBitmap by produceState<Bitmap?>(initialValue = null, coverImageUri) {
        value = coverImageUri?.let { uri ->
            withContext(Dispatchers.IO) {
                runCatching {
                    val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it, null, boundsOpts)
                    }
                    val maxDim = max(boundsOpts.outWidth, boundsOpts.outHeight)
                    var sampleSize = 1
                    while (maxDim / sampleSize > 720) {
                        sampleSize *= 2
                    }
                    val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
                    context.contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it, null, decodeOpts)
                    }
                }.getOrNull()
            }
        }
    }

    val timedLines = remember(uiState.lyricsDraft, previewTotalMs) {
        LyricalVideoFrameRenderer.parseTimedLines(uiState.lyricsDraft, previewTotalMs)
    }

    val previewSpectrum = remember { FloatArray(40) { 0.25f } }

    LaunchedEffect(isPreviewPlaying, previewTotalMs, project?.bpm) {
        val bpm = (project?.bpm ?: 120).toFloat()
        fun fillSpectrum(clockMs: Long) {
            val beatPhase = (clockMs / 1000f) * (bpm / 60f) * 3.14159f
            for (i in previewSpectrum.indices) {
                val bassEnv = if (i < 8) abs(sin(beatPhase.toDouble())).toFloat() * 0.72f else 0.12f
                val wave = abs(sin((beatPhase * 1.4f + i * 0.31f).toDouble())).toFloat()
                previewSpectrum[i] = (0.14f + bassEnv * 0.48f + wave * 0.45f).coerceIn(0.08f, 1.0f)
            }
        }
        fillSpectrum(previewClockMs)
        while (isPreviewPlaying) {
            delay(33L)
            val nextClock = (previewClockMs + 33L) % previewTotalMs
            fillSpectrum(nextClock)
            previewClockMs = nextClock
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "LYRICAL VIDEO STUDIO",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberVu,
                        )
                        Text(
                            text = "Kinetic MP4 Video Maker",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary,
                        )
                    }
                    StudioBadge(label = "H.264 + AAC MP4", accentColor = CyanWave)
                }
            }

            // Live WYSIWYG Animated Video Preview Stage
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, AmberVu.copy(alpha = 0.5f)),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        val boxAspect = when (selectedAspect) {
                            VideoAspectRatio.REELS_9_16 -> 0.5625f
                            VideoAspectRatio.SQUARE_1_1 -> 1.0f
                            VideoAspectRatio.YOUTUBE_16_9 -> 1.7777f
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth(if (selectedAspect == VideoAspectRatio.REELS_9_16) 0.72f else 1f)
                                .aspectRatio(boxAspect)
                                .clip(RoundedCornerShape(14.dp))
                                .background(StudioObsidian),
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val w = size.width.toInt().coerceAtLeast(100)
                                val h = size.height.toInt().coerceAtLeast(100)
                                drawIntoCanvas { canvas ->
                                    LyricalVideoFrameRenderer.drawFrame(
                                        canvas = canvas.nativeCanvas,
                                        width = w,
                                        height = h,
                                        theme = selectedTheme,
                                        songTitle = project?.title ?: "PSYCH☯⚡ Session",
                                        artistName = artistCredit,
                                        metaLine = "${project?.bpm ?: 136} BPM • ${uiState.selectedLanguage.englishName}",
                                        timedLines = timedLines,
                                        spectrumBars = previewSpectrum,
                                        coverBitmap = coverBitmap,
                                        currentMs = previewClockMs,
                                        totalMs = previewTotalMs,
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            OutlinedButton(
                                onClick = {
                                    isPreviewPlaying = !isPreviewPlaying
                                    if (activeTake != null) {
                                        onToggleTakePlay(activeTake)
                                    } else {
                                        onToggleBeat()
                                    }
                                },
                                border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.6f)),
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Icon(
                                    imageVector = if (isPreviewPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = CyanWave,
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isPreviewPlaying) "Pause Preview" else "Live Preview", color = CyanWave)
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = EmeraldMeter, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "100% Owner Credit",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldMeter,
                                )
                            }
                        }
                    }
                }
            }

            // Video Style, Aspect Ratio & Cover Art Controls
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Rounded.Palette, contentDescription = null, tint = AmberVu, modifier = Modifier.size(18.dp))
                            Text("Visual Theme", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            LyricalVideoTheme.entries.forEach { theme ->
                                FilterChip(
                                    selected = selectedTheme == theme,
                                    onClick = { selectedTheme = theme },
                                    label = { Text(theme.displayName) },
                                    leadingIcon = {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(CircleShape)
                                                .background(Color(theme.accentPrimary)),
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(theme.accentPrimary).copy(alpha = 0.22f),
                                        selectedLabelColor = Color(theme.accentPrimary),
                                    ),
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Rounded.AspectRatio, contentDescription = null, tint = CyanWave, modifier = Modifier.size(18.dp))
                            Text("Aspect Ratio & Resolution", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            VideoAspectRatio.entries.forEach { ratio ->
                                FilterChip(
                                    selected = selectedAspect == ratio,
                                    onClick = { selectedAspect = ratio },
                                    label = { Text(ratio.label, maxLines = 1) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyanWave.copy(alpha = 0.22f),
                                        selectedLabelColor = CyanWave,
                                    ),
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }

                        OutlinedTextField(
                            value = artistCredit,
                            onValueChange = { artistCredit = it },
                            label = { Text("Artist & Ownership Credit Watermark") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = StudioObsidian,
                                unfocusedContainerColor = StudioObsidian,
                                focusedBorderColor = AmberVu,
                                unfocusedBorderColor = StudioStroke,
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("video_artist_credit_input"),
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedButton(
                                onClick = onPickCoverArt,
                                border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("pick_cover_art_button"),
                            ) {
                                Icon(Icons.Rounded.Image, contentDescription = null, tint = CyanWave)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (coverImageUri == null) "Pick Cover Photo" else "Change Cover Photo", color = CyanWave)
                            }
                            if (coverImageUri != null) {
                                OutlinedButton(
                                    onClick = onClearCoverArt,
                                    border = BorderStroke(1.dp, StudioStroke),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.minimumInteractiveComponentSize(),
                                ) {
                                    Icon(Icons.Rounded.Clear, contentDescription = "Clear cover art", tint = TextSecondary)
                                }
                            }
                        }
                    }
                }
            }

            // Audio Track Source & MP4 Render Action
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(1.dp, StudioStroke),
                    colors = CardDefaults.cardColors(containerColor = StudioRack),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = EmeraldMeter, modifier = Modifier.size(18.dp))
                            Text("Video Soundtrack Source", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            FilterChip(
                                selected = activeTake == null,
                                onClick = { selectedTakeId = -1L },
                                label = { Text("Studio Beat Instrumental") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AmberVu.copy(alpha = 0.22f),
                                    selectedLabelColor = AmberVu,
                                ),
                            )
                            uiState.activeTakes.forEach { take ->
                                FilterChip(
                                    selected = activeTake?.id == take.id,
                                    onClick = { selectedTakeId = take.id },
                                    label = { Text(take.title) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldMeter.copy(alpha = 0.22f),
                                        selectedLabelColor = EmeraldMeter,
                                    ),
                                )
                            }
                        }

                        if (activeTake == null) {
                            Text("Instrumental Clip Length", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                listOf(15, 30, 60).forEach { sec ->
                                    FilterChip(
                                        selected = clipSeconds == sec,
                                        onClick = { clipSeconds = sec },
                                        label = { Text("${sec}s Clip", maxLines = 1) },
                                        modifier = Modifier.weight(1f),
                                    )
                                }
                            }
                        }

                        val renderState = uiState.videoRenderState
                        val isRendering = renderState is VideoRenderUiState.Rendering
                        if (renderState is VideoRenderUiState.Rendering) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text("Encoding H.264 + AAC MP4...", style = MaterialTheme.typography.labelMedium, color = CyanWave)
                                    Text("${(renderState.progress * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = AmberVu)
                                }
                                LinearProgressIndicator(
                                    progress = { renderState.progress },
                                    color = CyanWave,
                                    trackColor = StudioObsidian,
                                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                )
                            }
                        }

                        Button(
                            onClick = {
                                onRenderVideo(
                                    activeTake,
                                    selectedTheme,
                                    selectedAspect,
                                    artistCredit,
                                    coverImageUri,
                                    clipSeconds,
                                )
                            },
                            enabled = !isRendering,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AmberVu,
                                contentColor = StudioObsidian,
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("render_lyrical_video_button"),
                        ) {
                            Icon(Icons.Rounded.MovieCreation, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isRendering) "Rendering MP4 Video..." else "Generate MP4 Lyrical Video",
                                fontWeight = FontWeight.Bold,
                            )
                        }

                        if (renderState is VideoRenderUiState.Success) {
                            val result = renderState.result
                            Surface(
                                color = EmeraldMeter.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, EmeraldMeter.copy(alpha = 0.55f)),
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Text(
                                        text = "MP4 Rendered Ready (${result.width}x${result.height} • ${(result.durationMs / 1000L)}s)",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = EmeraldMeter,
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Button(
                                            onClick = { onExportVideoMp4(result) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = EmeraldMeter,
                                                contentColor = StudioObsidian,
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .minimumInteractiveComponentSize()
                                                .testTag("export_video_mp4_button"),
                                        ) {
                                            Icon(Icons.Rounded.Download, contentDescription = null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Save MP4", fontWeight = FontWeight.Bold)
                                        }
                                        OutlinedButton(
                                            onClick = { onShareVideoMp4(result) },
                                            border = BorderStroke(1.dp, CyanWave.copy(alpha = 0.6f)),
                                            modifier = Modifier
                                                .weight(1f)
                                                .minimumInteractiveComponentSize()
                                                .testTag("share_video_mp4_button"),
                                        ) {
                                            Icon(Icons.Rounded.Share, contentDescription = null, tint = CyanWave)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Share MP4", color = CyanWave)
                                        }
                                    }
                                }
                            }
                        } else if (renderState is VideoRenderUiState.Error) {
                            Surface(
                                color = CrimsonRec.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, CrimsonRec.copy(alpha = 0.5f)),
                            ) {
                                Text(
                                    text = renderState.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CrimsonRec,
                                    modifier = Modifier.padding(10.dp),
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}
