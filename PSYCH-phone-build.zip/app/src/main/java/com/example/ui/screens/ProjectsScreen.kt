package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.FolderSpecial
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.BeatStyle
import com.example.data.local.RapProject
import com.example.ui.components.NewProjectDialog
import com.example.ui.components.RenameProjectDialog
import com.example.ui.components.StudioBadge
import com.example.ui.theme.AmberVu
import com.example.ui.theme.CyanWave
import com.example.ui.theme.StudioModule
import com.example.ui.theme.StudioModuleElevated
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioRack
import com.example.ui.theme.StudioStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StudioUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProjectsScreen(
    uiState: StudioUiState,
    onSelectProject: (RapProject) -> Unit,
    onCreateProject: (title: String, bpm: Int, style: BeatStyle) -> Unit,
    onRenameProject: (RapProject, String) -> Unit,
    onDuplicateProject: (RapProject) -> Unit,
    onDeleteProject: (RapProject) -> Unit,
    onExportProjectJson: (RapProject) -> Unit,
    onImportProjectJson: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var showNewDialog by remember { mutableStateOf(false) }
    var projectToRename by remember { mutableStateOf<RapProject?>(null) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(
                            text = "PROJECT VAULT",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberVu,
                        )
                        Text(
                            text = "Tracks & Sessions",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary,
                        )
                    }
                    StudioBadge(
                        label = stringResource(R.string.creator_footer),
                        accentColor = CyanWave,
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = { showNewDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AmberVu,
                            contentColor = StudioObsidian,
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("new_track_button"),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.new_track), fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onImportProjectJson,
                        border = BorderStroke(1.dp, StudioStroke),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("import_json_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FileOpen,
                            contentDescription = null,
                            tint = CyanWave,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.import_json), color = CyanWave)
                    }
                }
            }

            if (uiState.projects.isEmpty()) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        border = BorderStroke(1.dp, StudioStroke),
                        colors = CardDefaults.cardColors(containerColor = StudioRack),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FolderSpecial,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(36.dp),
                            )
                            Text(
                                text = "Your vault is empty",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextSecondary,
                            )
                            Text(
                                text = "Create a new track or import a PSYCH☯⚡ JSON file.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted,
                            )
                        }
                    }
                }
            } else {
                items(uiState.projects, key = { it.id }) { project ->
                    val isActive = project.id == uiState.activeProject?.id
                    val takeCount = uiState.takeCounts[project.id] ?: 0
                    ProjectVaultCard(
                        project = project,
                        isActive = isActive,
                        takeCount = takeCount,
                        onOpen = { onSelectProject(project) },
                        onRename = { projectToRename = project },
                        onDuplicate = { onDuplicateProject(project) },
                        onExportJson = { onExportProjectJson(project) },
                        onDelete = { onDeleteProject(project) },
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }

    if (showNewDialog) {
        NewProjectDialog(
            onDismiss = { showNewDialog = false },
            onCreate = { title, bpm, style ->
                showNewDialog = false
                onCreateProject(title, bpm, style)
            },
        )
    }

    projectToRename?.let { target ->
        RenameProjectDialog(
            initialTitle = target.title,
            onDismiss = { projectToRename = null },
            onConfirm = { newTitle ->
                projectToRename = null
                onRenameProject(target, newTitle)
            },
        )
    }
}

@Composable
private fun ProjectVaultCard(
    project: RapProject,
    isActive: Boolean,
    takeCount: Int,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onExportJson: () -> Unit,
    onDelete: () -> Unit,
) {
    val style = BeatStyle.fromName(project.beatStyle)
    val barCount = remember(project.lyrics) {
        project.lyrics.lines().count { it.isNotBlank() && !it.trim().startsWith("[") }
    }
    val dateText = remember(project.updatedAt) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(project.updatedAt))
    }

    Card(
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(
            width = if (isActive) 1.5.dp else 1.dp,
            color = if (isActive) AmberVu else StudioStroke,
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) StudioModule else StudioRack,
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen() }
            .testTag("project_card_${project.id}"),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = project.title,
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (isActive) {
                            Surface(
                                color = AmberVu.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp),
                            ) {
                                Text(
                                    text = "ACTIVE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberVu,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                )
                            }
                        }
                    }
                    Text(
                        text = "${style.displayName} • ${project.bpm} BPM • Updated $dateText",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = StudioModuleElevated,
                        shape = RoundedCornerShape(8.dp),
                    ) {
                        Text(
                            text = "$barCount bars",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                    Surface(
                        color = StudioModuleElevated,
                        shape = RoundedCornerShape(8.dp),
                    ) {
                        Text(
                            text = "$takeCount takes",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanWave,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onRename) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = "Rename ${project.title}",
                            tint = TextSecondary,
                        )
                    }
                    IconButton(onClick = onDuplicate) {
                        Icon(
                            imageVector = Icons.Rounded.ContentCopy,
                            contentDescription = "Duplicate ${project.title}",
                            tint = TextSecondary,
                        )
                    }
                    IconButton(
                        onClick = onExportJson,
                        modifier = Modifier.testTag("export_project_json_${project.id}"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Download,
                            contentDescription = "Export ${project.title} JSON",
                            tint = AmberVu,
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_project_${project.id}"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "Delete ${project.title}",
                            tint = TextMuted,
                        )
                    }
                }
            }
        }
    }
}
