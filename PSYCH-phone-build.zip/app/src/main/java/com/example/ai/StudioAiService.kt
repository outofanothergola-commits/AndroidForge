package com.example.ai

import android.util.Log
import com.example.data.ScriptMode
import com.example.data.StudioLanguage
import com.example.data.local.BeatStyle
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "StudioAiService"
private const val MODEL_NAME = "gemini-3.8-flash"

data class AiGeneratedSong(
    val title: String,
    val recommendedBpm: Int,
    val recommendedBeatStyle: BeatStyle,
    val chordProgression: String,
    val vocalDeliveryNotes: String,
    val vocalStyle: String,
    val trackMinutes: Int,
    val lyrics: String,
    val language: StudioLanguage,
)

object HipHopMasterTemplate {
    fun buildScaffold(
        title: String,
        genre: String,
        mood: String,
        bpm: Int,
        vocalStyle: String,
        trackMinutes: Int,
    ): String {
        val extraSections = when {
            trackMinutes >= 10 -> """
                
                [Verse 3 – 16 Bars]
                (Beat switch / second chapter — escalate flow and storytelling)
                
                [Hook / Chorus – 8 Bars]
                (Anthem return)
                
                [Verse 4 – 16 Bars]
                (Cypher marathon bars — double-time switch and pinnacle wordplay)
                
                [Pre-Hook – 4 Bars]
                (Final tension rise)
            """.trimIndent()
            trackMinutes >= 5 -> """
                
                [Verse 3 – 16 Bars]
                (Beat switch / third verse — elevate energy and complex rhymes)
                
                [Hook / Chorus – 8 Bars]
                (Stronger vocal layers)
            """.trimIndent()
            else -> ""
        }

        return """
            |Song Title: ${title.ifBlank { "[Your Title]" }}
            |Genre: $genre | Mood: $mood | BPM: $bpm | Vocal: $vocalStyle | Track: $trackMinutes Min
            |
            |[Intro – 4 Bars]
            |
            |
            |[Hook / Chorus – 8 Bars]
            |
            |
            |[Verse 1 – 16 Bars]
            |
            |
            |[Pre-Hook – 4 Bars]
            |
            |
            |[Hook – 8 Bars]
            |
            |
            |[Verse 2 – 16 Bars]
            |
            |$extraSections
            |[Bridge – 4 to 8 Bars]
            |
            |
            |[Final Hook – 8 Bars]
            |
            |
            |[Outro – 4 Bars]
            |
        """.trimMargin().trim()
    }
}

class StudioAiService {

    private val songSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "Song title"),
            "recommendedBpm" to Schema.integer(description = "Tempo in BPM between 65 and 175"),
            "recommendedBeatStyle" to Schema.enumeration(
                values = listOf(
                    "TRAP_808",
                    "BOOM_BAP",
                    "DESI_TRAP",
                    "BIHU_FOLK_FUSION",
                    "DRILL",
                    "LO_FI_SOUL",
                    "AFRO_BOUNCE",
                ),
                description = "Best matching studio beat preset",
            ),
            "chordProgression" to Schema.string(description = "Musical key and 4-bar chord progression"),
            "vocalDeliveryNotes" to Schema.string(description = "Studio booth vocal delivery & mic tips"),
            "lyrics" to Schema.string(description = "Complete Hip-Hop Song Master Template lyrics following exact bar counts for the requested minute duration"),
        ),
    )

    private val structuredSongModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = songSchema
            },
        )
    }

    private val textModel by lazy {
        Firebase.ai.generativeModel(modelName = MODEL_NAME)
    }

    suspend fun generateCompleteSong(
        songTitleInput: String,
        promptOrSeedLyrics: String,
        language: StudioLanguage,
        scriptMode: ScriptMode,
        genre: String,
        mood: String,
        vocalStyle: String,
        flowTechnique: String,
        lyricTechnique: String,
        productionStyle: String,
        requestedBpm: Int?,
        trackMinutes: Int,
    ): AiGeneratedSong {
        val durationBlueprint = when {
            trackMinutes >= 10 -> """
                Target Duration: 10 MINUTES (Extended Marathon / Epic Cypher Edition).
                Follow EVERY section in order with full line counts:
                [Intro – 4 Bars]
                [Hook / Chorus – 8 Bars]
                [Verse 1 – 16 Bars] (theme intro -> story -> dense wordplay -> punchline ending)
                [Pre-Hook – 4 Bars]
                [Hook – 8 Bars]
                [Verse 2 – 16 Bars] (flow switch -> complex rhymes -> emotional/aggressive peak -> closing bars)
                [Bridge – 8 Bars] (beat switch variation)
                [Verse 3 – 16 Bars] (second chapter & double-time cadence)
                [Hook – 8 Bars]
                [Verse 4 – 16 Bars] (cypher finale & pinnacle punchlines)
                [Final Hook – 8 Bars]
                [Outro – 4 Bars]
            """.trimIndent()
            trackMinutes >= 5 -> """
                Target Duration: 5 MINUTES (Extended Studio Edition).
                Follow EVERY section in order with full line counts:
                [Intro – 4 Bars]
                [Hook / Chorus – 8 Bars]
                [Verse 1 – 16 Bars] (theme intro -> story -> dense wordplay -> punchline ending)
                [Pre-Hook – 4 Bars]
                [Hook – 8 Bars]
                [Verse 2 – 16 Bars] (flow switch -> complex rhymes -> peak -> closing bars)
                [Verse 3 – 16 Bars] (extended story climax & rapid wordplay)
                [Bridge – 6 Bars]
                [Final Hook – 8 Bars]
                [Outro – 4 Bars]
            """.trimIndent()
            else -> """
                Target Duration: 3 MINUTES (Standard Radio / Studio Master Edition).
                Follow EVERY section in order with full line counts:
                [Intro – 4 Bars]
                [Hook / Chorus – 8 Bars]
                [Verse 1 – 16 Bars] (4 bars theme -> 4 bars story -> 4 bars dense rhymes -> 4 bars punchline)
                [Pre-Hook – 4 Bars]
                [Hook – 8 Bars]
                [Verse 2 – 16 Bars] (4 bars flow switch -> 4 bars complex rhymes -> 4 bars peak -> 4 bars closing)
                [Bridge – 4 to 8 Bars]
                [Final Hook – 8 Bars]
                [Outro – 4 Bars]
            """.trimIndent()
        }

        val fullPrompt = """
            You are a chart-topping, masterclass multilingual hip-hop producer and lyricist inside PSYCH☯⚡.
            Generate a studio-ready track following the COMPLETE HIP-HOP & RAP STYLE MASTER TEMPLATE:
            - Song Title Preference: ${songTitleInput.ifBlank { "Create an iconic, memorable title" }}
            - Theme / Seed Lyrics: $promptOrSeedLyrics
            - Target Language: ${language.englishName} (${language.nativeLabel})
            - Cultural Style: ${language.culturalStyleHint}
            - Script Mode: ${scriptMode.label} — ${scriptMode.instruction}
            - Genre / Style Combination: $genre
            - Mood: $mood
            - Vocal Delivery: $vocalStyle
            - Primary Flow Technique: $flowTechnique
            - Lyric-Writing Craft: $lyricTechnique
            - Beat & Production Direction: $productionStyle
            - Preferred BPM: ${requestedBpm?.toString() ?: "Choose ideal BPM for $genre / $mood"}
            - $durationBlueprint

            ARTISTIC STANDARD (MANDATORY):
            1. Masterclass-level lyrical writing with dense, natural multisyllabic rhyming.
            2. Exceptional internal and external rhyme schemes, double entendres, callback punchlines, and imagery.
            3. Multiple flow patterns and intentional switches between verses and pre-hooks.
            4. Original, globally accessible melodic hooks with high replay value.
            5. Write the exact number of performable bars under each section header (no summaries or placeholders).
            6. Honor the authentic rhythm, idioms, and sound of ${language.englishName}.
        """.trimIndent()

        try {
            val response = withTimeout(60_000L) {
                structuredSongModel.generateContent(fullPrompt)
            }
            val rawJson = response.text ?: throw IllegalStateException("AI returned an empty song response.")
            val obj = JSONObject(rawJson)
            val resolvedTitle = songTitleInput.trim().ifBlank { obj.getString("title").trim() }
            val resolvedBpm = requestedBpm ?: obj.getInt("recommendedBpm").coerceIn(60, 180)
            return AiGeneratedSong(
                title = resolvedTitle,
                recommendedBpm = resolvedBpm,
                recommendedBeatStyle = BeatStyle.fromName(obj.getString("recommendedBeatStyle")),
                chordProgression = obj.getString("chordProgression").trim(),
                vocalDeliveryNotes = obj.getString("vocalDeliveryNotes").trim(),
                vocalStyle = vocalStyle,
                trackMinutes = trackMinutes,
                lyrics = obj.getString("lyrics").trim(),
                language = language,
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Song generation timed out", e)
            throw IllegalStateException("AI song generation timed out after 60 seconds. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Song generation failed", e)
            throw IllegalStateException(e.localizedMessage ?: "Failed to generate AI song.")
        }
    }

    fun streamLyricAssist(
        modePrompt: String,
        existingLyrics: String,
        language: StudioLanguage,
        scriptMode: ScriptMode,
        bpm: Int,
    ): Flow<String> = flow {
        val prompt = """
            You are a pro rap & song studio co-writer inside PSYCH☯⚡.
            Task: $modePrompt
            Target Language: ${language.englishName} (${language.nativeLabel})
            Script Requirement: ${scriptMode.instruction}
            Track Tempo: $bpm BPM

            Current Lyrics:
            ${existingLyrics.ifBlank { "(No lyrics yet — start fresh!)" }}

            Output only clean, ready-to-perform lyrics/bars with tight rhymes and rhythmic flow.
        """.trimIndent()

        try {
            withTimeout(60_000L) {
                textModel.generateContentStream(prompt).collect { chunk ->
                    val chunkText = chunk.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        emit(chunkText)
                    }
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Streaming lyric assist timed out", e)
            throw IllegalStateException("AI co-writer timed out after 60 seconds.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Streaming lyric assist failed", e)
            throw IllegalStateException(e.localizedMessage ?: "AI co-writer request failed.")
        }
    }

    suspend fun analyzeVoiceClonePersona(
        timbreSummary: String,
        pitchHz: Float,
        spectralCentroidHz: Float,
        gritAmount: Float,
        language: StudioLanguage,
    ): String {
        val prompt = """
            You are a mastering vocal engineer in PSYCH☯⚡.
            Analyze this cloned voice acoustic DNA:
            - Profile Summary: $timbreSummary
            - Fundamental Pitch F0: ${pitchHz.toInt()} Hz
            - Spectral Centroid: ${spectralCentroidHz.toInt()} Hz
            - Harmonic Grit Index: ${(gritAmount * 100).toInt()}%
            - Primary Language: ${language.englishName} (${language.nativeLabel})

            Give a concise 2-sentence studio vocal chain & delivery recommendation (best beat style, mic/EQ sweet spot, and rap flow fit).
        """.trimIndent()
        return try {
            val response = withTimeout(30_000L) {
                textModel.generateContent(prompt)
            }
            response.text?.trim().orEmpty().ifBlank {
                "Balanced studio vocal signature calibrated at ${pitchHz.toInt()} Hz for ${language.englishName} hooks and verses."
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Voice clone persona analysis failed", e)
            "Acoustic profile calibrated at ${pitchHz.toInt()} Hz ($timbreSummary) for ${language.englishName} studio tracking."
        }
    }
}
