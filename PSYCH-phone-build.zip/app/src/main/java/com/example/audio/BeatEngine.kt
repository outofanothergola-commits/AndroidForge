package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.net.Uri
import com.example.data.local.BeatStyle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

/**
 * Multi-Bus Stereo Studio Beat Production & Composition Engine (48 kHz / 32-Bit Float PCM).
 *
 * Production & Arrangement Architecture:
 * - 16-bar musical song arc: INTRO (Bars 0-1) -> VERSE (Bars 2-7) -> BUILD (Bars 8-9) -> HOOK DROP (Bars 10-15)
 * - Groove Swing & micro-velocity humanization tailored per genre
 * - Layered Studio Drums: 808 sub-punch, acoustic shell kit, snare fills, clap layers, 32nd-note hat rolls, crash/riser
 * - Tuned 808 Bass + Smooth Portamento Pitch Glides (Drill / Trap / Phonk)
 * - Harmonic Composition: Electric Rhodes, Concert Piano voicings, Lush Stereo Analog Pad, FM Bell Leads, Brass Stabs, Karplus-Strong Strings, Cowbell, Tabla/Dholak
 * - Kick-triggered sidechain ducking on Melody/Pad bus, Mid/Side sub-bass mono lock (<120Hz) & upper harmonic stereo width, warm analog bus saturation
 */
class BeatEngine(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentStep = MutableStateFlow(-1)
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

    private val _arrangementSection = MutableStateFlow("VERSE")
    val arrangementSection: StateFlow<String> = _arrangementSection.asStateFlow()

    @Volatile private var currentBpm: Int = 92
    @Volatile private var currentStyle: BeatStyle = BeatStyle.TRAP_808
    @Volatile private var customUri: Uri? = null

    @Volatile var drumsGain: Float = 0.90f
    @Volatile var bassGain: Float = 0.85f
    @Volatile var melodyGain: Float = 0.72f
    @Volatile var roomReverbEnabled: Boolean = true

    private var loopJob: Job? = null
    private var customPlayer: MediaPlayer? = null
    private var stepJob: Job? = null

    val sampleRate = STUDIO_SAMPLE_RATE

    // Pre-built 48kHz Studio Acoustic & Analog Instrument Bank
    private val kick808 by lazy { synthesizeStudioKick(158.0, 40.0, 410, 1.98, subTail = true) }
    private val kickAcoustic by lazy { synthesizeStudioKick(182.0, 52.0, 205, 1.42, subTail = false) }
    private val snareStudio by lazy { synthesizeStudioSnare(bodyHz = 196.0, durationMs = 215) }
    private val snareTight by lazy { synthesizeStudioSnare(bodyHz = 218.0, durationMs = 140) }
    private val snareRim by lazy { synthesizeRimshot() }
    private val clapStudio by lazy { synthesizeStudioClap() }
    private val hatClosed by lazy { synthesizeMetallicHat(durationMs = 46, decay = 86.0) }
    private val hatRollTriplet by lazy { synthesizeHatTripletRoll() }
    private val hatOpen by lazy { synthesizeMetallicHat(durationMs = 210, decay = 17.5) }
    private val crashCymbal by lazy { synthesizeCrashCymbal() }
    private val riserSweep by lazy { synthesizeRiserSweep() }
    private val cowbellMemphis by lazy { synthesizeMemphisCowbell() }
    private val tablaDha by lazy { synthesizeTablaDha() }
    private val tablaNa by lazy { synthesizeTablaNa() }
    private val clickHigh by lazy { synthesizeClick(freqHz = 1220.0, gain = 0.72) }
    private val clickLow by lazy { synthesizeClick(freqHz = 810.0, gain = 0.50) }

    fun updateSettings(bpm: Int, style: BeatStyle, customBeatUri: String?) {
        val prevStyle = currentStyle
        val prevUri = customUri
        currentBpm = bpm.coerceIn(60, 180)
        currentStyle = style
        customUri = customBeatUri?.let { runCatching { Uri.parse(it) }.getOrNull() }

        if (_isPlaying.value && (prevStyle != style || (style == BeatStyle.CUSTOM && prevUri != customUri))) {
            stop()
            start(currentBpm, currentStyle, customBeatUri)
        }
    }

    fun updateMix(drums: Float, bass: Float, melody: Float, reverb: Boolean) {
        drumsGain = drums.coerceIn(0f, 1.2f)
        bassGain = bass.coerceIn(0f, 1.2f)
        melodyGain = melody.coerceIn(0f, 1.2f)
        roomReverbEnabled = reverb
    }

    fun toggle(bpm: Int, style: BeatStyle, customBeatUri: String?): Boolean {
        return if (_isPlaying.value) {
            stop()
            false
        } else {
            start(bpm, style, customBeatUri)
        }
    }

    fun start(bpm: Int, style: BeatStyle, customBeatUri: String?): Boolean {
        stop()
        currentBpm = bpm.coerceIn(60, 180)
        currentStyle = style
        customUri = customBeatUri?.let { runCatching { Uri.parse(it) }.getOrNull() }

        if (style == BeatStyle.CUSTOM) {
            val uri = customUri ?: return false
            return startCustomBeat(uri)
        }

        _isPlaying.value = true
        loopJob = scope.launch {
            val (track, useFloatPcm) = buildStudioAudioTrack()

            try {
                track.play()
                val activeVoices = mutableListOf<StereoVoice>()
                val delayLineL = FloatArray(5200)
                val delayLineR = FloatArray(5200)
                var revLpL = 0f
                var revLpR = 0f
                var delayPos = 0
                var step = 0
                var barInSong = 0
                var kickDuckEnv = 0f
                val subLowPassSide = OnePoleLowPass(120.0, sampleRate)
                val busGlueRelease = exp(-1.0 / (0.095 * sampleRate)).toFloat()

                val maxStepSamples = ((sampleRate * 60.0) / (60.0 * 4.0) * 1.20).toInt().coerceAtLeast(12288)
                val floatBuffer = if (useFloatPcm) FloatArray(maxStepSamples * 2) else null
                val shortBuffer = if (!useFloatPcm) ShortArray(maxStepSamples * 2) else null

                while (isActive && _isPlaying.value) {
                    val baseStepSamples = ((sampleRate * 60.0) / (currentBpm * 4.0)).toInt().coerceAtLeast(1024)
                    val stepSamples = applyGrooveSwingSamples(currentStyle, step, baseStepSamples).coerceAtMost(maxStepSamples)
                    val section = resolveSongSection(barInSong)
                    if (_arrangementSection.value != section.label) {
                        _arrangementSection.value = section.label
                    }

                    val kickTriggered = triggerStepVoices(currentStyle, step, barInSong, section, activeVoices)
                    if (kickTriggered) {
                        kickDuckEnv = 1.0f
                    }
                    _currentStep.value = step

                    val dGain = drumsGain
                    val bGain = bassGain
                    val mGain = melodyGain
                    val useRev = roomReverbEnabled

                    for (i in 0 until stepSamples) {
                        kickDuckEnv *= busGlueRelease
                        val melodySidechain = 1.0f - (kickDuckEnv * 0.24f)

                        var sumL = 0.0
                        var sumR = 0.0
                        var reverbFeedL = 0.0
                        var reverbFeedR = 0.0

                        val iter = activeVoices.listIterator()
                        while (iter.hasNext()) {
                            val v = iter.next()
                            val busGain = when (v.bus) {
                                Bus.DRUMS -> dGain
                                Bus.BASS -> bGain
                                Bus.MELODY -> mGain * melodySidechain
                            }
                            val s = v.samples[v.index] * v.gain * busGain
                            val l = s * v.panL
                            val r = s * v.panR
                            sumL += l
                            sumR += r
                            if (v.bus != Bus.BASS) {
                                reverbFeedL += l * v.reverbSend
                                reverbFeedR += r * v.reverbSend
                            }
                            v.index++
                            if (v.index >= v.samples.size) {
                                iter.remove()
                            }
                        }

                        if (useRev) {
                            val tap1 = (delayPos - 941 + delayLineL.size) % delayLineL.size
                            val tap2 = (delayPos - 1723 + delayLineL.size) % delayLineL.size
                            val tap3 = (delayPos - 2963 + delayLineL.size) % delayLineL.size
                            val rawWetL = delayLineL[tap1] * 0.42f + delayLineR[tap2] * 0.30f + delayLineL[tap3] * 0.18f
                            val rawWetR = delayLineR[tap1] * 0.42f + delayLineL[tap2] * 0.30f + delayLineR[tap3] * 0.18f
                            revLpL += (rawWetL - revLpL) * 0.46f
                            revLpR += (rawWetR - revLpR) * 0.46f
                            delayLineL[delayPos] = (reverbFeedL.toFloat() + revLpR * 0.30f).coerceIn(-1f, 1f)
                            delayLineR[delayPos] = (reverbFeedR.toFloat() + revLpL * 0.30f).coerceIn(-1f, 1f)
                            sumL += revLpL * 0.28
                            sumR += revLpR * 0.28
                            delayPos = (delayPos + 1) % delayLineL.size
                        }

                        // Mid/Side Stereo Mastering: lock sub-bass (<120Hz) mono & widen upper stereo harmonics
                        val mid = (sumL + sumR) * 0.5
                        val rawSide = (sumL - sumR) * 0.5
                        val sideLow = subLowPassSide.process(rawSide.toFloat()).toDouble()
                        val widenedSide = (rawSide - sideLow * 0.88) * 1.18
                        val outL = tanh((mid + widenedSide) * 0.84)
                        val outR = tanh((mid - widenedSide) * 0.84)

                        if (floatBuffer != null) {
                            floatBuffer[i * 2] = outL.toFloat().coerceIn(-0.98f, 0.98f)
                            floatBuffer[i * 2 + 1] = outR.toFloat().coerceIn(-0.98f, 0.98f)
                        } else if (shortBuffer != null) {
                            shortBuffer[i * 2] = (outL * Short.MAX_VALUE).toInt()
                                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                            shortBuffer[i * 2 + 1] = (outR * Short.MAX_VALUE).toInt()
                                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                        }
                    }

                    if (floatBuffer != null) {
                        track.write(floatBuffer, 0, stepSamples * 2, AudioTrack.WRITE_BLOCKING)
                    } else if (shortBuffer != null) {
                        track.write(shortBuffer, 0, stepSamples * 2)
                    }

                    step = (step + 1) % 16
                    if (step == 0) barInSong = (barInSong + 1) % 16
                }
            } catch (_: Throwable) {
                // Safe shutdown on stop/lifecycle
            } finally {
                runCatching {
                    track.pause()
                    track.flush()
                    track.release()
                }
                _currentStep.value = -1
                _arrangementSection.value = "VERSE"
            }
        }
        return true
    }

    private fun buildStudioAudioTrack(): Pair<AudioTrack, Boolean> {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        val floatTrack = runCatching {
            val minFloatBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_FLOAT,
            ).coerceAtLeast(sampleRate)
            val builder = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build(),
                )
                .setBufferSizeInBytes(minFloatBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            }
            val t = builder.build()
            check(t.state == AudioTrack.STATE_INITIALIZED)
            t
        }.getOrNull()

        if (floatTrack != null) return floatTrack to true

        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT,
        ).coerceAtLeast(sampleRate / 2)
        val pcm16Track = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build(),
            )
            .setBufferSizeInBytes(minBuf)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        return pcm16Track to false
    }

    /**
     * Streams offline stereo 48kHz float PCM chunks of the multi-section studio composition
     * to [onChunk] without allocating large multi-minute arrays in memory.
     */
    fun renderInstrumentalChunked(
        style: BeatStyle,
        bpm: Int,
        totalFrames: Long,
        onChunk: (interleavedStereo: FloatArray, frameCount: Int) -> Unit,
    ) {
        val baseStepSamples = ((sampleRate * 60.0) / (bpm.coerceIn(60, 180) * 4.0)).toInt().coerceAtLeast(1024)
        val chunkBuf = FloatArray((baseStepSamples * 1.25).toInt() * 2 + 64)
        if (style == BeatStyle.CUSTOM) {
            var remaining = totalFrames
            while (remaining > 0L) {
                val count = minOf(remaining, baseStepSamples.toLong()).toInt()
                onChunk(chunkBuf, count)
                remaining -= count
            }
            return
        }

        val activeVoices = mutableListOf<StereoVoice>()
        val delayLineL = FloatArray(5200)
        val delayLineR = FloatArray(5200)
        var revLpL = 0f
        var revLpR = 0f
        var delayPos = 0
        var step = 0
        var barInSong = 0
        var frame = 0L
        var kickDuckEnv = 0f
        val subLowPassSide = OnePoleLowPass(120.0, sampleRate)
        val busGlueRelease = exp(-1.0 / (0.095 * sampleRate)).toFloat()

        val dGain = drumsGain
        val bGain = bassGain
        val mGain = melodyGain
        val useRev = roomReverbEnabled

        while (frame < totalFrames) {
            val swungStepSamples = applyGrooveSwingSamples(style, step, baseStepSamples)
            val section = resolveSongSection(barInSong)
            if (triggerStepVoices(style, step, barInSong, section, activeVoices)) {
                kickDuckEnv = 1.0f
            }

            val count = minOf(totalFrames - frame, swungStepSamples.toLong()).toInt()
            for (i in 0 until count) {
                kickDuckEnv *= busGlueRelease
                val melodySidechain = 1.0f - (kickDuckEnv * 0.24f)

                var sumL = 0.0
                var sumR = 0.0
                var revL = 0.0
                var revR = 0.0
                val iter = activeVoices.listIterator()
                while (iter.hasNext()) {
                    val v = iter.next()
                    val bg = when (v.bus) {
                        Bus.DRUMS -> dGain
                        Bus.BASS -> bGain
                        Bus.MELODY -> mGain * melodySidechain
                    }
                    val s = v.samples[v.index] * v.gain * bg
                    val l = s * v.panL
                    val r = s * v.panR
                    sumL += l
                    sumR += r
                    if (v.bus != Bus.BASS) {
                        revL += l * v.reverbSend
                        revR += r * v.reverbSend
                    }
                    v.index++
                    if (v.index >= v.samples.size) iter.remove()
                }
                if (useRev) {
                    val tap1 = (delayPos - 941 + delayLineL.size) % delayLineL.size
                    val tap2 = (delayPos - 1723 + delayLineL.size) % delayLineL.size
                    val tap3 = (delayPos - 2963 + delayLineL.size) % delayLineL.size
                    val rawWetL = delayLineL[tap1] * 0.42f + delayLineR[tap2] * 0.30f + delayLineL[tap3] * 0.18f
                    val rawWetR = delayLineR[tap1] * 0.42f + delayLineL[tap2] * 0.30f + delayLineR[tap3] * 0.18f
                    revLpL += (rawWetL - revLpL) * 0.46f
                    revLpR += (rawWetR - revLpR) * 0.46f
                    delayLineL[delayPos] = (revL.toFloat() + revLpR * 0.30f).coerceIn(-1f, 1f)
                    delayLineR[delayPos] = (revR.toFloat() + revLpL * 0.30f).coerceIn(-1f, 1f)
                    sumL += revLpL * 0.28
                    sumR += revLpR * 0.28
                    delayPos = (delayPos + 1) % delayLineL.size
                }

                val mid = (sumL + sumR) * 0.5
                val rawSide = (sumL - sumR) * 0.5
                val sideLow = subLowPassSide.process(rawSide.toFloat()).toDouble()
                val widenedSide = (rawSide - sideLow * 0.88) * 1.18
                chunkBuf[i * 2] = tanh((mid + widenedSide) * 0.84).toFloat()
                chunkBuf[i * 2 + 1] = tanh((mid - widenedSide) * 0.84).toFloat()
            }
            onChunk(chunkBuf, count)
            frame += count
            step = (step + 1) % 16
            if (step == 0) barInSong = (barInSong + 1) % 16
        }
    }

    private fun startCustomBeat(uri: Uri): Boolean {
        return try {
            _isPlaying.value = true
            _arrangementSection.value = "CUSTOM"
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                )
                setDataSource(context, uri)
                isLooping = true
                setOnPreparedListener { mp ->
                    if (!_isPlaying.value || customPlayer !== mp) return@setOnPreparedListener
                    mp.start()
                    stepJob?.cancel()
                    stepJob = scope.launch {
                        var step = 0
                        while (isActive && _isPlaying.value) {
                            _currentStep.value = step
                            step = (step + 1) % 16
                            val stepDelayMs = (60_000L / (currentBpm * 4L)).coerceAtLeast(60L)
                            delay(stepDelayMs)
                        }
                    }
                }
                setOnErrorListener { _, _, _ ->
                    stop()
                    true
                }
                prepareAsync()
            }
            customPlayer = player
            true
        } catch (_: Throwable) {
            stop()
            false
        }
    }

    fun stop() {
        _isPlaying.value = false
        loopJob?.cancel()
        loopJob = null
        stepJob?.cancel()
        stepJob = null
        customPlayer?.let { player ->
            runCatching {
                if (player.isPlaying) player.stop()
                player.release()
            }
        }
        customPlayer = null
        _currentStep.value = -1
        _arrangementSection.value = "VERSE"
    }

    fun release() {
        stop()
    }

    private enum class SongSection(val label: String) {
        INTRO("INTRO"),
        VERSE("VERSE"),
        BUILD("BUILD"),
        HOOK_DROP("HOOK DROP"),
    }

    private fun resolveSongSection(barInSong: Int): SongSection = when (barInSong % 16) {
        0, 1 -> SongSection.INTRO
        in 2..7 -> SongSection.VERSE
        8, 9 -> SongSection.BUILD
        else -> SongSection.HOOK_DROP
    }

    private fun applyGrooveSwingSamples(style: BeatStyle, step: Int, baseSamples: Int): Int {
        val swingAmount = when (style) {
            BeatStyle.BOOM_BAP, BeatStyle.LO_FI_SOUL -> 0.14
            BeatStyle.AFRO_BOUNCE -> 0.10
            BeatStyle.BIHU_FOLK_FUSION -> 0.08
            else -> 0.0
        }
        if (swingAmount == 0.0) return baseSamples
        return if (step % 2 == 0) {
            (baseSamples * (1.0 + swingAmount)).toInt()
        } else {
            (baseSamples * (1.0 - swingAmount)).toInt().coerceAtLeast(512)
        }
    }

    private fun triggerStepVoices(
        style: BeatStyle,
        step: Int,
        barInSong: Int,
        section: SongSection,
        voices: MutableList<StereoVoice>,
    ): Boolean {
        val bar = barInSong % 4
        val minorRoots = doubleArrayOf(130.81, 103.83, 87.31, 98.00) // C3, Ab2, F2, G2
        val soulRoots = doubleArrayOf(110.00, 87.31, 130.81, 98.00) // A2, F2, C3, G2
        val desiRoots = doubleArrayOf(146.83, 130.81, 116.54, 130.81) // D3, C3, Bb2, C3
        val drillRoots = doubleArrayOf(146.83, 146.83, 116.54, 130.81) // Dm -> Bb -> C
        var kickHit = false

        // Downbeat crash & riser cues for professional transitions
        if (step == 0 && (barInSong == 2 || barInSong == 10)) {
            voices.add(StereoVoice(crashCymbal, Bus.DRUMS, 0.56f, 0.88f, 1.12f, 0.65f))
        }
        if (section == SongSection.BUILD && barInSong == 9 && step == 0) {
            voices.add(StereoVoice(riserSweep, Bus.MELODY, 0.42f, 0.90f, 1.10f, 0.60f))
        }

        val allowFullDrums = section != SongSection.INTRO
        val isDrop = section == SongSection.HOOK_DROP
        val isFillStep = (bar == 3 && step >= 12) || (section == SongSection.BUILD && step in listOf(12, 14, 15))

        when (style) {
            BeatStyle.TRAP_808 -> {
                val root = minorRoots[bar]
                if (allowFullDrums && (step == 0 || step == 6 || step == 10 || (isDrop && step == 14))) {
                    voices.add(StereoVoice(kick808, Bus.DRUMS, 0.94f, 1.0f, 1.0f, 0.08f))
                    kickHit = true
                }
                if (allowFullDrums && (step == 0 || step == 10)) {
                    val bassLen = if (step == 0) 440 else 320
                    voices.add(StereoVoice(synthesizeBassNote(root / 2.0, bassLen), Bus.BASS, 0.68f, 1.0f, 1.0f, 0f))
                } else if (isDrop && step == 14) {
                    voices.add(StereoVoice(synthesizeBassGlide(root / 2.0, root * 0.75, 220), Bus.BASS, 0.60f, 1.0f, 1.0f, 0f))
                }
                if (allowFullDrums && (step == 4 || step == 12)) {
                    voices.add(StereoVoice(snareStudio, Bus.DRUMS, 0.74f, 0.96f, 1.04f, 0.35f))
                    voices.add(StereoVoice(clapStudio, Bus.DRUMS, 0.58f, 1.08f, 0.92f, 0.45f))
                }
                if (isFillStep && step in listOf(13, 14, 15)) {
                    voices.add(StereoVoice(hatRollTriplet, Bus.DRUMS, 0.40f, 1.14f, 0.86f, 0.25f))
                } else if (step % 2 == 0 || step == 5 || step == 11) {
                    val hatGain = if (step % 2 == 0) 0.34f else 0.22f
                    voices.add(StereoVoice(hatClosed, Bus.DRUMS, hatGain, 0.80f, 1.16f, 0.24f))
                }
                if (step == 0) {
                    voices.add(StereoVoice(synthesizeLushPad(root, minor = true, 1600), Bus.MELODY, 0.34f, 0.80f, 1.20f, 0.62f))
                    voices.add(StereoVoice(synthesizeStudioPianoChord(root * 2.0, minor = true, 1100), Bus.MELODY, 0.38f, 1.12f, 0.88f, 0.48f))
                }
                if (isDrop && (step == 0 || step == 3 || step == 6 || step == 10 || step == 12)) {
                    val ratio = when (step) {
                        3 -> 1.5
                        6 -> 2.0
                        10 -> 1.78
                        else -> 2.0
                    }
                    voices.add(StereoVoice(synthesizeBellLead(root * ratio, 380), Bus.MELODY, 0.32f, 1.16f, 0.84f, 0.52f))
                } else if (step == 0 || step == 6 || step == 12) {
                    voices.add(StereoVoice(synthesizePluckString(root * 2.0, 320), Bus.MELODY, 0.26f, 0.86f, 1.14f, 0.48f))
                }
            }

            BeatStyle.BOOM_BAP -> {
                val root = soulRoots[bar]
                if (allowFullDrums && (step == 0 || step == 7 || step == 10 || (isDrop && step == 15))) {
                    voices.add(StereoVoice(kickAcoustic, Bus.DRUMS, 0.96f, 1.0f, 1.0f, 0.14f))
                    kickHit = true
                }
                if (allowFullDrums && (step == 0 || step == 7 || (isDrop && step == 12))) {
                    voices.add(StereoVoice(synthesizeBassNote(root / 2.0, 280), Bus.BASS, 0.62f, 1.0f, 1.0f, 0f))
                }
                if (allowFullDrums && (step == 4 || step == 12)) {
                    voices.add(StereoVoice(snareStudio, Bus.DRUMS, 0.88f, 0.98f, 1.02f, 0.42f))
                } else if (isFillStep && step == 15) {
                    voices.add(StereoVoice(snareTight, Bus.DRUMS, 0.52f, 1.06f, 0.94f, 0.35f))
                }
                if (step % 2 == 0) {
                    val sample = if (step == 14) hatOpen else hatClosed
                    voices.add(StereoVoice(sample, Bus.DRUMS, 0.30f, 1.12f, 0.88f, 0.25f))
                }
                if (step == 0 || step == 8) {
                    voices.add(StereoVoice(synthesizeRhodesChord(root, minor = bar != 2, 820), Bus.MELODY, 0.46f, 0.88f, 1.12f, 0.48f))
                }
                if (isDrop && (step == 2 || step == 6 || step == 10)) {
                    voices.add(StereoVoice(synthesizeStudioPianoChord(root * 2.0, minor = bar != 2, 360), Bus.MELODY, 0.28f, 1.14f, 0.86f, 0.45f))
                }
            }

            BeatStyle.DESI_TRAP -> {
                val root = desiRoots[bar]
                if (allowFullDrums && (step == 0 || step == 6 || step == 10)) {
                    voices.add(StereoVoice(kick808, Bus.DRUMS, 0.92f, 1.0f, 1.0f, 0.08f))
                    kickHit = true
                }
                if (step == 0 || step == 8) {
                    voices.add(StereoVoice(tablaDha, Bus.DRUMS, 0.74f, 0.86f, 1.14f, 0.32f))
                }
                if (step == 2 || step == 6 || step == 10 || step == 14) {
                    voices.add(StereoVoice(tablaNa, Bus.DRUMS, 0.54f, 1.15f, 0.85f, 0.30f))
                }
                if (allowFullDrums && (step == 4 || step == 12)) {
                    voices.add(StereoVoice(clapStudio, Bus.DRUMS, 0.68f, 0.95f, 1.05f, 0.38f))
                }
                if (isFillStep && step == 14) {
                    voices.add(StereoVoice(hatRollTriplet, Bus.DRUMS, 0.36f, 0.82f, 1.18f, 0.22f))
                } else if (step % 2 == 0 || step == 11) {
                    voices.add(StereoVoice(hatClosed, Bus.DRUMS, 0.26f, 0.80f, 1.18f, 0.20f))
                }
                if (allowFullDrums && step == 0) {
                    voices.add(StereoVoice(synthesizeBassNote(root / 2.0, 440), Bus.BASS, 0.64f, 1.0f, 1.0f, 0f))
                }
                if (step == 0) {
                    voices.add(StereoVoice(synthesizeLushPad(root, minor = true, 1500), Bus.MELODY, 0.28f, 0.84f, 1.16f, 0.55f))
                }
                if (step == 0 || step == 3 || step == 6 || step == 10 || step == 14) {
                    val mult = when (step) {
                        3 -> 1.5
                        6 -> 1.78
                        10 -> 2.0
                        14 -> 1.5
                        else -> 1.0
                    }
                    voices.add(StereoVoice(synthesizePluckString(root * 2.0 * mult, 380), Bus.MELODY, if (isDrop) 0.42f else 0.34f, 1.12f, 0.88f, 0.48f))
                }
            }

            BeatStyle.BIHU_FOLK_FUSION -> {
                val root = desiRoots[bar]
                if (allowFullDrums && (step == 0 || step == 4 || step == 8 || step == 12)) {
                    voices.add(StereoVoice(kickAcoustic, Bus.DRUMS, 0.84f, 1.0f, 1.0f, 0.16f))
                    kickHit = true
                }
                if (step == 0 || step == 3 || step == 6 || step == 10 || step == 13) {
                    voices.add(StereoVoice(tablaDha, Bus.DRUMS, 0.78f, 0.88f, 1.12f, 0.32f))
                }
                if (step == 2 || step == 5 || step == 8 || step == 11 || step == 14) {
                    voices.add(StereoVoice(tablaNa, Bus.DRUMS, 0.60f, 1.16f, 0.84f, 0.30f))
                }
                if (allowFullDrums && (step == 0 || step == 6 || step == 12)) {
                    voices.add(StereoVoice(synthesizeBassNote(root / 2.0, 260), Bus.BASS, 0.58f, 1.0f, 1.0f, 0f))
                }
                if (step == 0 || step == 4 || step == 8 || step == 12 || (isDrop && step == 10)) {
                    val ratio = when (step) {
                        4, 12 -> 1.5
                        10 -> 1.78
                        else -> 2.0
                    }
                    voices.add(StereoVoice(synthesizePluckString(root * ratio, 320), Bus.MELODY, 0.42f, 0.85f, 1.15f, 0.45f))
                }
                if (isDrop && step == 0) {
                    voices.add(StereoVoice(synthesizeLushPad(root, minor = false, 1400), Bus.MELODY, 0.28f, 1.15f, 0.85f, 0.55f))
                }
            }

            BeatStyle.DRILL -> {
                val root = drillRoots[bar]
                if (allowFullDrums && (step == 0 || step == 3 || step == 10)) {
                    voices.add(StereoVoice(kick808, Bus.DRUMS, 0.96f, 1.0f, 1.0f, 0.08f))
                    kickHit = true
                }
                if (allowFullDrums && (step == 0 || step == 10 || step == 14)) {
                    if (step == 14) {
                        voices.add(StereoVoice(synthesizeBassGlide(root * 0.5, root * 1.0, 220), Bus.BASS, 0.74f, 1.0f, 1.0f, 0f))
                    } else {
                        voices.add(StereoVoice(synthesizeBassNote(root * 0.5, 360), Bus.BASS, 0.74f, 1.0f, 1.0f, 0f))
                    }
                }
                if (allowFullDrums && (step == 6 || step == 12)) {
                    voices.add(StereoVoice(snareStudio, Bus.DRUMS, 0.84f, 0.95f, 1.05f, 0.38f))
                }
                if (isFillStep && step == 14) {
                    voices.add(StereoVoice(hatRollTriplet, Bus.DRUMS, 0.42f, 0.78f, 1.20f, 0.28f))
                } else if (step == 0 || step == 2 || step == 3 || step == 6 || step == 8 || step == 10 || step == 11 || step == 14) {
                    voices.add(StereoVoice(hatClosed, Bus.DRUMS, 0.34f, 0.78f, 1.18f, 0.28f))
                }
                if (step == 0 || step == 8) {
                    voices.add(StereoVoice(synthesizeStudioPianoChord(root, minor = true, 640), Bus.MELODY, 0.42f, 1.15f, 0.85f, 0.55f))
                }
                if (isDrop && (step == 3 || step == 11)) {
                    voices.add(StereoVoice(synthesizeBellLead(root * 2.0, 320), Bus.MELODY, 0.26f, 0.84f, 1.16f, 0.52f))
                }
            }

            BeatStyle.LO_FI_SOUL -> {
                val root = soulRoots[bar]
                if (allowFullDrums && (step == 0 || step == 9)) {
                    voices.add(StereoVoice(kickAcoustic, Bus.DRUMS, 0.78f, 1.0f, 1.0f, 0.12f))
                    kickHit = true
                }
                if (allowFullDrums && (step == 4 || step == 12)) {
                    voices.add(StereoVoice(snareRim, Bus.DRUMS, 0.56f, 0.92f, 1.08f, 0.42f))
                }
                if (step % 2 == 0) {
                    voices.add(StereoVoice(hatClosed, Bus.DRUMS, 0.18f, 1.15f, 0.85f, 0.26f))
                }
                if (step == 0) {
                    if (allowFullDrums) {
                        voices.add(StereoVoice(synthesizeBassNote(root / 2.0, 520), Bus.BASS, 0.54f, 1.0f, 1.0f, 0f))
                    }
                    voices.add(StereoVoice(synthesizeRhodesChord(root, minor = bar != 2, 1350), Bus.MELODY, 0.56f, 0.86f, 1.14f, 0.54f))
                }
                if (isDrop && (step == 6 || step == 12)) {
                    voices.add(StereoVoice(synthesizeBellLead(root * 2.0, 420), Bus.MELODY, 0.22f, 1.14f, 0.86f, 0.58f))
                }
            }

            BeatStyle.AFRO_BOUNCE -> {
                val root = soulRoots[bar]
                if (allowFullDrums && (step == 0 || step == 6 || step == 10)) {
                    voices.add(StereoVoice(kickAcoustic, Bus.DRUMS, 0.88f, 1.0f, 1.0f, 0.12f))
                    kickHit = true
                }
                if (step == 3 || step == 6 || step == 11 || step == 14) {
                    voices.add(StereoVoice(snareRim, Bus.DRUMS, 0.64f, 1.12f, 0.88f, 0.35f))
                }
                if (step % 2 == 0) {
                    voices.add(StereoVoice(hatClosed, Bus.DRUMS, 0.24f, 0.85f, 1.15f, 0.22f))
                }
                if (allowFullDrums && (step == 0 || step == 6 || step == 10)) {
                    voices.add(StereoVoice(synthesizeBassNote(root / 2.0, 230), Bus.BASS, 0.62f, 1.0f, 1.0f, 0f))
                }
                if (step == 0 || step == 4 || step == 8 || step == 12 || (isDrop && step == 14)) {
                    val mult = if (step == 8 || step == 14) 2.5 else 2.0
                    voices.add(StereoVoice(synthesizePluckString(root * mult, 290), Bus.MELODY, 0.38f, 0.84f, 1.16f, 0.44f))
                }
            }

            BeatStyle.ORCHESTRAL_CINEMATIC -> {
                val root = minorRoots[bar]
                if (allowFullDrums && (step == 0 || step == 6 || step == 10)) {
                    voices.add(StereoVoice(kick808, Bus.DRUMS, 0.92f, 1.0f, 1.0f, 0.16f))
                    kickHit = true
                }
                if (allowFullDrums && (step == 4 || step == 12)) {
                    voices.add(StereoVoice(snareStudio, Bus.DRUMS, 0.82f, 0.96f, 1.04f, 0.48f))
                    voices.add(StereoVoice(clapStudio, Bus.DRUMS, 0.54f, 1.06f, 0.94f, 0.52f))
                }
                if (step % 2 == 0) {
                    voices.add(StereoVoice(hatClosed, Bus.DRUMS, 0.24f, 0.84f, 1.16f, 0.28f))
                }
                if (step == 0) {
                    if (allowFullDrums) {
                        voices.add(StereoVoice(synthesizeBassNote(root / 2.0, 620), Bus.BASS, 0.66f, 1.0f, 1.0f, 0f))
                    }
                    voices.add(StereoVoice(synthesizeLushPad(root, minor = true, 1800), Bus.MELODY, 0.42f, 0.80f, 1.20f, 0.65f))
                    voices.add(StereoVoice(synthesizeBrassStab(root, minor = true, 540), Bus.MELODY, if (isDrop) 0.52f else 0.36f, 1.12f, 0.88f, 0.55f))
                }
                if (step == 0 || step == 4 || step == 8 || step == 12) {
                    voices.add(StereoVoice(synthesizeStudioPianoChord(root * 2.0, minor = true, 420), Bus.MELODY, 0.32f, 0.88f, 1.12f, 0.52f))
                }
            }

            BeatStyle.PHONK_MEMPHIS -> {
                val root = drillRoots[bar]
                if (allowFullDrums && (step == 0 || step == 6 || step == 10 || step == 14)) {
                    voices.add(StereoVoice(kick808, Bus.DRUMS, 0.96f, 1.0f, 1.0f, 0.08f))
                    kickHit = true
                }
                if (allowFullDrums && (step == 0 || step == 10)) {
                    voices.add(StereoVoice(synthesizeBassNote(root / 2.0, 340), Bus.BASS, 0.72f, 1.0f, 1.0f, 0f))
                }
                if (allowFullDrums && (step == 4 || step == 12)) {
                    voices.add(StereoVoice(snareTight, Bus.DRUMS, 0.78f, 0.95f, 1.05f, 0.32f))
                    voices.add(StereoVoice(clapStudio, Bus.DRUMS, 0.52f, 1.08f, 0.92f, 0.38f))
                }
                if (step % 2 == 0 || step == 15) {
                    voices.add(StereoVoice(hatClosed, Bus.DRUMS, 0.28f, 0.80f, 1.18f, 0.22f))
                }
                // Classic Memphis Phonk syncopated cowbell melody
                if (step == 0 || step == 3 || step == 6 || step == 10 || step == 12 || (isDrop && step == 14)) {
                    voices.add(StereoVoice(cowbellMemphis, Bus.MELODY, 0.52f, 1.10f, 0.90f, 0.35f))
                }
            }

            BeatStyle.METRONOME -> {
                when (step) {
                    0 -> voices.add(StereoVoice(clickHigh, Bus.DRUMS, 0.90f, 1.0f, 1.0f, 0.05f))
                    4, 8, 12 -> voices.add(StereoVoice(clickLow, Bus.DRUMS, 0.72f, 1.0f, 1.0f, 0.05f))
                }
            }

            BeatStyle.CUSTOM -> Unit
        }
        return kickHit
    }

    private fun synthesizeStudioKick(
        startHz: Double,
        endHz: Double,
        durationMs: Int,
        drive: Double,
        subTail: Boolean,
    ): FloatArray {
        val length = (sampleRate * durationMs) / 1000
        val out = FloatArray(length)
        var phase = 0.0
        val rng = Random(11)
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            val progress = i.toDouble() / length
            val freq = endHz + (startHz - endHz) * exp(-25.0 * t)
            phase += 2.0 * PI * freq / sampleRate
            val beaterClick = if (i < sampleRate * 0.008) {
                (sin(2.0 * PI * 2900.0 * t) * 0.35 + rng.nextDouble(-0.2, 0.2)) * exp(-350.0 * t)
            } else {
                0.0
            }
            val decayRate = if (subTail) 5.8 else 9.8
            val env = exp(-decayRate * progress)
            val subBody = tanh(sin(phase) * drive) * env
            out[i] = (subBody + beaterClick).toFloat()
        }
        return out
    }

    private fun synthesizeStudioSnare(bodyHz: Double, durationMs: Int): FloatArray {
        val length = (sampleRate * durationMs) / 1000
        val out = FloatArray(length)
        val rng = Random(42)
        var prev = 0.0
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            val progress = i.toDouble() / length
            val shell = (sin(2.0 * PI * bodyHz * t) * 0.65 + sin(2.0 * PI * (bodyHz * 1.72) * t) * 0.35) * exp(-25.0 * t)
            val white = rng.nextDouble(-1.0, 1.0)
            val wire = white - 0.58 * prev
            prev = white
            val wireEnv = exp(-10.5 * progress)
            out[i] = (shell * 0.55 + wire * wireEnv * 0.58).toFloat()
        }
        return out
    }

    private fun synthesizeRimshot(): FloatArray {
        val length = (sampleRate * 75) / 1000
        val out = FloatArray(length)
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            val tone = sin(2.0 * PI * 420.0 * t) + 0.6 * sin(2.0 * PI * 980.0 * t)
            out[i] = (tanh(tone * 1.4) * exp(-55.0 * t) * 0.7).toFloat()
        }
        return out
    }

    private fun synthesizeStudioClap(): FloatArray {
        val length = (sampleRate * 180) / 1000
        val out = FloatArray(length)
        val rng = Random(99)
        var lp = 0.0
        var prev = 0.0
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            val burst = when {
                t < 0.012 -> exp(-240.0 * t)
                t < 0.024 -> exp(-240.0 * (t - 0.012))
                t < 0.036 -> exp(-240.0 * (t - 0.024))
                else -> exp(-18.0 * (t - 0.036))
            }
            val n = rng.nextDouble(-1.0, 1.0)
            val hp = n - 0.65 * prev
            prev = n
            lp = lp * 0.6 + hp * 0.4
            out[i] = (lp * burst * 0.85).toFloat()
        }
        return out
    }

    private fun synthesizeMetallicHat(durationMs: Int, decay: Double): FloatArray {
        val length = (sampleRate * durationMs) / 1000
        val out = FloatArray(length)
        val ratios = doubleArrayOf(263.0, 400.0, 421.0, 474.0, 587.0, 845.0)
        val rng = Random(17)
        var prev = 0.0
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            var metal = 0.0
            for (f in ratios) {
                metal += if (sin(2.0 * PI * f * t) >= 0.0) 1.0 else -1.0
            }
            metal /= ratios.size
            val noise = rng.nextDouble(-0.5, 0.5)
            val raw = metal * 0.65 + noise * 0.35
            val hp = raw - 0.82 * prev
            prev = raw
            out[i] = (hp * exp(-decay * t) * 0.65).toFloat()
        }
        return out
    }

    private fun synthesizeHatTripletRoll(): FloatArray {
        val single = hatClosed
        val gap = (sampleRate * 38) / 1000
        val total = gap * 2 + single.size
        val out = FloatArray(total)
        for (hit in 0..2) {
            val offset = hit * gap
            val vel = 0.55f + hit * 0.22f
            for (i in single.indices) {
                out[offset + i] += single[i] * vel
            }
        }
        return out
    }

    private fun synthesizeCrashCymbal(): FloatArray {
        val length = (sampleRate * 1100) / 1000
        val out = FloatArray(length)
        val rng = Random(313)
        var prev = 0.0
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            val shimmer = sin(2.0 * PI * 3120.0 * t) * 0.2 + sin(2.0 * PI * 4890.0 * t) * 0.2
            val n = rng.nextDouble(-1.0, 1.0)
            val hp = n - 0.78 * prev
            prev = n
            val env = (i / (sampleRate * 0.01)).coerceAtMost(1.0) * exp(-3.4 * t)
            out[i] = ((hp * 0.65 + shimmer) * env * 0.55).toFloat()
        }
        return out
    }

    private fun synthesizeRiserSweep(): FloatArray {
        val length = (sampleRate * 1600) / 1000
        val out = FloatArray(length)
        val rng = Random(701)
        var lp = 0.0
        for (i in 0 until length) {
            val p = i.toDouble() / length
            val n = rng.nextDouble(-1.0, 1.0)
            val cutoff = 0.03 + 0.55 * p * p
            lp += (n - lp) * cutoff
            val env = p * p * (1.0 - if (p > 0.94) (p - 0.94) / 0.06 else 0.0)
            out[i] = (lp * env * 0.55).toFloat()
        }
        return out
    }

    private fun synthesizeMemphisCowbell(): FloatArray {
        val length = (sampleRate * 185) / 1000
        val out = FloatArray(length)
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            val a = sin(2.0 * PI * 545.0 * t)
            val b = sin(2.0 * PI * 815.0 * t)
            out[i] = (tanh((a + b) * 1.65) * exp(-18.5 * t) * 0.55).toFloat()
        }
        return out
    }

    private fun synthesizeTablaDha(): FloatArray {
        val length = (sampleRate * 260) / 1000
        val out = FloatArray(length)
        var phase = 0.0
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            val freq = 105.0 + 75.0 * exp(-16.0 * t)
            phase += 2.0 * PI * freq / sampleRate
            val bayan = sin(phase) * exp(-8.0 * t)
            val syahi = sin(2.0 * PI * 320.0 * t) * 0.35 * exp(-22.0 * t)
            out[i] = (tanh((bayan + syahi) * 1.3) * 0.78).toFloat()
        }
        return out
    }

    private fun synthesizeTablaNa(): FloatArray {
        val length = (sampleRate * 140) / 1000
        val out = FloatArray(length)
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            val fundamental = sin(2.0 * PI * 330.0 * t) * 0.65
            val overtone = sin(2.0 * PI * 660.0 * t) * 0.45
            val ring = sin(2.0 * PI * 990.0 * t) * 0.25
            out[i] = ((fundamental + overtone + ring) * exp(-24.0 * t) * 0.7).toFloat()
        }
        return out
    }

    private val voiceCacheLock = Any()
    private val voiceCache = object : LinkedHashMap<String, FloatArray>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, FloatArray>?): Boolean = size > 96
    }

    private inline fun cachedVoice(key: String, builder: () -> FloatArray): FloatArray {
        synchronized(voiceCacheLock) {
            voiceCache[key]?.let { return it }
        }
        val built = builder()
        synchronized(voiceCacheLock) {
            voiceCache[key] = built
        }
        return built
    }

    private fun synthesizeBassNote(freqHz: Double, durationMs: Int): FloatArray =
        cachedVoice("bass_${(freqHz * 10).toInt()}_$durationMs") {
            val length = (sampleRate * durationMs) / 1000
            val out = FloatArray(length)
            for (i in 0 until length) {
                val t = i.toDouble() / sampleRate
                val progress = i.toDouble() / length
                val attack = (i / (sampleRate * 0.008)).coerceAtMost(1.0)
                val env = attack * exp(-3.2 * progress)
                val tone = sin(2.0 * PI * freqHz * t) + 0.34 * sin(2.0 * PI * freqHz * 2.0 * t) * exp(-7.5 * t)
                out[i] = (tanh(tone * 1.48) * env * 0.68).toFloat()
            }
            out
        }

    private fun synthesizeBassGlide(startHz: Double, endHz: Double, durationMs: Int): FloatArray =
        cachedVoice("glide_${(startHz * 10).toInt()}_${(endHz * 10).toInt()}_$durationMs") {
            val length = (sampleRate * durationMs) / 1000
            val out = FloatArray(length)
            var phase = 0.0
            for (i in 0 until length) {
                val p = i.toDouble() / length
                val freq = startHz + (endHz - startHz) * (1.0 - exp(-5.5 * p))
                phase += 2.0 * PI * freq / sampleRate
                val attack = (i / (sampleRate * 0.008)).coerceAtMost(1.0)
                val env = attack * exp(-2.8 * p)
                val tone = sin(phase) + 0.30 * sin(phase * 2.0)
                out[i] = (tanh(tone * 1.55) * env * 0.68).toFloat()
            }
            out
        }

    private fun synthesizeRhodesChord(rootHz: Double, minor: Boolean, durationMs: Int): FloatArray =
        cachedVoice("rhodes_${(rootHz * 10).toInt()}_${minor}_$durationMs") {
            val length = (sampleRate * durationMs) / 1000
            val out = FloatArray(length)
            val thirdRatio = if (minor) 1.1892 else 1.2599
            val freqs = doubleArrayOf(rootHz, rootHz * thirdRatio, rootHz * 1.4983, rootHz * 1.7818)
            for (i in 0 until length) {
                val t = i.toDouble() / sampleRate
                val progress = i.toDouble() / length
                val attack = (i / (sampleRate * 0.015)).coerceAtMost(1.0)
                val env = attack * exp(-2.8 * progress)
                val tremolo = 0.88 + 0.12 * cos(2.0 * PI * 4.5 * t)
                var sum = 0.0
                for (f in freqs) {
                    val warm = sin(2.0 * PI * f * t)
                    val tine = 0.22 * sin(2.0 * PI * f * 3.0 * t) * exp(-18.0 * t)
                    sum += warm + tine
                }
                out[i] = ((sum / freqs.size) * env * tremolo * 0.62).toFloat()
            }
            out
        }

    private fun synthesizeStudioPianoChord(rootHz: Double, minor: Boolean, durationMs: Int): FloatArray =
        cachedVoice("piano_${(rootHz * 10).toInt()}_${minor}_$durationMs") {
            val length = (sampleRate * durationMs) / 1000
            val out = FloatArray(length)
            val thirdRatio = if (minor) 1.1892 else 1.2599
            val freqs = doubleArrayOf(rootHz, rootHz * thirdRatio, rootHz * 1.4983, rootHz * 2.0)
            for (i in 0 until length) {
                val t = i.toDouble() / sampleRate
                val progress = i.toDouble() / length
                val attack = (i / (sampleRate * 0.004)).coerceAtMost(1.0)
                val env = attack * exp(-3.4 * progress)
                var sum = 0.0
                for (f in freqs) {
                    val p1 = sin(2.0 * PI * f * t)
                    val p2 = 0.42 * sin(2.0 * PI * f * 2.0 * t) * exp(-4.0 * t)
                    val p3 = 0.18 * sin(2.0 * PI * f * 3.0 * t) * exp(-9.0 * t)
                    sum += p1 + p2 + p3
                }
                out[i] = (tanh((sum / freqs.size) * 1.15) * env * 0.56).toFloat()
            }
            out
        }

    private fun synthesizeLushPad(rootHz: Double, minor: Boolean, durationMs: Int): FloatArray =
        cachedVoice("pad_${(rootHz * 10).toInt()}_${minor}_$durationMs") {
            val length = (sampleRate * durationMs) / 1000
            val out = FloatArray(length)
            val thirdRatio = if (minor) 1.1892 else 1.2599
            val freqs = doubleArrayOf(rootHz, rootHz * thirdRatio, rootHz * 1.4983)
            for (i in 0 until length) {
                val t = i.toDouble() / sampleRate
                val progress = i.toDouble() / length
                val attack = (i / (sampleRate * 0.18)).coerceAtMost(1.0)
                val release = if (progress > 0.75) (1.0 - (progress - 0.75) / 0.25) else 1.0
                var sum = 0.0
                for (f in freqs) {
                    sum += sin(2.0 * PI * f * t) + 0.65 * sin(2.0 * PI * (f * 1.0045) * t) + 0.3 * sin(2.0 * PI * (f * 1.997) * t)
                }
                out[i] = ((sum / (freqs.size * 2.0)) * attack * release * 0.52).toFloat()
            }
            out
        }

    private fun synthesizeBellLead(freqHz: Double, durationMs: Int): FloatArray =
        cachedVoice("bell_${(freqHz * 10).toInt()}_$durationMs") {
            val length = (sampleRate * durationMs) / 1000
            val out = FloatArray(length)
            for (i in 0 until length) {
                val t = i.toDouble() / sampleRate
                val progress = i.toDouble() / length
                val env = (i / (sampleRate * 0.005)).coerceAtMost(1.0) * exp(-4.8 * progress)
                val mod = 1.4 * exp(-12.0 * t) * sin(2.0 * PI * freqHz * 2.0 * t)
                val carrier = sin(2.0 * PI * freqHz * t + mod)
                out[i] = (carrier * env * 0.58).toFloat()
            }
            out
        }

    private fun synthesizeBrassStab(rootHz: Double, minor: Boolean, durationMs: Int): FloatArray =
        cachedVoice("brass_${(rootHz * 10).toInt()}_${minor}_$durationMs") {
            val length = (sampleRate * durationMs) / 1000
            val out = FloatArray(length)
            val thirdRatio = if (minor) 1.1892 else 1.2599
            val freqs = doubleArrayOf(rootHz, rootHz * thirdRatio, rootHz * 1.4983)
            for (i in 0 until length) {
                val t = i.toDouble() / sampleRate
                val progress = i.toDouble() / length
                val env = (i / (sampleRate * 0.035)).coerceAtMost(1.0) * exp(-2.8 * progress)
                var sum = 0.0
                for (f in freqs) {
                    var saw = 0.0
                    for (h in 1..5) {
                        saw += (1.0 / h) * sin(2.0 * PI * f * h * t)
                    }
                    sum += saw
                }
                out[i] = (tanh((sum / freqs.size) * 1.25) * env * 0.48).toFloat()
            }
            out
        }

    private fun synthesizePluckString(freqHz: Double, durationMs: Int): FloatArray =
        cachedVoice("pluck_${(freqHz * 10).toInt()}_$durationMs") {
            val length = (sampleRate * durationMs) / 1000
            val out = FloatArray(length)
            val period = (sampleRate / freqHz).toInt().coerceIn(20, 2048)
            val ring = FloatArray(period)
            val rng = Random(freqHz.toInt())
            for (j in 0 until period) {
                ring[j] = rng.nextFloat() * 2f - 1f
            }
            var idx = 0
            for (i in 0 until length) {
                val next = (idx + 1) % period
                val avg = 0.4972f * (ring[idx] + ring[next])
                ring[idx] = avg
                out[i] = avg * 0.56f
                idx = next
            }
            out
        }

    private fun synthesizeClick(freqHz: Double, gain: Double): FloatArray {
        val length = (sampleRate * 28) / 1000
        val out = FloatArray(length)
        for (i in 0 until length) {
            val t = i.toDouble() / sampleRate
            out[i] = (sin(2.0 * PI * freqHz * t) * exp(-140.0 * t) * gain).toFloat()
        }
        return out
    }

    private enum class Bus { DRUMS, BASS, MELODY }

    private data class StereoVoice(
        val samples: FloatArray,
        val bus: Bus,
        val gain: Float,
        val panL: Float,
        val panR: Float,
        val reverbSend: Float,
        var index: Int = 0,
    )
}
