package com.example.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

internal const val STUDIO_SAMPLE_RATE = 48000

enum class StudioPcmFormat(
    val displayName: String,
    val shortBadge: String,
    val bitsPerSample: Int,
    val isFloat: Boolean,
    val detail: String,
) {
    PCM_32_FLOAT(
        displayName = "32-Bit Float PCM",
        shortBadge = "32-BIT FLOAT",
        bitsPerSample = 32,
        isFloat = true,
        detail = "48 kHz • 32-Bit IEEE Float WAV (zero internal clipping)",
    ),
    PCM_24_INT(
        displayName = "24-Bit PCM Master",
        shortBadge = "24-BIT PCM",
        bitsPerSample = 24,
        isFloat = false,
        detail = "48 kHz • 24-Bit TPDF Dithered WAV (144 dB master)",
    ),
}

internal data class WavStreamInfo(
    val sampleRate: Int,
    val channels: Int,
    val bitsPerSample: Int,
    val isFloat: Boolean,
    val dataOffset: Int,
    val dataSize: Int,
)

internal fun inspectWavStreamHeader(headerBytes: ByteArray): WavStreamInfo? {
    if (headerBytes.size < 44) return null
    val buf = ByteBuffer.wrap(headerBytes).order(ByteOrder.LITTLE_ENDIAN)
    if (headerBytes[0] != 'R'.code.toByte() ||
        headerBytes[1] != 'I'.code.toByte() ||
        headerBytes[2] != 'F'.code.toByte() ||
        headerBytes[3] != 'F'.code.toByte()
    ) return null
    if (headerBytes[8] != 'W'.code.toByte() ||
        headerBytes[9] != 'A'.code.toByte() ||
        headerBytes[10] != 'V'.code.toByte() ||
        headerBytes[11] != 'E'.code.toByte()
    ) return null

    var pos = 12
    var audioFormat = 0
    var channels = 0
    var sampleRate = 0
    var bitsPerSample = 0
    var isFloat = false
    var dataOffset = -1
    var dataSize = 0

    while (pos + 8 <= headerBytes.size) {
        val id = String(headerBytes, pos, 4, Charsets.US_ASCII)
        val chunkSize = buf.getInt(pos + 4).coerceAtLeast(0)
        val bodyStart = pos + 8
        when (id) {
            "fmt " -> {
                if (bodyStart + 16 > headerBytes.size) return null
                audioFormat = buf.getShort(bodyStart).toInt() and 0xFFFF
                channels = (buf.getShort(bodyStart + 2).toInt() and 0xFFFF).coerceAtLeast(1)
                sampleRate = buf.getInt(bodyStart + 4).coerceAtLeast(8000)
                bitsPerSample = buf.getShort(bodyStart + 14).toInt() and 0xFFFF
                isFloat = audioFormat == 3
                if (audioFormat == 0xFFFE && chunkSize >= 40 && bodyStart + 26 <= headerBytes.size) {
                    val subFormatTag = buf.getShort(bodyStart + 24).toInt() and 0xFFFF
                    isFloat = subFormatTag == 3
                }
            }
            "data" -> {
                dataOffset = bodyStart
                dataSize = chunkSize
                break
            }
        }
        val padded = chunkSize + (chunkSize and 1)
        pos = bodyStart + padded
    }

    if (dataOffset < 0 || channels <= 0 || sampleRate <= 0) return null
    val supportedFormat = audioFormat == 1 || audioFormat == 3 || audioFormat == 0xFFFE
    if (!supportedFormat) return null
    return WavStreamInfo(
        sampleRate = sampleRate,
        channels = channels,
        bitsPerSample = bitsPerSample,
        isFloat = isFloat,
        dataOffset = dataOffset,
        dataSize = dataSize,
    )
}

internal fun detectTakeAudioFormatLabel(filePath: String): String {
    if (!filePath.endsWith(".wav", ignoreCase = true)) return "STUDIO AAC"
    val file = File(filePath)
    if (!file.exists()) return "24-BIT WAV"
    val info = runCatching {
        FileInputStream(file).use { input ->
            val buf = ByteArray(128)
            val read = input.read(buf)
            if (read >= 44) inspectWavStreamHeader(buf.copyOf(read)) else null
        }
    }.getOrNull() ?: return "24-BIT WAV"

    return when {
        info.isFloat && info.bitsPerSample >= 32 -> "32-BIT FLOAT"
        info.bitsPerSample == 32 -> "32-BIT PCM"
        info.bitsPerSample == 24 -> "24-BIT PCM"
        else -> "${info.bitsPerSample}-BIT WAV"
    }
}

internal fun decodeWavBytesToChannels48000(wavBytes: ByteArray): Pair<FloatArray, FloatArray>? {
    val info = inspectWavStreamHeader(wavBytes) ?: return null
    val bytesPerSample = (info.bitsPerSample / 8).coerceAtLeast(2)
    val availableBytes = (wavBytes.size - info.dataOffset).coerceAtMost(info.dataSize).coerceAtLeast(0)
    val totalFrames = availableBytes / (bytesPerSample * info.channels)
    if (totalFrames <= 0) return FloatArray(0) to FloatArray(0)

    val left = FloatArray(totalFrames)
    val right = FloatArray(totalFrames)
    val bb = ByteBuffer.wrap(wavBytes).order(ByteOrder.LITTLE_ENDIAN)
    var offset = info.dataOffset

    for (f in 0 until totalFrames) {
        var lSample = 0f
        var rSample = 0f
        for (c in 0 until info.channels) {
            val s = readPcmSampleNormalized(wavBytes, bb, offset, info.bitsPerSample, info.isFloat)
            if (c == 0) lSample = s
            if (c == 1) rSample = s
            offset += bytesPerSample
        }
        left[f] = lSample
        right[f] = if (info.channels >= 2) rSample else lSample
    }

    if (info.sampleRate == STUDIO_SAMPLE_RATE) return left to right
    return resampleCubic(left, info.sampleRate, STUDIO_SAMPLE_RATE) to
        resampleCubic(right, info.sampleRate, STUDIO_SAMPLE_RATE)
}

internal fun decodeAudioToStereo48000(context: Context, pathOrUri: String): Pair<FloatArray, FloatArray> {
    if (!pathOrUri.startsWith("content://") && pathOrUri.endsWith(".wav", ignoreCase = true)) {
        val file = File(pathOrUri)
        if (file.exists()) {
            val wavDecoded = decodeWavFileStreamingToStereo48000(file)
            if (wavDecoded != null) return wavDecoded
        }
    } else if (pathOrUri.startsWith("content://")) {
        runCatching {
            context.contentResolver.openInputStream(Uri.parse(pathOrUri))?.use { stream ->
                val head = ByteArray(128)
                val read = stream.read(head)
                if (read >= 44 && inspectWavStreamHeader(head.copyOf(read)) != null) {
                    val rest = stream.readBytes()
                    val full = head.copyOf(read) + rest
                    decodeWavBytesToChannels48000(full)
                } else {
                    null
                }
            }
        }.getOrNull()?.let { return it }
    }

    val extractor = MediaExtractor()
    if (pathOrUri.startsWith("content://")) {
        extractor.setDataSource(context, Uri.parse(pathOrUri), null)
    } else {
        extractor.setDataSource(pathOrUri)
    }

    var trackIdx = -1
    var format: MediaFormat? = null
    for (i in 0 until extractor.trackCount) {
        val f = extractor.getTrackFormat(i)
        val mime = f.getString(MediaFormat.KEY_MIME).orEmpty()
        if (mime.startsWith("audio/")) {
            trackIdx = i
            format = f
            break
        }
    }
    val audioFormat = format ?: error("No audio track found in media source")
    val mime = audioFormat.getString(MediaFormat.KEY_MIME) ?: error("Missing audio MIME type")
    var srcSampleRate = audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
    var srcChannels = audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
    var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT

    extractor.selectTrack(trackIdx)
    val codec = MediaCodec.createDecoderByType(mime)
    codec.configure(audioFormat, null, null, 0)
    codec.start()

    val pcmBytes = ByteArrayOutputStream()
    val info = MediaCodec.BufferInfo()
    var sawInputEos = false
    var sawOutputEos = false

    try {
        while (!sawOutputEos) {
            if (!sawInputEos) {
                val inIdx = codec.dequeueInputBuffer(10_000L)
                if (inIdx >= 0) {
                    val buf = codec.getInputBuffer(inIdx) ?: continue
                    val sampleSize = extractor.readSampleData(buf, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        sawInputEos = true
                    } else {
                        codec.queueInputBuffer(inIdx, 0, sampleSize, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }
            }

            val outIdx = codec.dequeueOutputBuffer(info, 10_000L)
            if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val outFmt = codec.outputFormat
                if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                    srcSampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                }
                if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                    srcChannels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                }
                if (outFmt.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                    pcmEncoding = outFmt.getInteger(MediaFormat.KEY_PCM_ENCODING)
                }
            } else if (outIdx >= 0) {
                val outBuf = codec.getOutputBuffer(outIdx)
                if (outBuf != null && info.size > 0) {
                    val chunk = ByteArray(info.size)
                    outBuf.position(info.offset)
                    outBuf.get(chunk)
                    pcmBytes.write(chunk)
                }
                codec.releaseOutputBuffer(outIdx, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    sawOutputEos = true
                }
            }
        }
    } finally {
        runCatching { codec.stop() }
        runCatching { codec.release() }
        runCatching { extractor.release() }
    }

    val rawBytes = pcmBytes.toByteArray()
    val (bitsPerSample, isFloat) = when (pcmEncoding) {
        AudioFormat.ENCODING_PCM_FLOAT -> 32 to true
        AudioFormat.ENCODING_PCM_24BIT_PACKED -> 24 to false
        AudioFormat.ENCODING_PCM_32BIT -> 32 to false
        else -> 16 to false
    }
    val bytesPerSample = bitsPerSample / 8
    val frameCount = rawBytes.size / (bytesPerSample * srcChannels)
    val left = FloatArray(frameCount)
    val right = FloatArray(frameCount)
    val bb = ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN)
    var pos = 0

    for (f in 0 until frameCount) {
        var l = 0f
        var r = 0f
        for (c in 0 until srcChannels) {
            val s = readPcmSampleNormalized(rawBytes, bb, pos, bitsPerSample, isFloat)
            if (c == 0) l = s
            if (c == 1) r = s
            pos += bytesPerSample
        }
        left[f] = l
        right[f] = if (srcChannels >= 2) r else l
    }

    if (srcSampleRate == STUDIO_SAMPLE_RATE || left.isEmpty()) return left to right
    return resampleCubic(left, srcSampleRate, STUDIO_SAMPLE_RATE) to
        resampleCubic(right, srcSampleRate, STUDIO_SAMPLE_RATE)
}

internal fun decodeAudioToMono48000(context: Context, pathOrUri: String): FloatArray {
    val (left, right) = decodeAudioToStereo48000(context, pathOrUri)
    if (left.isEmpty()) return left
    val mono = FloatArray(left.size)
    for (i in left.indices) {
        mono[i] = 0.5f * (left[i] + right[i])
    }
    return mono
}

private fun decodeWavFileStreamingToStereo48000(file: File): Pair<FloatArray, FloatArray>? {
    FileInputStream(file).use { input ->
        val headerProbe = ByteArray(256)
        val probeRead = input.read(headerProbe)
        if (probeRead < 44) return null
        val info = inspectWavStreamHeader(headerProbe.copyOf(probeRead)) ?: return null

        val bytesPerSample = (info.bitsPerSample / 8).coerceAtLeast(2)
        val frameBytes = bytesPerSample * info.channels
        val maxAvailable = (file.length() - info.dataOffset).coerceAtMost(info.dataSize.toLong()).coerceAtLeast(0L)
        val totalFrames = (maxAvailable / frameBytes.toLong()).toInt()
        if (totalFrames <= 0) return FloatArray(0) to FloatArray(0)

        val left = FloatArray(totalFrames)
        val right = FloatArray(totalFrames)

        FileInputStream(file).use { dataStream ->
            var toSkip = info.dataOffset.toLong()
            while (toSkip > 0L) {
                val skipped = dataStream.skip(toSkip)
                if (skipped <= 0L) break
                toSkip -= skipped
            }

            val bufFrames = 16384
            val ioBuf = ByteArray(bufFrames * frameBytes)
            val bb = ByteBuffer.wrap(ioBuf).order(ByteOrder.LITTLE_ENDIAN)
            var frameIdx = 0
            var carry = 0

            while (frameIdx < totalFrames) {
                val read = dataStream.read(ioBuf, carry, ioBuf.size - carry)
                if (read <= 0) break
                val totalAvail = carry + read
                val readableFrames = (totalAvail / frameBytes).coerceAtMost(totalFrames - frameIdx)
                var pos = 0
                for (f in 0 until readableFrames) {
                    var l = 0f
                    var r = 0f
                    for (c in 0 until info.channels) {
                        val s = readPcmSampleNormalized(ioBuf, bb, pos, info.bitsPerSample, info.isFloat)
                        if (c == 0) l = s
                        if (c == 1) r = s
                        pos += bytesPerSample
                    }
                    left[frameIdx] = l
                    right[frameIdx] = if (info.channels >= 2) r else l
                    frameIdx++
                }
                val consumed = readableFrames * frameBytes
                val leftover = totalAvail - consumed
                if (leftover > 0) {
                    System.arraycopy(ioBuf, consumed, ioBuf, 0, leftover)
                }
                carry = leftover
            }
        }

        if (info.sampleRate == STUDIO_SAMPLE_RATE) return left to right
        return resampleCubic(left, info.sampleRate, STUDIO_SAMPLE_RATE) to
            resampleCubic(right, info.sampleRate, STUDIO_SAMPLE_RATE)
    }
}

internal fun readPcmSampleNormalized(
    raw: ByteArray,
    bb: ByteBuffer,
    offset: Int,
    bitsPerSample: Int,
    isFloat: Boolean,
): Float {
    return when {
        isFloat && bitsPerSample == 32 -> {
            val f = bb.getFloat(offset)
            if (f.isFinite()) f else 0f
        }
        isFloat && bitsPerSample == 64 -> {
            val d = bb.getDouble(offset).toFloat()
            if (d.isFinite()) d else 0f
        }
        bitsPerSample == 24 -> {
            val b0 = raw[offset].toInt() and 0xFF
            val b1 = raw[offset + 1].toInt() and 0xFF
            val b2 = raw[offset + 2].toInt()
            val signed = (b2 shl 16) or (b1 shl 8) or b0
            signed / 8388608f
        }
        bitsPerSample == 32 -> {
            bb.getInt(offset) / 2147483648f
        }
        else -> {
            bb.getShort(offset) / 32768f
        }
    }
}

internal fun resampleCubic(src: FloatArray, srcRate: Int, dstRate: Int): FloatArray {
    if (src.isEmpty() || srcRate == dstRate) return src
    if (src.size < 4) return resampleLinear(src, srcRate, dstRate)
    val targetLen = ((src.size.toLong() * dstRate.toLong()) / srcRate.toLong()).toInt().coerceAtLeast(1)
    val out = FloatArray(targetLen)
    val ratio = (src.size - 1).toDouble() / targetLen.coerceAtLeast(1)
    val lastIdx = src.lastIndex
    for (i in 0 until targetLen) {
        val pos = i * ratio
        val i1 = pos.toInt().coerceIn(0, lastIdx)
        val t = (pos - i1).toFloat()
        val p0 = src[(i1 - 1).coerceAtLeast(0)]
        val p1 = src[i1]
        val p2 = src[(i1 + 1).coerceAtMost(lastIdx)]
        val p3 = src[(i1 + 2).coerceAtMost(lastIdx)]
        // Catmull-Rom cubic interpolation for low-aliasing studio sample rate conversion
        val t2 = t * t
        val t3 = t2 * t
        out[i] = 0.5f * (
            (2f * p1) +
                (-p0 + p2) * t +
                (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 +
                (-p0 + 3f * p1 - 3f * p2 + p3) * t3
            )
    }
    return out
}

internal fun resampleLinear(src: FloatArray, srcRate: Int, dstRate: Int): FloatArray {
    if (src.isEmpty() || srcRate == dstRate) return src
    val targetLen = ((src.size.toLong() * dstRate.toLong()) / srcRate.toLong()).toInt().coerceAtLeast(1)
    val out = FloatArray(targetLen)
    val ratio = (src.size - 1).toDouble() / targetLen.coerceAtLeast(1)
    for (i in 0 until targetLen) {
        val pos = i * ratio
        val idx0 = pos.toInt().coerceIn(0, src.lastIndex)
        val idx1 = (idx0 + 1).coerceIn(0, src.lastIndex)
        val frac = (pos - idx0).toFloat()
        out[i] = src[idx0] * (1f - frac) + src[idx1] * frac
    }
    return out
}

internal fun copyUriOrFileToInternal(context: Context, uri: Uri, destDir: File, fileName: String): File {
    destDir.mkdirs()
    val outFile = File(destDir, fileName)
    context.contentResolver.openInputStream(uri)?.use { input ->
        outFile.outputStream().use { output ->
            input.copyTo(output)
        }
    } ?: error("Cannot open selected audio file")
    return outFile
}

/**
 * Extracts per-frame multi-band audio-reactive spectrum bars (40 log-spaced bands via Goertzel)
 * at [fps] frames per second directly from mono 48kHz audio samples.
 */
internal fun extractSpectrumTimeline(
    mono48k: FloatArray,
    fps: Int = 30,
    bandCount: Int = 40,
): List<FloatArray> {
    if (mono48k.isEmpty()) return emptyList()
    val samplesPerFrame = STUDIO_SAMPLE_RATE / fps
    val totalFrames = (mono48k.size / samplesPerFrame).coerceAtLeast(1)
    val windowSize = 512

    val coeffs = FloatArray(bandCount)
    val minF = ln(55.0)
    val maxF = ln(11000.0)
    for (b in 0 until bandCount) {
        val freq = exp(minF + (maxF - minF) * (b.toDouble() / (bandCount - 1).coerceAtLeast(1)))
        val k = (0.5 + (windowSize * freq) / STUDIO_SAMPLE_RATE).toInt().coerceAtLeast(1)
        val omega = (2.0 * PI * k) / windowSize
        coeffs[b] = (2.0 * cos(omega)).toFloat()
    }

    val prevBars = FloatArray(bandCount) { 0.08f }
    val frames = ArrayList<FloatArray>(totalFrames)

    for (f in 0 until totalFrames) {
        val center = f * samplesPerFrame
        val start = (center - windowSize / 2).coerceIn(0, (mono48k.size - windowSize).coerceAtLeast(0))
        val available = (mono48k.size - start).coerceAtMost(windowSize)
        val out = FloatArray(bandCount)
        if (available >= 64) {
            var rmsAcc = 0f
            for (n in 0 until available) {
                val s = mono48k[start + n]
                rmsAcc += s * s
            }
            val frameRms = sqrt(rmsAcc / available)
            for (b in 0 until bandCount) {
                val c = coeffs[b]
                var sPrev = 0f
                var sPrev2 = 0f
                for (n in 0 until available) {
                    val hann = 0.5f * (1f - cos((2.0 * PI * n) / (available - 1)).toFloat())
                    val sample = mono48k[start + n] * hann
                    val s = sample + c * sPrev - sPrev2
                    sPrev2 = sPrev
                    sPrev = s
                }
                val power = (sPrev2 * sPrev2 + sPrev * sPrev - c * sPrev * sPrev2).coerceAtLeast(0f)
                val mag = (sqrt(power) / (available * 0.25f) * 1.4f + frameRms * 0.65f).coerceIn(0.05f, 1.0f)
                val smoothed = if (mag > prevBars[b]) {
                    prevBars[b] * 0.30f + mag * 0.70f
                } else {
                    prevBars[b] * 0.72f + mag * 0.28f
                }
                prevBars[b] = smoothed
                out[b] = smoothed
            }
        } else {
            out.fill(0.08f)
        }
        frames.add(out)
    }
    return frames
}

internal fun writeSampleFloat32(dst: ByteArray, offset: Int, sampleFloat: Float): Int {
    val bits = (if (sampleFloat.isFinite()) sampleFloat else 0f).toRawBits()
    dst[offset] = (bits and 0xFF).toByte()
    dst[offset + 1] = ((bits shr 8) and 0xFF).toByte()
    dst[offset + 2] = ((bits shr 16) and 0xFF).toByte()
    dst[offset + 3] = ((bits shr 24) and 0xFF).toByte()
    return offset + 4
}

internal fun writeSample24Tpdf(dst: ByteArray, offset: Int, sampleNorm: Double, rng: Random): Int {
    val dither = (rng.nextDouble() - rng.nextDouble()) / 8388607.0
    val scaled = ((sampleNorm + dither) * 8388607.0).toInt().coerceIn(-8388608, 8388607)
    dst[offset] = (scaled and 0xFF).toByte()
    dst[offset + 1] = ((scaled shr 8) and 0xFF).toByte()
    dst[offset + 2] = ((scaled shr 16) and 0xFF).toByte()
    return offset + 3
}

internal fun writeWavSample(
    dst: ByteArray,
    offset: Int,
    sampleNorm: Double,
    format: StudioPcmFormat,
    rng: Random,
): Int {
    return if (format.isFloat) {
        writeSampleFloat32(dst, offset, sampleNorm.toFloat())
    } else {
        writeSample24Tpdf(dst, offset, sampleNorm, rng)
    }
}

internal fun writeWavHeader(
    out: OutputStream,
    totalFrames: Long,
    sampleRate: Int,
    channels: Int,
    format: StudioPcmFormat,
) {
    val header = buildWavHeaderBytes(totalFrames, sampleRate, channels, format)
    out.write(header)
}

internal fun buildWavHeaderBytes(
    totalFrames: Long,
    sampleRate: Int,
    channels: Int,
    format: StudioPcmFormat,
): ByteArray {
    val bytesPerSample = format.bitsPerSample / 8
    val blockAlign = channels * bytesPerSample
    val dataSize = (totalFrames * blockAlign.toLong()).coerceAtMost(Int.MAX_VALUE.toLong() - 36L).toInt()
    val totalSize = 36 + dataSize
    val formatTag: Short = if (format.isFloat) 3 else 1 // 3 = IEEE_FLOAT, 1 = Linear PCM
    return ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
        put("RIFF".toByteArray())
        putInt(totalSize)
        put("WAVE".toByteArray())
        put("fmt ".toByteArray())
        putInt(16)
        putShort(formatTag)
        putShort(channels.toShort())
        putInt(sampleRate)
        putInt(sampleRate * blockAlign)
        putShort(blockAlign.toShort())
        putShort(format.bitsPerSample.toShort())
        put("data".toByteArray())
        putInt(dataSize)
    }.array()
}

internal fun writeWav24Header(out: OutputStream, totalFrames: Long, sampleRate: Int, channels: Int = 2) {
    writeWavHeader(out, totalFrames, sampleRate, channels, StudioPcmFormat.PCM_24_INT)
}

internal class OnePoleHighPass(cutoffHz: Double, sampleRate: Int) {
    private val rc = 1.0 / (2.0 * PI * cutoffHz)
    private val dt = 1.0 / sampleRate
    private val alpha = (rc / (rc + dt)).toFloat()
    private var prevIn = 0f
    private var prevOut = 0f

    fun process(x: Float): Float {
        val y = alpha * (prevOut + x - prevIn)
        prevIn = x
        prevOut = y
        return y
    }
}

internal class OnePoleLowPass(cutoffHz: Double, sampleRate: Int) {
    private val rc = 1.0 / (2.0 * PI * cutoffHz)
    private val dt = 1.0 / sampleRate
    private val alpha = (dt / (rc + dt)).toFloat()
    private var prevOut = 0f

    fun process(x: Float): Float {
        prevOut += alpha * (x - prevOut)
        return prevOut
    }
}

internal class BiquadFilter(
    private val b0: Float,
    private val b1: Float,
    private val b2: Float,
    private val a1: Float,
    private val a2: Float,
) {
    private var x1 = 0f
    private var x2 = 0f
    private var y1 = 0f
    private var y2 = 0f

    fun process(x: Float): Float {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1
        x1 = x
        y2 = y1
        y1 = y
        return y
    }

    companion object {
        fun peaking(freqHz: Double, sampleRate: Int, q: Double, gainDb: Double): BiquadFilter {
            val a = Math.pow(10.0, gainDb / 40.0)
            val w0 = 2.0 * PI * freqHz / sampleRate
            val alpha = sin(w0) / (2.0 * q)
            val cosW0 = cos(w0)
            val b0 = 1.0 + alpha * a
            val b1 = -2.0 * cosW0
            val b2 = 1.0 - alpha * a
            val a0 = 1.0 + alpha / a
            val a1 = -2.0 * cosW0
            val a2 = 1.0 - alpha / a
            return BiquadFilter(
                (b0 / a0).toFloat(),
                (b1 / a0).toFloat(),
                (b2 / a0).toFloat(),
                (a1 / a0).toFloat(),
                (a2 / a0).toFloat(),
            )
        }

        fun highShelf(freqHz: Double, sampleRate: Int, gainDb: Double): BiquadFilter {
            val a = Math.pow(10.0, gainDb / 40.0)
            val w0 = 2.0 * PI * freqHz / sampleRate
            val cosW0 = cos(w0)
            val sinW0 = sin(w0)
            val alpha = sinW0 / 2.0 * sqrt(2.0)
            val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
            val b0 = a * ((a + 1) + (a - 1) * cosW0 + twoSqrtAAlpha)
            val b1 = -2 * a * ((a - 1) + (a + 1) * cosW0)
            val b2 = a * ((a + 1) + (a - 1) * cosW0 - twoSqrtAAlpha)
            val a0 = (a + 1) - (a - 1) * cosW0 + twoSqrtAAlpha
            val a1 = 2 * ((a - 1) - (a + 1) * cosW0)
            val a2 = (a + 1) - (a - 1) * cosW0 - twoSqrtAAlpha
            return BiquadFilter(
                (b0 / a0).toFloat(),
                (b1 / a0).toFloat(),
                (b2 / a0).toFloat(),
                (a1 / a0).toFloat(),
                (a2 / a0).toFloat(),
            )
        }

        fun lowPass(freqHz: Double, sampleRate: Int, q: Double = 0.707): BiquadFilter {
            val w0 = 2.0 * PI * freqHz / sampleRate
            val alpha = sin(w0) / (2.0 * q)
            val cosW0 = cos(w0)
            val b0 = (1.0 - cosW0) / 2.0
            val b1 = 1.0 - cosW0
            val b2 = (1.0 - cosW0) / 2.0
            val a0 = 1.0 + alpha
            val a1 = -2.0 * cosW0
            val a2 = 1.0 - alpha
            return BiquadFilter(
                (b0 / a0).toFloat(),
                (b1 / a0).toFloat(),
                (b2 / a0).toFloat(),
                (a1 / a0).toFloat(),
                (a2 / a0).toFloat(),
            )
        }

        fun bandPass(freqHz: Double, sampleRate: Int, q: Double = 2.2): BiquadFilter {
            val w0 = 2.0 * PI * freqHz / sampleRate
            val alpha = sin(w0) / (2.0 * q)
            val cosW0 = cos(w0)
            val b0 = alpha
            val b1 = 0.0
            val b2 = -alpha
            val a0 = 1.0 + alpha
            val a1 = -2.0 * cosW0
            val a2 = 1.0 - alpha
            return BiquadFilter(
                (b0 / a0).toFloat(),
                (b1 / a0).toFloat(),
                (b2 / a0).toFloat(),
                (a1 / a0).toFloat(),
                (a2 / a0).toFloat(),
            )
        }
    }
}

data class AudioDetailReport(
    val title: String,
    val formatLabel: String,
    val sampleRateHz: Int,
    val channelsLabel: String,
    val bitDepthLabel: String,
    val bitrateKbpsLabel: String,
    val fileSizeLabel: String,
    val durationLabel: String,
    val peakDbfsLabel: String,
    val rmsDbfsLabel: String,
    val dynamicRangeLabel: String,
    val clippingLabel: String,
)

internal fun inspectAudioFileDetails(context: Context, title: String, filePath: String, durationMs: Long): AudioDetailReport {
    val file = File(filePath)
    val bytes = if (file.exists()) file.length() else 0L
    val fileSizeLabel = when {
        bytes >= 1024L * 1024L -> String.format(java.util.Locale.US, "%.2f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024L -> "${bytes / 1024L} KB"
        else -> "$bytes B"
    }

    val wavHeader = if (file.exists() && filePath.endsWith(".wav", ignoreCase = true)) {
        runCatching {
            FileInputStream(file).use { input ->
                val head = ByteArray(128)
                val read = input.read(head)
                if (read >= 44) inspectWavStreamHeader(head.copyOf(read)) else null
            }
        }.getOrNull()
    } else {
        null
    }

    val (left, right) = runCatching { decodeAudioToStereo48000(context, filePath) }
        .getOrElse { FloatArray(0) to FloatArray(0) }

    var peak = 1e-6f
    var sumSq = 0.0
    var clips = 0
    val n = left.size.coerceAtLeast(1)
    for (i in left.indices) {
        val l = kotlin.math.abs(left[i])
        val r = kotlin.math.abs(right[i])
        if (l > peak) peak = l
        if (r > peak) peak = r
        if (l >= 0.999f || r >= 0.999f) clips++
        sumSq += (left[i] * left[i] + right[i] * right[i]) * 0.5
    }

    val rms = sqrt(sumSq / n).toFloat().coerceAtLeast(1e-6f)
    val peakDb = 20.0 * kotlin.math.log10(peak.toDouble())
    val rmsDb = 20.0 * kotlin.math.log10(rms.toDouble())
    val crestDb = (peakDb - rmsDb).coerceAtLeast(0.0)

    val sr = wavHeader?.sampleRate ?: STUDIO_SAMPLE_RATE
    val channels = wavHeader?.channels ?: 2
    val bits = wavHeader?.bitsPerSample ?: 16
    val kbps = if (wavHeader != null) (sr * channels * bits) / 1000 else 320

    val totalSec = (durationMs / 1000L).coerceAtLeast(1L)
    val durStr = String.format(java.util.Locale.US, "%d:%02d", totalSec / 60L, totalSec % 60L)

    return AudioDetailReport(
        title = title,
        formatLabel = detectTakeAudioFormatLabel(filePath),
        sampleRateHz = sr,
        channelsLabel = if (channels == 1) "Mono (1 ch)" else "Stereo ($channels ch)",
        bitDepthLabel = when {
            wavHeader == null -> "AAC-LC Variable"
            wavHeader.isFloat -> "32-Bit IEEE Float"
            else -> "$bits-Bit Linear PCM"
        },
        bitrateKbpsLabel = if (wavHeader != null) "$kbps kbps (Lossless WAV)" else "~320 kbps AAC",
        fileSizeLabel = fileSizeLabel,
        durationLabel = durStr,
        peakDbfsLabel = String.format(java.util.Locale.US, "%.1f dBFS", peakDb),
        rmsDbfsLabel = String.format(java.util.Locale.US, "%.1f dBFS", rmsDb),
        dynamicRangeLabel = String.format(java.util.Locale.US, "%.1f dB Crest", crestDb),
        clippingLabel = if (clips == 0) "0 Clips (Clean Headroom)" else "$clips samples near 0 dBFS",
    )
}
