package com.example.audio

import android.content.Context
import com.example.data.local.BeatStyle
import com.example.data.local.VocalPreset
import com.example.data.local.VocalTake
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sqrt
import kotlin.math.tanh
import kotlin.random.Random

enum class MasteringProfile(
    val displayName: String,
    val subtitle: String,
    val stereoWidth: Float,
    val deEsserStrength: Float,
    val masterDrive: Double,
    val masterMakeupGain: Double,
    val subBoostDb: Double,
) {
    RADIO_SLAM(
        displayName = "Radio Master",
        subtitle = "Loud -9 LUFS • Tight sub & crisp air",
        stereoWidth = 1.24f,
        deEsserStrength = 0.55f,
        masterDrive = 1.26,
        masterMakeupGain = 1.18,
        subBoostDb = 1.2,
    ),
    STREAMING_HIFI(
        displayName = "Streaming Hi-Fi",
        subtitle = "Open -14 LUFS • Clean transient detail",
        stereoWidth = 1.16f,
        deEsserStrength = 0.45f,
        masterDrive = 1.08,
        masterMakeupGain = 1.04,
        subBoostDb = 0.5,
    ),
    BASS_HEAVY(
        displayName = "808 Club Slam",
        subtitle = "Heavy sub-bass + wide stadium stereo",
        stereoWidth = 1.28f,
        deEsserStrength = 0.50f,
        masterDrive = 1.34,
        masterMakeupGain = 1.20,
        subBoostDb = 2.6,
    ),
    ANALOG_WARM(
        displayName = "Analog Warmth",
        subtitle = "Silky tape harmonic glue & smooth highs",
        stereoWidth = 1.12f,
        deEsserStrength = 0.40f,
        masterDrive = 1.20,
        masterMakeupGain = 1.08,
        subBoostDb = 1.0,
    ),
}

enum class VocalClarityMode(
    val displayName: String,
    val subtitle: String,
    val gateThreshold: Float,
    val deMudDb: Double,
    val presenceLiftDb: Double,
    val exciterAmount: Float,
    val beatPocketDuckDepth: Float,
) {
    NATURAL_WARM(
        displayName = "Natural Warm",
        subtitle = "Organic mic warmth + gentle noise gate",
        gateThreshold = 0.005f,
        deMudDb = -1.6,
        presenceLiftDb = 1.8,
        exciterAmount = 0.08f,
        beatPocketDuckDepth = 0.16f,
    ),
    HD_BROADCAST(
        displayName = "HD Broadcast",
        subtitle = "Clean studio de-mud & focused midrange",
        gateThreshold = 0.008f,
        deMudDb = -2.6,
        presenceLiftDb = 3.0,
        exciterAmount = 0.16f,
        beatPocketDuckDepth = 0.24f,
    ),
    CRYSTAL_STUDIO(
        displayName = "Crystal Studio",
        subtitle = "Noise-gated + air exciter + beat vocal pocket",
        gateThreshold = 0.011f,
        deMudDb = -3.4,
        presenceLiftDb = 4.0,
        exciterAmount = 0.24f,
        beatPocketDuckDepth = 0.32f,
    ),
    ULTRA_CRISP(
        displayName = "Ultra Crisp",
        subtitle = "Razor-sharp lyric articulation through 808s",
        gateThreshold = 0.014f,
        deMudDb = -4.0,
        presenceLiftDb = 4.8,
        exciterAmount = 0.34f,
        beatPocketDuckDepth = 0.38f,
    ),
}

/**
 * Studio Mix & Mastering Engine (48 kHz / 32-Bit IEEE Float PCM & 24-Bit Stereo WAV).
 *
 * Vocal Clarity & Mastering Signal Chain:
 *   88Hz HPF -> Smooth Noise Gate / Room-Hiss Reducer -> 240Hz Mud Carve + 470Hz Honk Tame ->
 *   6.4kHz Dynamic De-Esser -> 3-Band Vocal EQ + Harmonic Air Exciter ->
 *   Dual-Stage Optical+FET Compressor -> Haas Stereo Widener -> Damped Plate Reverb
 *
 * Master Bus:
 *   Dynamic Mid-Channel Beat Vocal-Pocket Carve + Sidechain Duck -> Sub EQ ->
 *   Mid/Side Mono Sub (<115Hz) + Stereo Air Width -> Glue Bus Compressor ->
 *   Analog Tape Saturation -> True-Peak Limiter (-0.3 dBFS)
 */
class StudioMixdownEngine(
    private val context: Context,
    private val beatEngine: BeatEngine,
) {
    private val targetSampleRate = STUDIO_SAMPLE_RATE

    suspend fun mixTakeWithBeat(
        take: VocalTake,
        beatStyle: BeatStyle,
        bpm: Int,
        vocalPreset: VocalPreset,
        pcmFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT,
        masteringProfile: MasteringProfile = MasteringProfile.RADIO_SLAM,
        clarityMode: VocalClarityMode = VocalClarityMode.CRYSTAL_STUDIO,
        clarityBoost: Float = 0.70f,
        vocalGain: Float = 1.26f,
        beatGain: Float = 0.78f,
    ): Result<RecordedAudioResult> = withContext(Dispatchers.IO) {
        runCatching {
            val source = File(take.filePath)
            require(source.exists()) { "Source vocal take file missing." }

            val decoded = decodeAudioToMono48000(context, source.absolutePath)
            require(decoded.isNotEmpty()) { "Could not decode vocal audio." }

            mixMonoVocalArrayWithBeat(
                vocalMono = decoded,
                beatStyle = beatStyle,
                bpm = bpm,
                vocalPreset = vocalPreset,
                pcmFormat = pcmFormat,
                masteringProfile = masteringProfile,
                clarityMode = clarityMode,
                clarityBoost = clarityBoost,
                filePrefix = "master",
                vocalGain = vocalGain,
                beatGain = beatGain,
            )
        }
    }

    internal fun mixMonoVocalArrayWithBeat(
        vocalMono: FloatArray,
        beatStyle: BeatStyle,
        bpm: Int,
        vocalPreset: VocalPreset,
        pcmFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT,
        masteringProfile: MasteringProfile = MasteringProfile.RADIO_SLAM,
        clarityMode: VocalClarityMode = VocalClarityMode.CRYSTAL_STUDIO,
        clarityBoost: Float = 0.70f,
        filePrefix: String = "master",
        vocalGain: Float = 1.26f,
        beatGain: Float = 0.78f,
    ): RecordedAudioResult {
        return mixStereoVocalArraysWithBeat(
            vocalLeft = vocalMono,
            vocalRight = vocalMono,
            beatStyle = beatStyle,
            bpm = bpm,
            vocalPreset = vocalPreset,
            pcmFormat = pcmFormat,
            masteringProfile = masteringProfile,
            clarityMode = clarityMode,
            clarityBoost = clarityBoost,
            filePrefix = filePrefix,
            vocalGain = vocalGain,
            beatGain = beatGain,
        )
    }

    internal fun mixStereoVocalArraysWithBeat(
        vocalLeft: FloatArray,
        vocalRight: FloatArray,
        beatStyle: BeatStyle,
        bpm: Int,
        vocalPreset: VocalPreset,
        pcmFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT,
        masteringProfile: MasteringProfile = MasteringProfile.RADIO_SLAM,
        clarityMode: VocalClarityMode = VocalClarityMode.CRYSTAL_STUDIO,
        clarityBoost: Float = 0.70f,
        filePrefix: String = "master",
        vocalGain: Float = 1.26f,
        beatGain: Float = 0.78f,
    ): RecordedAudioResult {
        val totalFrames = minOf(vocalLeft.size, vocalRight.size)
        val takesDir = File(context.filesDir, "takes").apply { mkdirs() }
        val outFile = File(takesDir, "${filePrefix}_${pcmFormat.bitsPerSample}b_${System.currentTimeMillis()}.wav")

        val clarityScale = (0.45 + clarityBoost.coerceIn(0f, 1f) * 0.85)
        val isStereoDoubled = vocalLeft !== vocalRight

        // Vocal Corrective Clarity Filters (L/R symmetric)
        val hpfL = OnePoleHighPass(cutoffHz = 88.0, sampleRate = targetSampleRate)
        val hpfR = OnePoleHighPass(cutoffHz = 88.0, sampleRate = targetSampleRate)
        val mudCutL = BiquadFilter.peaking(240.0, targetSampleRate, q = 1.25, gainDb = clarityMode.deMudDb * clarityScale)
        val mudCutR = BiquadFilter.peaking(240.0, targetSampleRate, q = 1.25, gainDb = clarityMode.deMudDb * clarityScale)
        val nasalCutL = BiquadFilter.peaking(470.0, targetSampleRate, q = 1.5, gainDb = -1.4 * clarityScale)
        val nasalCutR = BiquadFilter.peaking(470.0, targetSampleRate, q = 1.5, gainDb = -1.4 * clarityScale)

        val lowWarmShelfL = BiquadFilter.peaking(195.0, targetSampleRate, q = 0.9, gainDb = presetWarmDb(vocalPreset))
        val lowWarmShelfR = BiquadFilter.peaking(195.0, targetSampleRate, q = 0.9, gainDb = presetWarmDb(vocalPreset))
        val presenceBoostL = BiquadFilter.peaking(
            3150.0,
            targetSampleRate,
            q = 1.05,
            gainDb = (presetPresenceDb(vocalPreset) * 0.55 + clarityMode.presenceLiftDb * 0.65) * clarityScale,
        )
        val presenceBoostR = BiquadFilter.peaking(
            3150.0,
            targetSampleRate,
            q = 1.05,
            gainDb = (presetPresenceDb(vocalPreset) * 0.55 + clarityMode.presenceLiftDb * 0.65) * clarityScale,
        )
        val airShelfL = BiquadFilter.highShelf(10200.0, targetSampleRate, gainDb = presetAirDb(vocalPreset) + 1.4 * clarityScale)
        val airShelfR = BiquadFilter.highShelf(10200.0, targetSampleRate, gainDb = presetAirDb(vocalPreset) + 1.4 * clarityScale)

        val deEssDetector = BiquadFilter.bandPass(6500.0, targetSampleRate, q = 2.4)
        val deEssNotchL = BiquadFilter.lowPass(5400.0, targetSampleRate, q = 0.72)
        val deEssNotchR = BiquadFilter.lowPass(5400.0, targetSampleRate, q = 0.72)
        val exciterHpL = OnePoleHighPass(cutoffHz = 4800.0, sampleRate = targetSampleRate)
        val exciterHpR = OnePoleHighPass(cutoffHz = 4800.0, sampleRate = targetSampleRate)

        // Beat Mid-Channel Vocal-Pocket Carve & Master Mid/Side Sub/Glue processors
        val beatMidPocketBand = BiquadFilter.bandPass(2350.0, targetSampleRate, q = 0.95)
        val subBassEq = BiquadFilter.peaking(62.0, targetSampleRate, q = 0.85, gainDb = masteringProfile.subBoostDb)
        val sideSubLowPass = OnePoleLowPass(115.0, targetSampleRate)

        val revDelayL = FloatArray(4320)
        val revDelayR = FloatArray(4320)
        val haasVocalDelay = FloatArray(384) // ~8ms stereo vocal micro-spread
        var revIdx = 0
        var haasIdx = 0
        var revLpL = 0f
        var revLpR = 0f

        var gateEnv = 0f
        var gateGain = 1f
        var optEnv = 0f
        var fetEnv = 0f
        var sibilanceEnv = 0f
        var masterGlueEnv = 0f

        val gateAttack = exp(-1.0 / (0.005 * targetSampleRate)).toFloat()
        val gateRelease = exp(-1.0 / (0.085 * targetSampleRate)).toFloat()
        val optAttack = exp(-1.0 / (0.012 * targetSampleRate)).toFloat()
        val optRelease = exp(-1.0 / (0.120 * targetSampleRate)).toFloat()
        val fetAttack = exp(-1.0 / (0.002 * targetSampleRate)).toFloat()
        val fetRelease = exp(-1.0 / (0.045 * targetSampleRate)).toFloat()
        val sibAttack = exp(-1.0 / (0.0015 * targetSampleRate)).toFloat()
        val sibRelease = exp(-1.0 / (0.025 * targetSampleRate)).toFloat()
        val glueAttack = exp(-1.0 / (0.008 * targetSampleRate)).toFloat()
        val glueRelease = exp(-1.0 / (0.090 * targetSampleRate)).toFloat()

        val revMix = when (vocalPreset) {
            VocalPreset.RAW_MIC -> 0.04f
            VocalPreset.WARM_BOOTH -> 0.13f
            VocalPreset.CRISPY_TRAP -> 0.18f
            VocalPreset.ARENA_ANTHEM -> 0.30f
            VocalPreset.LOFI_RADIO -> 0.11f
        }
        val vocalDrive = when (vocalPreset) {
            VocalPreset.RAW_MIC -> 1.0f
            VocalPreset.WARM_BOOTH -> 1.22f
            VocalPreset.CRISPY_TRAP -> 1.32f
            VocalPreset.ARENA_ANTHEM -> 1.42f
            VocalPreset.LOFI_RADIO -> 1.54f
        }
        val exciterBlend = (clarityMode.exciterAmount * (0.5f + clarityBoost.coerceIn(0f, 1f) * 0.7f)).coerceIn(0f, 0.45f)
        val gateThresh = clarityMode.gateThreshold

        val rng = Random(2026)
        val bytesPerFrame = (pcmFormat.bitsPerSample / 8) * 2

        BufferedOutputStream(FileOutputStream(outFile), 65536).use { out ->
            writeWavHeader(out, totalFrames.toLong(), targetSampleRate, channels = 2, format = pcmFormat)
            var frameCursor = 0
            val byteChunk = ByteArray(16384 * bytesPerFrame)

            beatEngine.renderInstrumentalChunked(
                style = if (beatStyle == BeatStyle.CUSTOM || beatStyle == BeatStyle.METRONOME) BeatStyle.CUSTOM else beatStyle,
                bpm = bpm,
                totalFrames = totalFrames.toLong(),
            ) { beatStereo, chunkFrames ->
                var outPos = 0
                for (i in 0 until chunkFrames) {
                    val f = frameCursor + i
                    val rawL = hpfL.process(vocalLeft[f])
                    val rawR = hpfR.process(vocalRight[f])

                    // Smooth Soft-Knee Noise Gate (keeps pauses crystal quiet without clicks)
                    val level = maxOf(abs(rawL), abs(rawR))
                    val gateCoeff = if (level > gateEnv) gateAttack else gateRelease
                    gateEnv = gateCoeff * gateEnv + (1f - gateCoeff) * level
                    val targetGateGain = if (gateEnv >= gateThresh) {
                        1f
                    } else {
                        ((gateEnv / gateThresh).let { r -> r * r }).coerceIn(0.08f, 1f)
                    }
                    gateGain += (targetGateGain - gateGain) * 0.025f
                    val gatedL = rawL * gateGain
                    val gatedR = rawR * gateGain

                    // De-esser: attenuate harsh 6.5kHz sibilance dynamically
                    val sibSignal = abs(deEssDetector.process((gatedL + gatedR) * 0.5f))
                    val sibCoeff = if (sibSignal > sibilanceEnv) sibAttack else sibRelease
                    sibilanceEnv = sibCoeff * sibilanceEnv + (1f - sibCoeff) * sibSignal
                    val deEssDuck = if (sibilanceEnv > 0.038f) {
                        ((sibilanceEnv - 0.038f) * 4.5f * masteringProfile.deEsserStrength).coerceIn(0f, 0.58f)
                    } else {
                        0f
                    }
                    val deEssedL = gatedL * (1f - deEssDuck) + deEssNotchL.process(gatedL) * deEssDuck
                    val deEssedR = gatedR * (1f - deEssDuck) + deEssNotchR.process(gatedR) * deEssDuck

                    val eqL = if (vocalPreset == VocalPreset.RAW_MIC) {
                        airShelfL.process(presenceBoostL.process(mudCutL.process(deEssedL)))
                    } else {
                        airShelfL.process(presenceBoostL.process(lowWarmShelfL.process(nasalCutL.process(mudCutL.process(deEssedL)))))
                    }
                    val eqR = if (isStereoDoubled) {
                        if (vocalPreset == VocalPreset.RAW_MIC) {
                            airShelfR.process(presenceBoostR.process(mudCutR.process(deEssedR)))
                        } else {
                            airShelfR.process(presenceBoostR.process(lowWarmShelfR.process(nasalCutR.process(mudCutR.process(deEssedR)))))
                        }
                    } else {
                        eqL
                    }

                    // Harmonic Air Exciter (>4.8kHz crystal condenser shimmer)
                    val hiL = exciterHpL.process(eqL)
                    val hiR = if (isStereoDoubled) exciterHpR.process(eqR) else hiL
                    val excitedL = eqL + (tanh((hiL * 2.1).toDouble()).toFloat() - hiL * 0.25f) * exciterBlend
                    val excitedR = eqR + (tanh((hiR * 2.1).toDouble()).toFloat() - hiR * 0.25f) * exciterBlend

                    // Dual-stage vocal compression (smooth Optical + fast FET peak catch)
                    val absV = maxOf(abs(excitedL), abs(excitedR))
                    optEnv = (if (absV > optEnv) optAttack else optRelease).let { c -> c * optEnv + (1f - c) * absV }
                    fetEnv = (if (absV > fetEnv) fetAttack else fetRelease).let { c -> c * fetEnv + (1f - c) * absV }
                    val optGain = if (optEnv > 0.13f) (1f / sqrt((optEnv / 0.13f).toDouble()).toFloat()).coerceIn(0.42f, 1.0f) else 1.0f
                    val fetGain = if (fetEnv > 0.28f) (0.28f / fetEnv).coerceIn(0.50f, 1.0f) else 1.0f

                    val compL = tanh((excitedL * optGain * fetGain * vocalDrive).toDouble()).toFloat()
                    val compR = if (isStereoDoubled) {
                        tanh((excitedR * optGain * fetGain * vocalDrive).toDouble()).toFloat()
                    } else {
                        compL
                    }

                    // Stereo Haas vocal width + Damped stereo plate reverb
                    val compMono = (compL + compR) * 0.5f
                    val haasDelayed = haasVocalDelay[haasIdx]
                    haasVocalDelay[haasIdx] = compMono
                    haasIdx = (haasIdx + 1) % haasVocalDelay.size

                    val tapL = revDelayL[(revIdx - 1151 + revDelayL.size) % revDelayL.size] * 0.55f +
                        revDelayR[(revIdx - 2399 + revDelayR.size) % revDelayR.size] * 0.35f
                    val tapR = revDelayR[(revIdx - 1327 + revDelayR.size) % revDelayR.size] * 0.55f +
                        revDelayL[(revIdx - 2689 + revDelayL.size) % revDelayL.size] * 0.35f
                    revLpL += (tapL - revLpL) * 0.45f
                    revLpR += (tapR - revLpR) * 0.45f
                    revDelayL[revIdx] = (compL + revLpR * 0.28f).coerceIn(-1f, 1f)
                    revDelayR[revIdx] = (compR + revLpL * 0.28f).coerceIn(-1f, 1f)
                    revIdx = (revIdx + 1) % revDelayL.size

                    val wideBlend = if (isStereoDoubled) 0.08f else if (vocalPreset == VocalPreset.RAW_MIC) 0.04f else 0.14f
                    val vL = (compL + haasDelayed * wideBlend + revLpL * revMix) * vocalGain
                    val vR = (compR - haasDelayed * wideBlend * 0.85f + revLpR * revMix) * vocalGain

                    // Dynamic Vocal-Pocket Mid-Channel Beat Carve + Sidechain Ducking
                    val duck = 1.0f - (optEnv * 0.58f).coerceIn(0f, 0.20f)
                    val rawBeatL = beatStereo[i * 2] * beatGain * duck
                    val rawBeatR = beatStereo[i * 2 + 1] * beatGain * duck
                    val beatMid = (rawBeatL + rawBeatR) * 0.5f
                    val beatSide = (rawBeatL - rawBeatR) * 0.5f
                    val vocalPresenceActivity = (optEnv * 4.5f).coerceIn(0f, 1f) * clarityMode.beatPocketDuckDepth
                    val carvedBeatMid = beatMid - beatMidPocketBand.process(beatMid) * vocalPresenceActivity
                    val bL = carvedBeatMid + beatSide
                    val bR = carvedBeatMid - beatSide

                    // Master Bus: Summing -> Sub EQ -> Mid/Side Matrix -> Glue Compressor -> True-Peak Limiter
                    val sumL = vL + bL
                    val sumR = vR + bR
                    val mid = subBassEq.process((sumL + sumR) * 0.5f)
                    val rawSide = (sumL - sumR) * 0.5f
                    val lowSide = sideSubLowPass.process(rawSide)
                    val wideSide = (rawSide - lowSide * 0.92f) * masteringProfile.stereoWidth

                    val preMasterL = mid + wideSide
                    val preMasterR = mid - wideSide
                    val busMag = maxOf(abs(preMasterL), abs(preMasterR))
                    val glueCoeff = if (busMag > masterGlueEnv) glueAttack else glueRelease
                    masterGlueEnv = glueCoeff * masterGlueEnv + (1f - glueCoeff) * busMag
                    val glueGain = if (masterGlueEnv > 0.42f) {
                        (1f / sqrt((masterGlueEnv / 0.42f).toDouble()).toFloat()).coerceIn(0.62f, 1.0f)
                    } else {
                        1.0f
                    }

                    val drivenL = preMasterL * glueGain * masteringProfile.masterDrive * masteringProfile.masterMakeupGain
                    val drivenR = preMasterR * glueGain * masteringProfile.masterDrive * masteringProfile.masterMakeupGain

                    // Soft analog clipper + brickwall -0.3 dBFS (0.966) limiter
                    val masterL = tanh(drivenL * 0.88).coerceIn(-0.966, 0.966)
                    val masterR = tanh(drivenR * 0.88).coerceIn(-0.966, 0.966)

                    outPos = writeWavSample(byteChunk, outPos, masterL, pcmFormat, rng)
                    outPos = writeWavSample(byteChunk, outPos, masterR, pcmFormat, rng)
                    if (outPos >= byteChunk.size) {
                        out.write(byteChunk, 0, outPos)
                        outPos = 0
                    }
                }
                if (outPos > 0) {
                    out.write(byteChunk, 0, outPos)
                }
                frameCursor += chunkFrames
            }
            out.flush()
        }

        val durationMs = (totalFrames * 1000L) / targetSampleRate.toLong()
        return RecordedAudioResult(filePath = outFile.absolutePath, durationMs = durationMs.coerceAtLeast(500L))
    }

    suspend fun renderInstrumentalMasterWav(
        beatStyle: BeatStyle,
        bpm: Int,
        minutes: Int,
        pcmFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT,
        masteringProfile: MasteringProfile = MasteringProfile.RADIO_SLAM,
    ): Result<RecordedAudioResult> = withContext(Dispatchers.IO) {
        runCatching {
            val clampedMinutes = minutes.coerceIn(1, 10)
            val totalFrames = clampedMinutes.toLong() * 60L * targetSampleRate.toLong()
            val takesDir = File(context.filesDir, "takes").apply { mkdirs() }
            val outFile = File(takesDir, "beat_${clampedMinutes}m_${pcmFormat.bitsPerSample}b_${System.currentTimeMillis()}.wav")
            val rng = Random(4824)
            val bytesPerFrame = (pcmFormat.bitsPerSample / 8) * 2
            val subBassEq = BiquadFilter.peaking(62.0, targetSampleRate, q = 0.85, gainDb = masteringProfile.subBoostDb)

            BufferedOutputStream(FileOutputStream(outFile), 65536).use { out ->
                writeWavHeader(out, totalFrames, targetSampleRate, channels = 2, format = pcmFormat)
                val byteChunk = ByteArray(16384 * bytesPerFrame)
                beatEngine.renderInstrumentalChunked(beatStyle, bpm, totalFrames) { stereoChunk, chunkFrames ->
                    var outPos = 0
                    for (i in 0 until chunkFrames) {
                        val rawL = stereoChunk[i * 2]
                        val rawR = stereoChunk[i * 2 + 1]
                        val mid = subBassEq.process((rawL + rawR) * 0.5f)
                        val side = (rawL - rawR) * 0.5f * masteringProfile.stereoWidth
                        val sL = tanh((mid + side) * masteringProfile.masterDrive * 0.90).coerceIn(-0.966, 0.966)
                        val sR = tanh((mid - side) * masteringProfile.masterDrive * 0.90).coerceIn(-0.966, 0.966)
                        outPos = writeWavSample(byteChunk, outPos, sL, pcmFormat, rng)
                        outPos = writeWavSample(byteChunk, outPos, sR, pcmFormat, rng)
                        if (outPos >= byteChunk.size) {
                            out.write(byteChunk, 0, outPos)
                            outPos = 0
                        }
                    }
                    if (outPos > 0) {
                        out.write(byteChunk, 0, outPos)
                    }
                }
                out.flush()
            }
            RecordedAudioResult(filePath = outFile.absolutePath, durationMs = clampedMinutes * 60_000L)
        }
    }

    private fun presetWarmDb(preset: VocalPreset): Double = when (preset) {
        VocalPreset.RAW_MIC -> 0.0
        VocalPreset.WARM_BOOTH -> 2.4
        VocalPreset.CRISPY_TRAP -> -0.8
        VocalPreset.ARENA_ANTHEM -> 2.8
        VocalPreset.LOFI_RADIO -> 3.0
    }

    private fun presetPresenceDb(preset: VocalPreset): Double = when (preset) {
        VocalPreset.RAW_MIC -> 0.0
        VocalPreset.WARM_BOOTH -> 2.8
        VocalPreset.CRISPY_TRAP -> 3.6
        VocalPreset.ARENA_ANTHEM -> 3.0
        VocalPreset.LOFI_RADIO -> 4.2
    }

    private fun presetAirDb(preset: VocalPreset): Double = when (preset) {
        VocalPreset.RAW_MIC -> 0.0
        VocalPreset.WARM_BOOTH -> 2.2
        VocalPreset.CRISPY_TRAP -> 4.5
        VocalPreset.ARENA_ANTHEM -> 3.5
        VocalPreset.LOFI_RADIO -> -4.2
    }
}
