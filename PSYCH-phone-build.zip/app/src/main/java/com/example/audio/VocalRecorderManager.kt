package com.example.audio

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

data class RecordedAudioResult(
    val filePath: String,
    val durationMs: Long,
)

class VocalRecorderManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _elapsedMs = MutableStateFlow(0L)
    val elapsedMs: StateFlow<Long> = _elapsedMs.asStateFlow()

    private val _waveformBars = MutableStateFlow(List(48) { 0.08f })
    val waveformBars: StateFlow<List<Float>> = _waveformBars.asStateFlow()

    private val _activeCaptureLabel = MutableStateFlow("48kHz • 32-Bit Float PCM")
    val activeCaptureLabel: StateFlow<String> = _activeCaptureLabel.asStateFlow()

    private var audioRecord: AudioRecord? = null
    private var captureJob: Job? = null
    private var fallbackMediaRecorder: MediaRecorder? = null
    private var meterJob: Job? = null
    private var outputFile: File? = null
    private var startTimeMs: Long = 0L
    private var activePcmFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT

    @Volatile
    private var captureFramesWritten: Long = 0L

    @Volatile
    private var captureSampleRate: Int = STUDIO_SAMPLE_RATE

    fun startRecording(targetFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT): Boolean {
        if (_isRecording.value) return false
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        activePcmFormat = targetFormat
        val takesDir = File(context.filesDir, "takes").apply { mkdirs() }
        val wavFile = File(takesDir, "take_${System.currentTimeMillis()}.wav")

        val pcmStarted = tryStartHighResAudioRecord(wavFile, targetFormat)
        if (pcmStarted) {
            return true
        }

        runCatching { wavFile.delete() }
        val m4aFile = File(takesDir, "take_${System.currentTimeMillis()}.m4a")
        return tryStartFallbackMediaRecorder(m4aFile)
    }

    @SuppressLint("MissingPermission")
    private fun tryStartHighResAudioRecord(wavFile: File, targetFormat: StudioPcmFormat): Boolean {
        val candidateSources = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                add(MediaRecorder.AudioSource.UNPROCESSED)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaRecorder.AudioSource.VOICE_PERFORMANCE)
            }
            add(MediaRecorder.AudioSource.MIC)
        }
        val candidateEncodings = buildList {
            if (targetFormat.isFloat) {
                add(AudioFormat.ENCODING_PCM_FLOAT)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    add(AudioFormat.ENCODING_PCM_24BIT_PACKED)
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    add(AudioFormat.ENCODING_PCM_24BIT_PACKED)
                }
                add(AudioFormat.ENCODING_PCM_FLOAT)
            }
            add(AudioFormat.ENCODING_PCM_16BIT)
        }

        var chosenRecord: AudioRecord? = null
        var chosenEncoding = AudioFormat.ENCODING_PCM_16BIT
        var chosenSampleRate = STUDIO_SAMPLE_RATE
        var chosenBufferBytes = 8192

        for (rate in listOf(48000, 44100)) {
            for (encoding in candidateEncodings) {
                val minBuf = AudioRecord.getMinBufferSize(
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    encoding,
                )
                if (minBuf <= 0) continue
                val bufSize = (minBuf * 3).coerceAtLeast(16384)
                for (source in candidateSources) {
                    val rec = runCatching {
                        AudioRecord.Builder()
                            .setAudioSource(source)
                            .setAudioFormat(
                                AudioFormat.Builder()
                                    .setEncoding(encoding)
                                    .setSampleRate(rate)
                                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                                    .build(),
                            )
                            .setBufferSizeInBytes(bufSize)
                            .build()
                    }.getOrNull()
                    if (rec != null && rec.state == AudioRecord.STATE_INITIALIZED) {
                        val started = runCatching {
                            rec.startRecording()
                            rec.recordingState == AudioRecord.RECORDSTATE_RECORDING
                        }.getOrDefault(false)
                        if (started) {
                            chosenRecord = rec
                            chosenEncoding = encoding
                            chosenSampleRate = rate
                            chosenBufferBytes = bufSize
                            break
                        }
                    }
                    runCatching { rec?.release() }
                }
                if (chosenRecord != null) break
            }
            if (chosenRecord != null) break
        }

        val activeRecord = chosenRecord ?: return false
        audioRecord = activeRecord
        outputFile = wavFile
        captureSampleRate = chosenSampleRate
        captureFramesWritten = 0L
        startTimeMs = System.currentTimeMillis()
        _elapsedMs.value = 0L
        _waveformBars.value = List(48) { 0.08f }
        _isRecording.value = true

        val captureBadge = when (chosenEncoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> "${chosenSampleRate / 1000}kHz • 32-Bit Float Mic -> ${targetFormat.shortBadge}"
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> "${chosenSampleRate / 1000}kHz • 24-Bit Mic -> ${targetFormat.shortBadge}"
            else -> "${chosenSampleRate / 1000}kHz • Lossless -> ${targetFormat.shortBadge}"
        }
        _activeCaptureLabel.value = captureBadge

        captureJob = scope.launch(Dispatchers.IO) {
            val rng = Random(3224)
            BufferedOutputStream(FileOutputStream(wavFile), 65536).use { out ->
                writeWavHeader(out, 0L, chosenSampleRate, channels = 1, format = targetFormat)
                val bytesPerOutSample = targetFormat.bitsPerSample / 8
                val floatChunk = FloatArray(2048)
                val byteReadChunk = ByteArray(chosenBufferBytes.coerceAtLeast(8192))
                val shortChunk = ShortArray(2048)
                val outBytes = ByteArray(4096 * bytesPerOutSample)
                var meterAccumCount = 0
                var meterPeak = 0f

                while (isActive && _isRecording.value) {
                    val sampleCount: Int
                    when (chosenEncoding) {
                        AudioFormat.ENCODING_PCM_FLOAT -> {
                            val read = activeRecord.read(floatChunk, 0, floatChunk.size, AudioRecord.READ_BLOCKING)
                            sampleCount = read.coerceAtLeast(0)
                            if (sampleCount > 0) {
                                var pos = 0
                                for (i in 0 until sampleCount) {
                                    val s = floatChunk[i].let { if (it.isFinite()) it else 0f }
                                    val a = abs(s)
                                    if (a > meterPeak) meterPeak = a
                                    pos = writeWavSample(outBytes, pos, s.toDouble(), targetFormat, rng)
                                }
                                out.write(outBytes, 0, pos)
                            }
                        }
                        AudioFormat.ENCODING_PCM_24BIT_PACKED -> {
                            val maxBytes = (byteReadChunk.size / 3) * 3
                            val readBytes = activeRecord.read(byteReadChunk, 0, maxBytes, AudioRecord.READ_BLOCKING)
                            sampleCount = (readBytes.coerceAtLeast(0)) / 3
                            if (sampleCount > 0) {
                                var pos = 0
                                for (i in 0 until sampleCount) {
                                    val off = i * 3
                                    val b0 = byteReadChunk[off].toInt() and 0xFF
                                    val b1 = byteReadChunk[off + 1].toInt() and 0xFF
                                    val b2 = byteReadChunk[off + 2].toInt()
                                    val signed = (b2 shl 16) or (b1 shl 8) or b0
                                    val s = signed / 8388608.0
                                    val a = abs(s).toFloat()
                                    if (a > meterPeak) meterPeak = a
                                    pos = writeWavSample(outBytes, pos, s, targetFormat, rng)
                                }
                                out.write(outBytes, 0, pos)
                            }
                        }
                        else -> {
                            val read = activeRecord.read(shortChunk, 0, shortChunk.size)
                            sampleCount = read.coerceAtLeast(0)
                            if (sampleCount > 0) {
                                var pos = 0
                                for (i in 0 until sampleCount) {
                                    val s = shortChunk[i] / 32768.0
                                    val a = abs(s).toFloat()
                                    if (a > meterPeak) meterPeak = a
                                    pos = writeWavSample(outBytes, pos, s, targetFormat, rng)
                                }
                                out.write(outBytes, 0, pos)
                            }
                        }
                    }

                    if (sampleCount > 0) {
                        captureFramesWritten += sampleCount
                        meterAccumCount += sampleCount
                        if (meterAccumCount >= chosenSampleRate / 22) {
                            val bar = (sqrt(meterPeak.toDouble()).toFloat() * 1.15f).coerceIn(0.06f, 1.0f)
                            val elapsed = (captureFramesWritten * 1000L) / chosenSampleRate.toLong()
                            meterAccumCount = 0
                            meterPeak = 0f
                            if (_isRecording.value) {
                                _elapsedMs.value = elapsed
                                _waveformBars.value = _waveformBars.value.drop(1) + bar
                            }
                        }
                    }
                }
                out.flush()
            }
        }
        return true
    }

    private fun tryStartFallbackMediaRecorder(targetFile: File): Boolean {
        val startedRecorder =
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                tryStartMediaRecorder(
                    targetFile = targetFile,
                    audioSource = MediaRecorder.AudioSource.VOICE_PERFORMANCE,
                    sampleRate = 48000,
                    bitRate = 320000,
                )
            } else {
                null
            })
                ?: tryStartMediaRecorder(
                    targetFile = targetFile,
                    audioSource = MediaRecorder.AudioSource.MIC,
                    sampleRate = 48000,
                    bitRate = 256000,
                )

        if (startedRecorder == null) {
            runCatching { targetFile.delete() }
            fallbackMediaRecorder = null
            outputFile = null
            _isRecording.value = false
            return false
        }

        fallbackMediaRecorder = startedRecorder
        outputFile = targetFile
        startTimeMs = System.currentTimeMillis()
        _elapsedMs.value = 0L
        _waveformBars.value = List(48) { 0.08f }
        _activeCaptureLabel.value = "48kHz • 320kbps AAC Fallback"
        _isRecording.value = true

        meterJob = scope.launch {
            while (isActive && _isRecording.value) {
                val amp = runCatching { fallbackMediaRecorder?.maxAmplitude ?: 0 }.getOrDefault(0)
                val normalized = (amp / 22000f).coerceIn(0.06f, 1.0f)
                _elapsedMs.value = System.currentTimeMillis() - startTimeMs
                _waveformBars.value = _waveformBars.value.drop(1) + normalized
                delay(50L)
            }
        }
        return true
    }

    private fun tryStartMediaRecorder(
        targetFile: File,
        audioSource: Int,
        sampleRate: Int,
        bitRate: Int,
    ): MediaRecorder? {
        val mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        return try {
            mediaRecorder.apply {
                setAudioSource(audioSource)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioChannels(1)
                setAudioSamplingRate(sampleRate)
                setAudioEncodingBitRate(bitRate)
                setOutputFile(targetFile.absolutePath)
                prepare()
                start()
            }
            mediaRecorder
        } catch (_: Throwable) {
            runCatching { mediaRecorder.release() }
            null
        }
    }

    suspend fun stopRecording(): RecordedAudioResult? {
        _isRecording.value = false
        val activeRec = audioRecord
        val job = captureJob
        val fb = fallbackMediaRecorder
        val file = outputFile
        val elapsedFallback = (System.currentTimeMillis() - startTimeMs).coerceAtLeast(300L)

        meterJob?.cancel()
        meterJob = null
        audioRecord = null
        captureJob = null
        fallbackMediaRecorder = null
        outputFile = null

        if (activeRec != null) {
            withContext(Dispatchers.IO) {
                runCatching { activeRec.stop() }
                runCatching { job?.join() }
                runCatching { activeRec.release() }
                if (file != null && file.exists() && captureFramesWritten > 0L) {
                    finalizeWavHeaderInPlace(file, captureFramesWritten, captureSampleRate, activePcmFormat)
                }
            }
            val durationMs = ((captureFramesWritten * 1000L) / captureSampleRate.coerceAtLeast(8000)).coerceAtLeast(0L)
            _elapsedMs.value = 0L
            return if (file != null && file.exists() && file.length() > 64L && durationMs >= 300L) {
                RecordedAudioResult(filePath = file.absolutePath, durationMs = durationMs)
            } else {
                runCatching { file?.delete() }
                null
            }
        }

        val stoppedOk = runCatching {
            fb?.stop()
            true
        }.getOrDefault(false)
        runCatching { fb?.release() }
        _elapsedMs.value = 0L

        return if (stoppedOk && file != null && file.exists() && file.length() > 0L) {
            RecordedAudioResult(filePath = file.absolutePath, durationMs = elapsedFallback)
        } else {
            runCatching { file?.delete() }
            null
        }
    }

    private fun finalizeWavHeaderInPlace(
        file: File,
        totalFrames: Long,
        sampleRate: Int,
        format: StudioPcmFormat,
    ) {
        val header = buildWavHeaderBytes(totalFrames, sampleRate, channels = 1, format = format)
        runCatching {
            RandomAccessFile(file, "rw").use { raf ->
                raf.seek(0L)
                raf.write(header)
            }
        }
    }

    fun release() {
        _isRecording.value = false
        meterJob?.cancel()
        captureJob?.cancel()
        runCatching { audioRecord?.stop() }
        runCatching { audioRecord?.release() }
        runCatching { fallbackMediaRecorder?.stop() }
        runCatching { fallbackMediaRecorder?.release() }
        audioRecord = null
        fallbackMediaRecorder = null
    }
}
