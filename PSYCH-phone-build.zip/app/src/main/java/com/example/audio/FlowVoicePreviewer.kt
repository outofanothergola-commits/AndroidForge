package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.StudioLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class FlowVoicePreviewer(context: Context) {

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setOnUtteranceProgressListener(
                    object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _isSpeaking.value = true
                        }

                        override fun onDone(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _isSpeaking.value = false
                        }
                    },
                )
            }
        }
    }

    fun toggleSpeak(lyrics: String, language: StudioLanguage, bpm: Int) {
        val engine = tts ?: return
        if (_isSpeaking.value) {
            stop()
            return
        }
        if (!ready || lyrics.isBlank()) return

        val rawCleaned = lyrics.lines()
            .filter { it.isNotBlank() && !it.trim().startsWith("[") }
            .joinToString(". ")
        if (rawCleaned.isBlank()) return
        val maxLen = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(1000)
        val cleaned = if (rawCleaned.length > maxLen) rawCleaned.take(maxLen) else rawCleaned

        val locale = Locale.forLanguageTag(language.ttsLanguageTag)
        val res = engine.setLanguage(locale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.ENGLISH)
        }
        // Adjust speech cadence slightly with BPM
        val rate = (0.92f + ((bpm - 90) / 220f)).coerceIn(0.82f, 1.32f)
        engine.setSpeechRate(rate)
        engine.setPitch(0.95f)
        engine.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, "psych_flow_preview")
    }

    fun stop() {
        runCatching { tts?.stop() }
        _isSpeaking.value = false
    }

    fun release() {
        stop()
        runCatching { tts?.shutdown() }
        tts = null
    }
}
