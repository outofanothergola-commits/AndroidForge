package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.os.Build
import com.example.data.local.VocalPreset
import com.example.data.local.VocalTake
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder


class TakePlayerManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _playingTakeId = MutableStateFlow<Long?>(null)
    val playingTakeId: StateFlow<Long?> = _playingTakeId.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private var player: MediaPlayer? = null
    private var pcmTrack: AudioTrack? = null
    private var pcmPlaybackJob: Job? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var presetReverb: PresetReverb? = null
    private var dynamicsProcessing: DynamicsProcessing? = null
    private var progressJob: Job? = null
    private var currentPreset: VocalPreset = VocalPreset.WARM_BOOTH

    fun setPreset(preset: VocalPreset) {
        currentPreset = preset
        applyEffectsToActivePlayer(preset)
    }

    fun togglePlay(take: VocalTake, preset: VocalPreset = currentPreset): Boolean {
        currentPreset = preset
        if (_playingTakeId.value == take.id) {
            stop()
            return false
        }
        stop()

        if (take.filePath.endsWith(".wav", ignoreCase = true) && File(take.filePath).exists()) {
            return playLosslessWavViaFloatAudioTrack(take, preset)
        }

        return try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                )
                setDataSource(take.filePath)
                setOnCompletionListener {
                    stop()
                }
                prepare()
                start()
            }
            player = mp
            attachEffects(mp.audioSessionId, preset)
            _playingTakeId.value = take.id
            _progress.value = 0f

            progressJob = scope.launch {
                while (isActive && _playingTakeId.value == take.id) {
                    val active = player ?: break
                    val dur = runCatching { active.duration }.getOrDefault(0)
                    val pos = runCatching { active.currentPosition }.getOrDefault(0)
                    _progress.value = if (dur > 0) (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f) else 0f
                    delay(80L)
                }
            }
            true
        } catch (_: Throwable) {
            stop()
            false
        }
    }

    private fun playLosslessWavViaFloatAudioTrack(take: VocalTake, preset: VocalPreset): Boolean {
        _playingTakeId.value = take.id
        _progress.value = 0f

        pcmPlaybackJob = scope.launch(Dispatchers.IO) {
            val file = File(take.filePath)
            val headerProbe = runCatching {
                FileInputStream(file).use { input ->
                    val head = ByteArray(256)
                    val read = input.read(head)
                    if (read >= 44) inspectWavStreamHeader(head.copyOf(read)) else null
                }
            }.getOrNull()

            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val (track, useFloatPcm) = buildPlaybackAudioTrack(attrs) ?: run {
                withContext(Dispatchers.Main) { stop() }
                return@launch
            }
            pcmTrack = track

            withContext(Dispatchers.Main) {
                attachEffects(track.audioSessionId, preset)
            }

            try {
                track.play()
                val chunkFrames = 4096
                val floatChunk = if (useFloatPcm) FloatArray(chunkFrames * 2) else null
                val shortChunk = if (!useFloatPcm) ShortArray(chunkFrames * 2) else null

                if (headerProbe != null && headerProbe.sampleRate == STUDIO_SAMPLE_RATE) {
                    val bytesPerSample = (headerProbe.bitsPerSample / 8).coerceAtLeast(2)
                    val frameBytes = bytesPerSample * headerProbe.channels
                    val maxAvailable = (file.length() - headerProbe.dataOffset).coerceAtMost(headerProbe.dataSize.toLong()).coerceAtLeast(0L)
                    val totalFrames = (maxAvailable / frameBytes.toLong()).coerceAtLeast(1L)
                    val ioBuf = ByteArray(chunkFrames * frameBytes)
                    val bb = ByteBuffer.wrap(ioBuf).order(ByteOrder.LITTLE_ENDIAN)

                    FileInputStream(file).use { dataStream ->
                        var toSkip = headerProbe.dataOffset.toLong()
                        while (toSkip > 0L) {
                            val skipped = dataStream.skip(toSkip)
                            if (skipped <= 0L) break
                            toSkip -= skipped
                        }
                        var framesPlayed = 0L
                        var carry = 0
                        while (isActive && _playingTakeId.value == take.id && framesPlayed < totalFrames) {
                            val read = dataStream.read(ioBuf, carry, ioBuf.size - carry)
                            if (read <= 0) break
                            val totalAvail = carry + read
                            val readableFrames = (totalAvail / frameBytes).toLong()
                                .coerceAtMost(totalFrames - framesPlayed)
                                .toInt()
                            if (readableFrames <= 0) {
                                carry = totalAvail
                                continue
                            }
                            var pos = 0
                            for (f in 0 until readableFrames) {
                                var l = 0f
                                var r = 0f
                                for (c in 0 until headerProbe.channels) {
                                    val s = readPcmSampleNormalized(ioBuf, bb, pos, headerProbe.bitsPerSample, headerProbe.isFloat)
                                    if (c == 0) l = s
                                    if (c == 1) r = s
                                    pos += bytesPerSample
                                }
                                val rightSample = if (headerProbe.channels >= 2) r else l
                                if (floatChunk != null) {
                                    floatChunk[f * 2] = l.coerceIn(-1f, 1f)
                                    floatChunk[f * 2 + 1] = rightSample.coerceIn(-1f, 1f)
                                } else if (shortChunk != null) {
                                    shortChunk[f * 2] = (l.coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
                                    shortChunk[f * 2 + 1] = (rightSample.coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
                                }
                            }
                            if (floatChunk != null) {
                                track.write(floatChunk, 0, readableFrames * 2, AudioTrack.WRITE_BLOCKING)
                            } else if (shortChunk != null) {
                                track.write(shortChunk, 0, readableFrames * 2)
                            }
                            val consumed = readableFrames * frameBytes
                            val leftover = totalAvail - consumed
                            if (leftover > 0) {
                                System.arraycopy(ioBuf, consumed, ioBuf, 0, leftover)
                            }
                            carry = leftover
                            framesPlayed += readableFrames
                            if (_playingTakeId.value == take.id) {
                                _progress.value = (framesPlayed.toFloat() / totalFrames.toFloat()).coerceIn(0f, 1f)
                            }
                        }
                    }
                } else {
                    val decoded = runCatching {
                        decodeAudioToStereo48000(context, take.filePath)
                    }.getOrNull() ?: run {
                        withContext(Dispatchers.Main) { stop() }
                        return@launch
                    }
                    val left = decoded.first
                    val right = decoded.second
                    val totalFrames = left.size
                    var cursor = 0
                    while (isActive && _playingTakeId.value == take.id && cursor < totalFrames) {
                        val count = (totalFrames - cursor).coerceAtMost(chunkFrames)
                        if (floatChunk != null) {
                            for (i in 0 until count) {
                                floatChunk[i * 2] = left[cursor + i].coerceIn(-1f, 1f)
                                floatChunk[i * 2 + 1] = right[cursor + i].coerceIn(-1f, 1f)
                            }
                            track.write(floatChunk, 0, count * 2, AudioTrack.WRITE_BLOCKING)
                        } else if (shortChunk != null) {
                            for (i in 0 until count) {
                                shortChunk[i * 2] = (left[cursor + i].coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
                                shortChunk[i * 2 + 1] = (right[cursor + i].coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
                            }
                            track.write(shortChunk, 0, count * 2)
                        }
                        cursor += count
                        if (_playingTakeId.value == take.id) {
                            _progress.value = (cursor.toFloat() / totalFrames.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                        }
                    }
                }
            } catch (_: Throwable) {
                // Safe stop
            } finally {
                withContext(Dispatchers.Main) {
                    if (_playingTakeId.value == take.id) {
                        stop()
                    }
                }
            }
        }
        return true
    }

    private fun buildPlaybackAudioTrack(attrs: AudioAttributes): Pair<AudioTrack, Boolean>? {
        val floatTrack = runCatching {
            val minBuf = AudioTrack.getMinBufferSize(
                STUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_FLOAT,
            ).coerceAtLeast(STUDIO_SAMPLE_RATE / 2)
            val t = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(STUDIO_SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build(),
                )
                .setBufferSizeInBytes(minBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            check(t.state == AudioTrack.STATE_INITIALIZED)
            t
        }.getOrNull()

        if (floatTrack != null) return floatTrack to true

        return runCatching {
            val minBuf = AudioTrack.getMinBufferSize(
                STUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT,
            ).coerceAtLeast(STUDIO_SAMPLE_RATE / 4)
            val t = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(STUDIO_SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build(),
                )
                .setBufferSizeInBytes(minBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            check(t.state == AudioTrack.STATE_INITIALIZED)
            t to false
        }.getOrNull()
    }

    private fun attachEffects(audioSessionId: Int, preset: VocalPreset) {
        releaseEffects()
        runCatching {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
        }
        runCatching {
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
        }
        runCatching {
            presetReverb = PresetReverb(0, audioSessionId).apply { enabled = true }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching {
                val cfg = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                    2,
                    false,
                    0,
                    false,
                    0,
                    false,
                    0,
                    true,
                ).build()
                dynamicsProcessing = DynamicsProcessing(0, audioSessionId, cfg).apply {
                    enabled = true
                }
            }
        }
        applyEffectsToActivePlayer(preset)
    }

    private fun applyEffectsToActivePlayer(preset: VocalPreset) {
        runCatching {
            val eq = equalizer ?: return@runCatching
            val bands = eq.numberOfBands.toInt()
            val range = eq.bandLevelRange
            val minLvl = range[0].toInt()
            val maxLvl = range[1].toInt()
            for (b in 0 until bands) {
                val freqHz = eq.getCenterFreq(b.toShort()) / 1000
                val target = when {
                    freqHz < 250 -> preset.lowDb.toInt()
                    freqHz < 2500 -> preset.midDb.toInt()
                    else -> preset.highDb.toInt()
                }.coerceIn(minLvl, maxLvl)
                eq.setBandLevel(b.toShort(), target.toShort())
            }
        }
        runCatching {
            val bb = bassBoost ?: return@runCatching
            if (bb.strengthSupported) {
                bb.setStrength(preset.bassBoostStrength)
            }
        }
        runCatching {
            val rev = presetReverb ?: return@runCatching
            rev.preset = preset.reverbPreset
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching {
                val dp = dynamicsProcessing ?: return@runCatching
                val limiter = DynamicsProcessing.Limiter(
                    true,
                    preset != VocalPreset.RAW_MIC,
                    0,
                    2.0f,
                    20.0f,
                    2.5f,
                    -0.5f,
                    if (preset == VocalPreset.RAW_MIC) 0f else 1.5f,
                )
                dp.setLimiterAllChannelsTo(limiter)
            }
        }
    }

    private fun releaseEffects() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { presetReverb?.release() }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching { dynamicsProcessing?.release() }
        }
        equalizer = null
        bassBoost = null
        presetReverb = null
        dynamicsProcessing = null
    }

    fun stop() {
        progressJob?.cancel()
        progressJob = null
        pcmPlaybackJob?.cancel()
        pcmPlaybackJob = null
        releaseEffects()
        pcmTrack?.let { track ->
            runCatching {
                track.pause()
                track.flush()
                track.release()
            }
        }
        pcmTrack = null
        player?.let { mp ->
            runCatching {
                if (mp.isPlaying) mp.stop()
                mp.release()
            }
        }
        player = null
        _playingTakeId.value = null
        _progress.value = 0f
    }

    fun release() {
        stop()
    }
}
