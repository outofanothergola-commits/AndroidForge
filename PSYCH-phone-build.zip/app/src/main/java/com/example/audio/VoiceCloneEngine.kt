package com.example.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.StudioLanguage
import com.example.data.local.BeatStyle
import com.example.data.local.VocalPreset
import com.example.data.local.VocalProfileHelpers
import com.example.data.local.VoiceProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh
import kotlin.random.Random

enum class VoiceCloneRealismMode(
    val displayName: String,
    val subtitle: String,
    val consonantPreserveGain: Float,
    val vibratoDepthSamples: Float,
    val subWarmthMix: Float,
    val melodicSnap: Float,
) {
    STUDIO_NATURAL(
        displayName = "Studio Natural",
        subtitle = "Human vibrato + warm chest + clear diction",
        consonantPreserveGain = 1.08f,
        vibratoDepthSamples = 1.6f,
        subWarmthMix = 0.10f,
        melodicSnap = 0.15f,
    ),
    CRYSTAL_RAP_HD(
        displayName = "Crystal Rap HD",
        subtitle = "Transient-locked consonants + tight booth punch",
        consonantPreserveGain = 1.28f,
        vibratoDepthSamples = 0.7f,
        subWarmthMix = 0.14f,
        melodicSnap = 0.0f,
    ),
    MELODIC_AUTOTUNE(
        displayName = "Melodic Pitch-Lock",
        subtitle = "Smooth chorus vibrato + harmonic stereo sheen",
        consonantPreserveGain = 1.15f,
        vibratoDepthSamples = 2.6f,
        subWarmthMix = 0.12f,
        melodicSnap = 0.65f,
    ),
    RAW_HUMAN(
        displayName = "Raw Human Breath",
        subtitle = "Organic breath realism + minimal processing",
        consonantPreserveGain = 1.00f,
        vibratoDepthSamples = 1.9f,
        subWarmthMix = 0.07f,
        melodicSnap = 0.0f,
    ),
}

data class ExtractedVoiceprint(
    val pitchHz: Float,
    val spectralCentroidHz: Float,
    val warmthDb: Float,
    val presenceDb: Float,
    val airDb: Float,
    val gritAmount: Float,
    val formantShift: Float,
    val breathiness: Float,
    val timbreSummary: String,
    val durationMs: Long,
    val spectralEnvelopeCsv: String = "",
    val pitchVarianceHz: Float = 18f,
)

/**
 * 48 kHz High-Realism Acoustic Voiceprint Extractor & Split-Band Voice Clone DSP Engine.
 *
 * Acoustic Pipeline:
 * - Pitch F0 median & natural pitch variance extraction via normalized autocorrelation
 * - 8-Band spectral fingerprint extraction (140Hz to 10.5kHz) for real timbre matching
 * - Split-Band Voiced/Unvoiced Separation (3.4 kHz crossover):
 *   WSOLA time-preserving pitch shift acts purely on harmonic vocal folds (< 3.4 kHz)
 *   while unvoiced consonants (s/t/k/p/ch > 3.4 kHz) stay razor-clear without phaser smear
 * - 3-Formant (F1/F2/F3) + 8-band spectral envelope matching + smooth noise gate + de-esser
 * - Expressive micro-vibrato / melodic chorus layer & optional stereo hook doubler
 */
class VoiceCloneEngine(
    private val context: Context,
    private val mixdownEngine: StudioMixdownEngine,
) {
    private val sampleRate = STUDIO_SAMPLE_RATE

    suspend fun analyzeVoiceSample(pathOrUri: String): Result<ExtractedVoiceprint> = withContext(Dispatchers.IO) {
        runCatching {
            val mono = decodeAudioToMono48000(context, pathOrUri)
            require(mono.size >= sampleRate / 2) { "Voice sample is too short (record at least 1 second)." }

            val (pitchHz, pitchVarianceHz) = estimatePitchStatsHz(mono)
            val spectral = analyzeSpectralProfile(mono)
            val zcr = computeVoicedZeroCrossingRate(mono)
            val envelopeCsv = extract8BandEnvelopeCsv(mono)

            val warmthDb = ((2000f - spectral.centroidHz) / 360f + spectral.lowRatio * 5.5f).coerceIn(-3.0f, 5.5f)
            val presenceDb = ((spectral.midRatio * 7.5f) + 1.0f).coerceIn(0.0f, 5.5f)
            val airDb = ((spectral.highRatio * 12.0f) + ((spectral.centroidHz - 1400f) / 450f)).coerceIn(-3.5f, 6.0f)
            val gritAmount = (zcr * 2.2f + spectral.midRatio * 0.45f).coerceIn(0.08f, 0.72f)
            val formantShift = (0.85f + (pitchHz - 95f) / 360f).coerceIn(0.80f, 1.24f)
            val breathiness = (spectral.highRatio * 0.65f).coerceIn(0.04f, 0.28f)

            val registerLabel = when {
                pitchHz < 115f -> "Deep Bass"
                pitchHz < 150f -> "Baritone"
                pitchHz < 195f -> "Tenor"
                pitchHz < 245f -> "Alto"
                else -> "Soprano"
            }
            val colorLabel = when {
                gritAmount >= 0.40f -> "Raspy Grit"
                warmthDb >= 2.8f -> "Warm Chest"
                airDb >= 2.8f -> "Crisp Air"
                else -> "Balanced Studio"
            }
            val summary = "${pitchHz.toInt()} Hz $registerLabel • $colorLabel (8-Band DNA)"
            val durationMs = (mono.size * 1000L) / sampleRate.toLong()

            ExtractedVoiceprint(
                pitchHz = pitchHz,
                spectralCentroidHz = spectral.centroidHz,
                warmthDb = warmthDb,
                presenceDb = presenceDb,
                airDb = airDb,
                gritAmount = gritAmount,
                formantShift = formantShift,
                breathiness = breathiness,
                timbreSummary = summary,
                durationMs = durationMs,
                spectralEnvelopeCsv = envelopeCsv,
                pitchVarianceHz = pitchVarianceHz,
            )
        }
    }

    suspend fun generateClonedVoiceFromLyrics(
        lyrics: String,
        language: StudioLanguage,
        profile: VoiceProfile,
        bpm: Int,
        beatStyle: BeatStyle,
        vocalPreset: VocalPreset,
        mixWithBeat: Boolean,
        pitchOffsetSemitones: Float,
        formantOffset: Float,
        gritBoost: Float,
        realismMode: VoiceCloneRealismMode = VoiceCloneRealismMode.CRYSTAL_RAP_HD,
        clarityMode: VocalClarityMode = VocalClarityMode.CRYSTAL_STUDIO,
        clarityBoost: Float = 0.75f,
        stereoDoubleLayer: Boolean = true,
        pcmFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT,
        masteringProfile: MasteringProfile = MasteringProfile.RADIO_SLAM,
    ): Result<RecordedAudioResult> = withContext(Dispatchers.IO) {
        runCatching {
            val speakableLines = lyrics.lines()
                .map { it.trim() }
                .filter {
                    it.isNotEmpty() &&
                        !it.startsWith("[") &&
                        !it.startsWith("Song Title:", ignoreCase = true) &&
                        !it.startsWith("Genre:", ignoreCase = true)
                }

            require(speakableLines.isNotEmpty()) { "Write or generate lyrics before cloning voice vocals." }

            val speechChunks = mutableListOf<FloatArray>()
            val ttsRate = (0.94f + (bpm - 95) / 210f).coerceIn(0.84f, 1.32f)
            val tempDir = File(context.cacheDir, "tts_clone").apply { mkdirs() }

            val batchedPhrases = batchLinesForTts(speakableLines, maxChars = 340)
            val gapSamples = (sampleRate * (0.13f * (100f / bpm.coerceIn(60, 180)))).toInt().coerceIn(2200, 14400)

            for ((idx, phrase) in batchedPhrases.withIndex()) {
                val wavFile = File(tempDir, "tts_chunk_${System.currentTimeMillis()}_$idx.wav")
                val ok = synthesizePhraseToWav(phrase, language, ttsRate, wavFile)
                if (ok && wavFile.exists() && wavFile.length() > 64L) {
                    val pcm = decodeAudioToMono48000(context, wavFile.absolutePath)
                    if (pcm.isNotEmpty()) {
                        speechChunks.add(trimSilence(pcm))
                    }
                }
                runCatching { wavFile.delete() }
            }

            require(speechChunks.isNotEmpty()) {
                "Device speech synthesizer unavailable for ${language.englishName}. Switch to Morph Recorded Take or install system TTS voice."
            }

            val totalSamples = speechChunks.sumOf { it.size } + gapSamples * speechChunks.size
            val combinedRaw = FloatArray(totalSamples)
            var cursor = 0
            for (chunk in speechChunks) {
                chunk.copyInto(combinedRaw, destinationOffset = cursor)
                cursor += chunk.size + gapSamples
            }

            val (sourceF0, _) = estimatePitchStatsHz(combinedRaw)
            val (clonedL, clonedR) = applyVoiceCloneDspStereo(
                srcMono = combinedRaw,
                sourceF0 = sourceF0,
                profile = profile,
                pitchOffsetSemitones = pitchOffsetSemitones,
                formantOffset = formantOffset,
                gritBoost = gritBoost,
                realismMode = realismMode,
                clarityBoost = clarityBoost,
                stereoDoubleLayer = stereoDoubleLayer,
            )

            if (mixWithBeat && beatStyle != BeatStyle.CUSTOM && beatStyle != BeatStyle.METRONOME) {
                mixdownEngine.mixStereoVocalArraysWithBeat(
                    vocalLeft = clonedL,
                    vocalRight = clonedR,
                    beatStyle = beatStyle,
                    bpm = bpm,
                    vocalPreset = vocalPreset,
                    pcmFormat = pcmFormat,
                    masteringProfile = masteringProfile,
                    clarityMode = clarityMode,
                    clarityBoost = clarityBoost,
                    filePrefix = "clone_mix",
                    vocalGain = 1.36f,
                    beatGain = 0.76f,
                )
            } else {
                writeStereoClonedStemWav(clonedL, clonedR, prefix = "clone_voice", pcmFormat = pcmFormat)
            }
        }
    }

    suspend fun morphTakeWithVoiceProfile(
        sourceFilePath: String,
        profile: VoiceProfile,
        bpm: Int,
        beatStyle: BeatStyle,
        vocalPreset: VocalPreset,
        mixWithBeat: Boolean,
        pitchOffsetSemitones: Float,
        formantOffset: Float,
        gritBoost: Float,
        realismMode: VoiceCloneRealismMode = VoiceCloneRealismMode.CRYSTAL_RAP_HD,
        clarityMode: VocalClarityMode = VocalClarityMode.CRYSTAL_STUDIO,
        clarityBoost: Float = 0.75f,
        stereoDoubleLayer: Boolean = true,
        pcmFormat: StudioPcmFormat = StudioPcmFormat.PCM_32_FLOAT,
        masteringProfile: MasteringProfile = MasteringProfile.RADIO_SLAM,
    ): Result<RecordedAudioResult> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(sourceFilePath)
            require(file.exists()) { "Selected vocal take file not found." }
            val rawMono = decodeAudioToMono48000(context, file.absolutePath)
            require(rawMono.isNotEmpty()) { "Could not decode selected vocal take." }

            val (sourceF0, _) = estimatePitchStatsHz(rawMono)
            val (clonedL, clonedR) = applyVoiceCloneDspStereo(
                srcMono = rawMono,
                sourceF0 = sourceF0,
                profile = profile,
                pitchOffsetSemitones = pitchOffsetSemitones,
                formantOffset = formantOffset,
                gritBoost = gritBoost,
                realismMode = realismMode,
                clarityBoost = clarityBoost,
                stereoDoubleLayer = stereoDoubleLayer,
            )

            if (mixWithBeat && beatStyle != BeatStyle.CUSTOM && beatStyle != BeatStyle.METRONOME) {
                mixdownEngine.mixStereoVocalArraysWithBeat(
                    vocalLeft = clonedL,
                    vocalRight = clonedR,
                    beatStyle = beatStyle,
                    bpm = bpm,
                    vocalPreset = vocalPreset,
                    pcmFormat = pcmFormat,
                    masteringProfile = masteringProfile,
                    clarityMode = clarityMode,
                    clarityBoost = clarityBoost,
                    filePrefix = "clone_morph_mix",
                    vocalGain = 1.30f,
                    beatGain = 0.76f,
                )
            } else {
                writeStereoClonedStemWav(clonedL, clonedR, prefix = "clone_morph", pcmFormat = pcmFormat)
            }
        }
    }

    private fun applyVoiceCloneDspStereo(
        srcMono: FloatArray,
        sourceF0: Float,
        profile: VoiceProfile,
        pitchOffsetSemitones: Float,
        formantOffset: Float,
        gritBoost: Float,
        realismMode: VoiceCloneRealismMode,
        clarityBoost: Float,
        stereoDoubleLayer: Boolean,
    ): Pair<FloatArray, FloatArray> {
        val clarityNorm = clarityBoost.coerceIn(0f, 1f)
        val ratioFromProfile = (profile.pitchHz / sourceF0.coerceIn(75f, 320f)).coerceIn(0.60f, 1.75f)
        val semitoneFactor = 2.0.pow(pitchOffsetSemitones / 12.0).toFloat()
        val totalPitchRatio = (ratioFromProfile * semitoneFactor).coerceIn(0.56f, 1.85f)

        // 1. Split-Band Voiced/Unvoiced Separation (3.4 kHz crossover)
        // Only harmonic vocal body (<3.4 kHz) is pitch shifted; consonants (>3.4 kHz) stay razor sharp!
        val splitLp1 = OnePoleLowPass(3400.0, sampleRate)
        val splitLp2 = OnePoleLowPass(3400.0, sampleRate)
        val voicedLowBand = FloatArray(srcMono.size)
        val consonantHighBand = FloatArray(srcMono.size)
        for (i in srcMono.indices) {
            val lo = splitLp2.process(splitLp1.process(srcMono[i]))
            voicedLowBand[i] = lo
            consonantHighBand[i] = srcMono[i] - lo
        }

        // 2. WSOLA pitch shift on voiced body only
        val shiftedLowBand = wsolaPitchShift(voicedLowBand, totalPitchRatio)

        // 3. Recombine voiced body + transient-preserved consonant articulation + expressive micro-vibrato
        val recombined = FloatArray(srcMono.size)
        val consGain = realismMode.consonantPreserveGain * (0.78f + clarityNorm * 0.42f)
        val vibDepth = realismMode.vibratoDepthSamples
        val vibRate = 5.35 * 2.0 * PI / sampleRate
        val melodicChorusMix = realismMode.melodicSnap * 0.22f
        val chorusDelayBuf = FloatArray(512)
        var chorusIdx = 0

        for (i in srcMono.indices) {
            val baseVoiced = shiftedLowBand[i]
            val modOffset = (sin(i * vibRate) * vibDepth).toFloat()
            val voicedExpressive = if (vibDepth > 0.1f && i > 8 && i < shiftedLowBand.lastIndex - 8) {
                val readIdx = (i + modOffset).coerceIn(0f, shiftedLowBand.lastIndex.toFloat())
                val idx0 = readIdx.toInt()
                val frac = readIdx - idx0
                val vibSample = shiftedLowBand[idx0] * (1f - frac) + shiftedLowBand[(idx0 + 1).coerceAtMost(shiftedLowBand.lastIndex)] * frac
                baseVoiced * (1f - melodicChorusMix) + vibSample * melodicChorusMix
            } else {
                baseVoiced
            }

            // Soft-gate unvoiced high band so room hiss isn't lifted while crisp S/T/K transients shine
            val cSample = consonantHighBand[i]
            val consGate = if (abs(cSample) > 0.006f) 1f else 0.15f
            val blended = voicedExpressive + cSample * consGain * consGate

            chorusDelayBuf[chorusIdx] = voicedExpressive
            val subIdx = (chorusIdx - 192 + chorusDelayBuf.size) % chorusDelayBuf.size
            val warmSub = if (profile.pitchHz < 135f) chorusDelayBuf[subIdx] * realismMode.subWarmthMix else 0f
            chorusIdx = (chorusIdx + 1) % chorusDelayBuf.size

            recombined[i] = blended + warmSub
        }

        // 4. Multi-Stage Clarity Gate + 3-Formant Filters + 8-Band Acoustic Fingerprint Matching
        val hpf = OnePoleHighPass(cutoffHz = 82.0, sampleRate = sampleRate)
        val deMud = BiquadFilter.peaking(235.0, sampleRate, q = 1.25, gainDb = -2.2 - clarityNorm * 1.4)
        val effectiveFormant = (profile.formantShift * formantOffset).coerceIn(0.74f, 1.32f)
        val f1Freq = (540.0 * effectiveFormant).coerceIn(320.0, 920.0)
        val f2Freq = (1650.0 * effectiveFormant).coerceIn(950.0, 2600.0)
        val f3Freq = (2850.0 * effectiveFormant).coerceIn(2100.0, 3600.0)

        val formant1 = BiquadFilter.peaking(f1Freq, sampleRate, q = 1.4, gainDb = profile.warmthDb.toDouble() * 0.85)
        val formant2 = BiquadFilter.peaking(f2Freq, sampleRate, q = 1.5, gainDb = profile.presenceDb.toDouble() * 0.90)
        val formant3 = BiquadFilter.peaking(f3Freq, sampleRate, q = 1.6, gainDb = (profile.airDb.toDouble() * 0.40) + clarityNorm * 1.6)
        val presenceEq = BiquadFilter.peaking(3250.0, sampleRate, q = 1.1, gainDb = profile.presenceDb.toDouble() * 0.45 + clarityNorm * 2.4)
        val airEq = BiquadFilter.highShelf(9200.0, sampleRate, gainDb = profile.airDb.toDouble() + clarityNorm * 2.0)

        val bandFilters = parseEnvelopeFilters(profile.spectralEnvelopeCsv)
        val deEssDetect = BiquadFilter.bandPass(6500.0, sampleRate, q = 2.4)
        val deEssLow = BiquadFilter.lowPass(5400.0, sampleRate, q = 0.72)
        val airNoiseHp = OnePoleHighPass(cutoffHz = 4800.0, sampleRate = sampleRate)
        val exciterHp = OnePoleHighPass(cutoffHz = 5000.0, sampleRate = sampleRate)

        val grit = (profile.gritAmount + gritBoost).coerceIn(0.04f, 0.95f)
        val drive = 1.0f + grit * 1.25f
        val breathMix = (profile.breathiness * if (realismMode == VoiceCloneRealismMode.RAW_HUMAN) 1.15f else 0.72f).coerceIn(0f, 0.24f)
        val exciterMix = (0.10f + clarityNorm * 0.24f).coerceIn(0.05f, 0.36f)
        val rng = Random(7711)

        val processedMono = FloatArray(recombined.size)
        var gateEnv = 0f
        var gateGain = 1f
        var sibEnv = 0f
        var peak = 0.001f

        val gateAttack = exp(-1.0 / (0.005 * sampleRate)).toFloat()
        val gateRelease = exp(-1.0 / (0.085 * sampleRate)).toFloat()
        val sibAttack = exp(-1.0 / (0.0015 * sampleRate)).toFloat()
        val sibRelease = exp(-1.0 / (0.025 * sampleRate)).toFloat()

        for (i in recombined.indices) {
            var s = hpf.process(recombined[i])

            // Smooth Noise Gate
            val absS = abs(s)
            gateEnv = (if (absS > gateEnv) gateAttack else gateRelease).let { c -> c * gateEnv + (1f - c) * absS }
            val targetG = if (gateEnv >= 0.008f) 1f else ((gateEnv / 0.008f).let { r -> r * r }).coerceIn(0.10f, 1f)
            gateGain += (targetG - gateGain) * 0.025f
            s *= gateGain

            s = deMud.process(s)
            s = formant1.process(s)
            s = formant2.process(s)
            s = formant3.process(s)
            for (bf in bandFilters) {
                s = bf.process(s)
            }
            s = presenceEq.process(s)
            s = airEq.process(s)

            // Dynamic De-Esser before saturation
            val sibVal = abs(deEssDetect.process(s))
            sibEnv = (if (sibVal > sibEnv) sibAttack else sibRelease).let { c -> c * sibEnv + (1f - c) * sibVal }
            val duck = if (sibEnv > 0.042f) ((sibEnv - 0.042f) * 4.0f).coerceIn(0f, 0.50f) else 0f
            s = s * (1f - duck) + deEssLow.process(s) * duck

            // Warm asymmetric chest tube saturation + harmonic air exciter
            val sat = tanh((s * drive + 0.03f * grit).toDouble()).toFloat() - 0.024f * grit
            val airHi = exciterHp.process(sat)
            val excited = sat + (tanh((airHi * 2.0).toDouble()).toFloat() - airHi * 0.25f) * exciterMix
            val breathNoise = airNoiseHp.process((rng.nextFloat() * 2f - 1f) * abs(sat) * breathMix)
            val voiced = excited + breathNoise

            processedMono[i] = voiced
            val a = abs(voiced)
            if (a > peak) peak = a
        }

        val normGain = (0.86f / peak).coerceIn(0.3f, 2.2f)
        for (i in processedMono.indices) {
            processedMono[i] = (processedMono[i] * normGain).coerceIn(-0.96f, 0.96f)
        }

        if (!stereoDoubleLayer) {
            return processedMono to processedMono
        }

        // 5. Studio Stereo Hook Layer: micro-chorus L/R spread (center lead + wide stereo double)
        val outL = FloatArray(processedMono.size)
        val outR = FloatArray(processedMono.size)
        val delayL = FloatArray(720)
        val delayR = FloatArray(720)
        var dIdx = 0
        val lfoRate = 1.65 * 2.0 * PI / sampleRate
        val sideAirEqL = BiquadFilter.peaking(4200.0, sampleRate, q = 1.0, gainDb = 1.6)
        val sideAirEqR = BiquadFilter.peaking(2900.0, sampleRate, q = 1.0, gainDb = 1.6)

        for (i in processedMono.indices) {
            val lead = processedMono[i]
            delayL[dIdx] = lead
            delayR[dIdx] = lead
            val modL = (sin(i * lfoRate) * 45.0).toInt()
            val modR = (cos(i * lfoRate) * 45.0).toInt()
            val idxL = (dIdx - (440 + modL) + delayL.size) % delayL.size
            val idxR = (dIdx - (530 + modR) + delayR.size) % delayR.size
            val dblL = sideAirEqL.process(delayL[idxL])
            val dblR = sideAirEqR.process(delayR[idxR])
            dIdx = (dIdx + 1) % delayL.size

            outL[i] = (lead * 0.84f + dblL * 0.24f - dblR * 0.08f).coerceIn(-0.97f, 0.97f)
            outR[i] = (lead * 0.84f + dblR * 0.24f - dblL * 0.08f).coerceIn(-0.97f, 0.97f)
        }
        return outL to outR
    }

    private fun parseEnvelopeFilters(csv: String): List<BiquadFilter> {
        if (csv.isBlank()) return emptyList()
        val gains = csv.split(',').mapNotNull { it.trim().toDoubleOrNull() }
        if (gains.size < 8) return emptyList()
        val freqs = doubleArrayOf(140.0, 320.0, 620.0, 1200.0, 2200.0, 3600.0, 6000.0, 10500.0)
        return freqs.mapIndexed { idx, freq ->
            val gain = (gains[idx] * 0.55).coerceIn(-4.5, 4.5)
            BiquadFilter.peaking(freq, sampleRate, q = 1.35, gainDb = gain)
        }
    }

    private fun extract8BandEnvelopeCsv(mono: FloatArray): String {
        val freqs = doubleArrayOf(140.0, 320.0, 620.0, 1200.0, 2200.0, 3600.0, 6000.0, 10500.0)
        val filters = freqs.map { f -> BiquadFilter.bandPass(f, sampleRate, q = 1.6) }
        val energies = DoubleArray(freqs.size) { 1e-8 }
        val step = (mono.size / 48000).coerceAtLeast(1)
        var i = 0
        while (i < mono.size) {
            val s = mono[i]
            for (b in filters.indices) {
                val out = filters[b].process(s)
                energies[b] += (out * out).toDouble()
            }
            i += step
        }
        val dbValues = energies.map { 10.0 * log10(it) }
        val avgDb = dbValues.average()
        return dbValues.joinToString(",") { db ->
            String.format(Locale.US, "%.2f", (db - avgDb).coerceIn(-6.0, 6.0))
        }
    }

    /**
     * WSOLA (Waveform Similarity Overlap-Add) pitch shifter:
     * Preserves duration while cleanly shifting fundamental frequency + harmonics.
     */
    private fun wsolaPitchShift(input: FloatArray, pitchRatio: Float): FloatArray {
        if (input.size < 2048 || abs(pitchRatio - 1.0f) < 0.015f) return input

        val windowSize = 1344 // 28 ms at 48kHz
        val hopOut = windowSize / 4
        val hopIn = (hopOut / pitchRatio).toInt().coerceAtLeast(32)
        val searchRadius = 160

        val stretchedLen = (input.size * pitchRatio).toInt().coerceAtLeast(windowSize + 1)
        val stretched = FloatArray(stretchedLen)
        val weightSum = FloatArray(stretchedLen)
        val hann = FloatArray(windowSize) { i ->
            (0.5 * (1.0 - cos((2.0 * PI * i) / (windowSize - 1)))).toFloat()
        }

        var inPos = 0
        var outPos = 0
        while (outPos + windowSize < stretchedLen && inPos + windowSize < input.size) {
            var bestOffset = 0
            if (outPos > 0) {
                var bestCorr = -1e9f
                val maxDelta = searchRadius.coerceAtMost(input.size - windowSize - inPos)
                val minDelta = (-searchRadius).coerceAtLeast(-inPos)
                var d = minDelta
                while (d <= maxDelta) {
                    var corr = 0f
                    var k = 0
                    while (k < hopOut) {
                        corr += input[inPos + d + k] * stretched[outPos + k]
                        k += 4
                    }
                    if (corr > bestCorr) {
                        bestCorr = corr
                        bestOffset = d
                    }
                    d += 4
                }
            }
            val srcStart = (inPos + bestOffset).coerceIn(0, input.size - windowSize)
            for (k in 0 until windowSize) {
                val w = hann[k]
                stretched[outPos + k] += input[srcStart + k] * w
                weightSum[outPos + k] += w
            }
            inPos += hopIn
            outPos += hopOut
        }

        for (i in stretched.indices) {
            val w = weightSum[i]
            if (w > 0.001f) stretched[i] /= w
        }

        val output = FloatArray(input.size)
        val ratio = (stretched.size - 1).toDouble() / input.size.coerceAtLeast(1)
        val lastIdx = stretched.lastIndex
        for (i in output.indices) {
            val pos = i * ratio
            val i1 = pos.toInt().coerceIn(0, lastIdx)
            val t = (pos - i1).toFloat()
            val p0 = stretched[(i1 - 1).coerceAtLeast(0)]
            val p1 = stretched[i1]
            val p2 = stretched[(i1 + 1).coerceAtMost(lastIdx)]
            val p3 = stretched[(i1 + 2).coerceAtMost(lastIdx)]
            val t2 = t * t
            val t3 = t2 * t
            output[i] = 0.5f * (
                (2f * p1) +
                    (-p0 + p2) * t +
                    (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 +
                    (-p0 + 3f * p1 - 3f * p2 + p3) * t3
                )
        }
        return output
    }

    private fun writeStereoClonedStemWav(
        left: FloatArray,
        right: FloatArray,
        prefix: String,
        pcmFormat: StudioPcmFormat,
    ): RecordedAudioResult {
        val frames = minOf(left.size, right.size)
        val takesDir = File(context.filesDir, "takes").apply { mkdirs() }
        val outFile = File(takesDir, "${prefix}_${pcmFormat.bitsPerSample}b_${System.currentTimeMillis()}.wav")
        val rng = Random(9182)
        val bytesPerFrame = (pcmFormat.bitsPerSample / 8) * 2
        BufferedOutputStream(FileOutputStream(outFile), 65536).use { out ->
            writeWavHeader(out, frames.toLong(), sampleRate, channels = 2, format = pcmFormat)
            val chunk = ByteArray(16384 * bytesPerFrame)
            var outPos = 0
            for (i in 0 until frames) {
                val l = left[i].toDouble().let { if (pcmFormat.isFloat) it else it.coerceIn(-0.97, 0.97) }
                val r = right[i].toDouble().let { if (pcmFormat.isFloat) it else it.coerceIn(-0.97, 0.97) }
                outPos = writeWavSample(chunk, outPos, l, pcmFormat, rng)
                outPos = writeWavSample(chunk, outPos, r, pcmFormat, rng)
                if (outPos >= chunk.size) {
                    out.write(chunk, 0, outPos)
                    outPos = 0
                }
            }
            if (outPos > 0) {
                out.write(chunk, 0, outPos)
            }
            out.flush()
        }
        val durationMs = (frames * 1000L) / sampleRate.toLong()
        return RecordedAudioResult(outFile.absolutePath, durationMs.coerceAtLeast(500L))
    }

    private fun estimatePitchStatsHz(mono: FloatArray): Pair<Float, Float> {
        val frameSize = 2048
        val step = 1024
        val minLag = sampleRate / 350
        val maxLag = sampleRate / 68
        val pitches = mutableListOf<Float>()

        var start = 0
        while (start + frameSize < mono.size) {
            var energy = 0f
            for (i in 0 until frameSize) {
                val s = mono[start + i]
                energy += s * s
            }
            val rms = sqrt(energy / frameSize)
            if (rms > 0.018f) {
                var bestLag = -1
                var bestNormCorr = 0.42f
                for (lag in minLag..maxLag) {
                    var num = 0f
                    var denA = 0f
                    var denB = 0f
                    var i = 0
                    while (i < frameSize - lag) {
                        val a = mono[start + i]
                        val b = mono[start + i + lag]
                        num += a * b
                        denA += a * a
                        denB += b * b
                        i += 2
                    }
                    val den = sqrt((denA * denB).toDouble()).toFloat().coerceAtLeast(1e-6f)
                    val corr = num / den
                    if (corr > bestNormCorr) {
                        bestNormCorr = corr
                        bestLag = lag
                    }
                }
                if (bestLag > 0) {
                    pitches.add(sampleRate.toFloat() / bestLag.toFloat())
                }
            }
            start += step
        }

        if (pitches.isEmpty()) return 132f to 18f
        pitches.sort()
        val median = pitches[pitches.size / 2].coerceIn(78f, 290f)
        val p15 = pitches[(pitches.size * 15) / 100]
        val p85 = pitches[((pitches.size * 85) / 100).coerceAtMost(pitches.lastIndex)]
        val variance = (p85 - p15).coerceIn(6f, 95f)
        return median to variance
    }

    private data class SpectralStats(
        val centroidHz: Float,
        val lowRatio: Float,
        val midRatio: Float,
        val highRatio: Float,
    )

    private fun analyzeSpectralProfile(mono: FloatArray): SpectralStats {
        val lpLow = OnePoleLowPass(350.0, sampleRate)
        val lpMid = OnePoleLowPass(2400.0, sampleRate)
        val hpHigh = OnePoleHighPass(4200.0, sampleRate)
        var eLow = 1e-6
        var eMid = 1e-6
        var eHigh = 1e-6

        val step = (mono.size / 48000).coerceAtLeast(1)
        var i = 0
        while (i < mono.size) {
            val s = mono[i]
            val low = lpLow.process(s)
            val mid = lpMid.process(s) - low
            val high = hpHigh.process(s)
            eLow += (low * low).toDouble()
            eMid += (mid * mid).toDouble()
            eHigh += (high * high).toDouble()
            i += step
        }
        val total = eLow + eMid + eHigh
        val rLow = (eLow / total).toFloat()
        val rMid = (eMid / total).toFloat()
        val rHigh = (eHigh / total).toFloat()
        val centroid = rLow * 220f + rMid * 1350f + rHigh * 5600f
        return SpectralStats(centroid.coerceIn(400f, 4500f), rLow, rMid, rHigh)
    }

    private fun computeVoicedZeroCrossingRate(mono: FloatArray): Float {
        var crossings = 0
        var active = 0
        for (i in 1 until mono.size) {
            if (abs(mono[i]) > 0.02f) {
                active++
                if ((mono[i] >= 0f) != (mono[i - 1] >= 0f)) {
                    crossings++
                }
            }
        }
        if (active == 0) return 0.08f
        return (crossings.toFloat() / active.toFloat()).coerceIn(0.02f, 0.35f)
    }

    private fun trimSilence(pcm: FloatArray): FloatArray {
        var first = 0
        while (first < pcm.size && abs(pcm[first]) < 0.01f) first++
        var last = pcm.lastIndex
        while (last > first && abs(pcm[last]) < 0.01f) last--
        if (last <= first) return pcm
        return pcm.copyOfRange(first, last + 1)
    }

    private fun batchLinesForTts(lines: List<String>, maxChars: Int): List<String> {
        val batches = mutableListOf<String>()
        val sb = StringBuilder()
        for (line in lines) {
            if (sb.length + line.length + 2 > maxChars && sb.isNotEmpty()) {
                batches.add(sb.toString())
                sb.clear()
            }
            if (sb.isNotEmpty()) sb.append(". ")
            sb.append(line)
        }
        if (sb.isNotEmpty()) batches.add(sb.toString())
        return batches
    }

    private suspend fun synthesizePhraseToWav(
        text: String,
        language: StudioLanguage,
        speechRate: Float,
        outFile: File,
    ): Boolean = withTimeout(18_000L) {
        suspendCancellableCoroutine { cont ->
            var ttsRef: TextToSpeech? = null
            val utteranceId = "clone_tts_${System.nanoTime()}"
            ttsRef = TextToSpeech(context.applicationContext) { status ->
                val engine = ttsRef
                if (status != TextToSpeech.SUCCESS || engine == null) {
                    runCatching { engine?.shutdown() }
                    if (cont.isActive) cont.resume(false)
                    return@TextToSpeech
                }
                val primary = Locale.forLanguageTag(language.ttsLanguageTag)
                val res = engine.setLanguage(primary)
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val hindiRes = engine.setLanguage(Locale.forLanguageTag("hi-IN"))
                    if (hindiRes == TextToSpeech.LANG_MISSING_DATA || hindiRes == TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.setLanguage(Locale.ENGLISH)
                    }
                }
                engine.setSpeechRate(speechRate)
                engine.setPitch(1.0f)
                engine.setOnUtteranceProgressListener(
                    object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) {
                            runCatching { engine.shutdown() }
                            if (cont.isActive) cont.resume(true)
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(id: String?) {
                            runCatching { engine.shutdown() }
                            if (cont.isActive) cont.resume(false)
                        }
                    },
                )
                val synthResult = engine.synthesizeToFile(text, Bundle(), outFile, utteranceId)
                if (synthResult != TextToSpeech.SUCCESS) {
                    runCatching { engine.shutdown() }
                    if (cont.isActive) cont.resume(false)
                }
            }
            cont.invokeOnCancellation {
                runCatching {
                    ttsRef?.stop()
                    ttsRef?.shutdown()
                }
            }
        }
    }

    companion object {
        fun starterProfiles(): List<VoiceProfile> = VocalProfileHelpers.starterProfiles()
    }
}
